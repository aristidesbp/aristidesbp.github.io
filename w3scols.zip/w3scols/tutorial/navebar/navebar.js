// tutorial/navebar/navebar.js
document.addEventListener("DOMContentLoaded", function () {
    
// Carregar o conteúdo do arquivo navebar.html e inserir no contêiner
    fetch("tutorial/navebar/navebar.html")
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro na rede: ' + response.status);
            }
            return response.text();
        })
        .then(data => {
            document.getElementById("navebar").innerHTML = data;
        })
        .catch(error => console.error('Erro ao carregar a navebar:', error));
});