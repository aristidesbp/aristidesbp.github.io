// tutorial/conteudo/conteudo.js
document.addEventListener("DOMContentLoaded", function () {
    // Carregar o conteúdo do arquivo conteudo.html e inserir no contêiner
    fetch("tutorial/conteudo/conteudo.html")
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro na rede: ' + response.status);
            }
            return response.text();
        })
        .then(data => {
            document.getElementById("conteudo").innerHTML = data;
        })
        .catch(error => console.error('Erro ao carregar o conteudo:', error));
});