// tutorial/footer/footer.js
document.addEventListener("DOMContentLoaded", function () {
    // Carregar o conteúdo do arquivo conteudo.html e inserir no contêiner
    fetch("tutorial/footer/footer.html")
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro na rede: ' + response.status);
            }
            return response.text();
        })
        .then(data => {
            document.getElementById("footer").innerHTML = data;
        })
        .catch(error => console.error('Erro ao carregar o footer:', error));
});