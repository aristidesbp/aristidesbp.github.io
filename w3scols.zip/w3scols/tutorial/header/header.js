// tutorial/header/header.js
document.addEventListener("DOMContentLoaded", function () {
    // Carregar o conteúdo do arquivo conteudo.html e inserir no contêiner
    fetch("tutorial/header/header.html")
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro na rede: ' + response.status);
            }
            return response.text();
        })
        .then(data => {
            document.getElementById("header").innerHTML = data;
        })
        .catch(error => console.error('Erro ao carregar o header:', error));
});