# banco
```
/* inicio de limpeza_total */
-- Deleta todas as tabelas em cascata (isso já apaga RLS, Triggers e Constraints atrelados a elas)
DROP TABLE IF EXISTS public.auditoria_produtos CASCADE;
DROP TABLE IF EXISTS public.itens_venda CASCADE;
DROP TABLE IF EXISTS public.vendas CASCADE;
DROP TABLE IF EXISTS public.movimentacoes_estoque CASCADE;
DROP TABLE IF EXISTS public.parcelas CASCADE;
DROP TABLE IF EXISTS public.financas CASCADE;
DROP TABLE IF EXISTS public.avaliacoes CASCADE;
DROP TABLE IF EXISTS public.favoritos CASCADE;
DROP TABLE IF EXISTS public.servicos CASCADE;
DROP TABLE IF EXISTS public.categorias CASCADE;
DROP TABLE IF EXISTS public.produtos CASCADE;
DROP TABLE IF EXISTS public.entidades CASCADE;
/* fim de limpeza_total */

/* inicio de setup_storages */
-- Criação dos 4 buckets. 
-- Produtos e Entidades são públicos (qualquer um vê a foto). Boletos e Comprovantes são privados.
INSERT INTO storage.buckets (id, name, public) VALUES ('foto_produtos', 'foto_produtos', true) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('foto_entidades', 'foto_entidades', true) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('foto_comprovantes', 'foto_comprovantes', false) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('foto_boletos', 'foto_boletos', false) ON CONFLICT DO NOTHING;
/* fim de setup_storages */

/* inicio de criacao_tabelas_saas */
-- 1. ENTIDADES (Espelho do auth.users)
CREATE TABLE public.entidades (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    nome_completo text, avatar_url text, bio text, cpf text, data_nascimento date,
    email text, telefone text, tipo_acesso text DEFAULT 'cliente', tipo_entidade text DEFAULT 'cliente',
    status_entidade text DEFAULT 'ativo', avaliacao integer DEFAULT 5,
    cep text, logradouro text, numero text, bairro text, cidade text, estado character varying
);

-- 2. CATEGORIAS
CREATE TABLE public.categorias (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    tipo_de_categoria text NOT NULL
);

-- 3. SERVICOS
CREATE TABLE public.servicos (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    titulo text NOT NULL, descricao text, 
    categoria bigint REFERENCES public.categorias(id) ON DELETE SET NULL,
    preco_estimado numeric(10, 2), preco_detalhe text, foto_url text,
    criado_por_usuario bigint REFERENCES public.entidades(id) ON DELETE CASCADE,
    terceiro boolean DEFAULT false, eu_mesmo boolean DEFAULT true, whatsapp text
);

-- 4. FAVORITOS
CREATE TABLE public.favoritos (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    usuario_id bigint NOT NULL REFERENCES public.entidades(id) ON DELETE CASCADE,
    servico_id bigint NOT NULL REFERENCES public.servicos(id) ON DELETE CASCADE
);

-- 5. AVALIACOES
CREATE TABLE public.avaliacoes (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    servico_id bigint NOT NULL REFERENCES public.servicos(id) ON DELETE CASCADE,
    author_id bigint NOT NULL REFERENCES public.entidades(id) ON DELETE CASCADE,
    nota smallint NOT NULL CHECK (nota >= 1 AND nota <= 5),
    comentario text
);
/* fim de criacao_tabelas_saas */

/* inicio de criacao_tabelas_produtos_vendas */
-- 6. PRODUTOS (Super-Tabela: Mescla da Blindagem Fiscal com Multi-tenant SaaS)
CREATE TABLE public.produtos (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id), -- Pertence a um usuário SaaS
    nome text NOT NULL,
    preco numeric NOT NULL, -- Preço de Venda
    preco_custo numeric DEFAULT 0.00,
    especificacoes jsonb DEFAULT '{}'::jsonb,
    foto_url text,
    codigo_produto text, ean text, ncm text, cest text, cfop text, -- Fiscais
    unidade_comercial text,
    quantidade numeric DEFAULT 0, -- Estoque Atual
    estoque_minimo numeric DEFAULT 5,
    valor_total numeric DEFAULT 0,
    fornecedor text, origem text, local_estoque text, local_loja text,
    tipo_embalagem text, categoria text DEFAULT 'Geral',
    peso_liquido numeric DEFAULT 0, dimensoes text,
    data_compra date, data_vencimento date,
    esta_ativo boolean DEFAULT true,
    criado_em timestamp with time zone DEFAULT now()
);

-- 7. AUDITORIA PRODUTOS
CREATE TABLE public.auditoria_produtos (
    id_auditoria uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    produto_id uuid, acao text NOT NULL,
    dados_antigos jsonb, dados_novos jsonb,
    usuario_id uuid, data_hora timestamp with time zone DEFAULT now()
);

-- 8. MOVIMENTAÇÕES DE ESTOQUE
CREATE TABLE public.movimentacoes_estoque (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id),
    produto_id uuid REFERENCES public.produtos(id),
    tipo text CHECK (tipo = ANY (ARRAY['entrada', 'saida'])),
    quantidade numeric NOT NULL, -- Alterado para numeric para compatibilidade com produtos
    motivo text DEFAULT 'venda',
    created_at timestamp with time zone DEFAULT now()
);

-- 9. VENDAS (PDV)
CREATE TABLE public.vendas (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id),
    entidade_id bigint REFERENCES public.entidades(id),
    valor_total numeric NOT NULL, desconto numeric DEFAULT 0.00,
    forma_pagamento text,
    status text DEFAULT 'concluida' CHECK (status = ANY (ARRAY['pendente', 'concluida', 'cancelada'])),
    created_at timestamp with time zone DEFAULT now()
);

-- 10. ITENS DA VENDA
CREATE TABLE public.itens_venda (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    venda_id uuid REFERENCES public.vendas(id),
    produto_id uuid REFERENCES public.produtos(id),
    quantidade numeric NOT NULL,
    preco_unitario numeric NOT NULL,
    subtotal numeric NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);
/* fim de criacao_tabelas_produtos_vendas */

/* inicio de criacao_tabelas_financeiras */
-- 11. FINANÇAS
CREATE TABLE public.financas (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid DEFAULT auth.uid() REFERENCES auth.users(id),
    entidade_id bigint REFERENCES public.entidades(id),
    descricao text NOT NULL, valor_total numeric NOT NULL,
    tipo text CHECK (tipo = ANY (ARRAY['receita', 'despesa'])),
    num_parcelas integer DEFAULT 1,
    categoria text DEFAULT 'Geral',
    status_lancamento text DEFAULT 'aberto' CHECK (status_lancamento = ANY (ARRAY['aberto', 'finalizado', 'cancelado'])),
    created_at timestamp with time zone DEFAULT now()
);

-- 12. PARCELAS
CREATE TABLE public.parcelas (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    financa_id uuid REFERENCES public.financas(id),
    num_parcela integer NOT NULL, valor_parcela numeric NOT NULL,
    data_vencimento date NOT NULL, data_pagamento date,
    status text DEFAULT 'pendente' CHECK (status = ANY (ARRAY['pendente', 'pago', 'atrasado'])),
    codigo_barra text, boleto_url text, comprovante_url text,
    created_at timestamp with time zone DEFAULT now()
);
/* fim de criacao_tabelas_financeiras */


```
# tregges
```

/* inicio de trigger_novo_usuario */
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
    INSERT INTO public.entidades (user_id, nome_completo, avatar_url, bio)
    VALUES (
        new.id,
        coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
        new.raw_user_meta_data->>'avatar_url',
        NULL
    );
    RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
/* fim de trigger_novo_usuario */

/* inicio de trigger_auditoria_produtos */
CREATE OR REPLACE FUNCTION public.registrar_auditoria()
RETURNS trigger SECURITY DEFINER LANGUAGE plpgsql AS $$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO public.auditoria_produtos (produto_id, acao, dados_antigos, usuario_id)
        VALUES (OLD.id, 'DELETE', row_to_json(OLD)::jsonb, auth.uid());
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO public.auditoria_produtos (produto_id, acao, dados_antigos, dados_novos, usuario_id)
        VALUES (NEW.id, 'UPDATE', row_to_json(OLD)::jsonb, row_to_json(NEW)::jsonb, auth.uid());
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO public.auditoria_produtos (produto_id, acao, dados_novos, usuario_id)
        VALUES (NEW.id, 'INSERT', row_to_json(NEW)::jsonb, auth.uid());
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trigger_auditoria_produtos ON public.produtos;
CREATE TRIGGER trigger_auditoria_produtos AFTER INSERT OR UPDATE OR DELETE ON public.produtos
FOR EACH ROW EXECUTE FUNCTION public.registrar_auditoria();
/* fim de trigger_auditoria_produtos */

/* inicio de trigger_baixa_estoque */
CREATE OR REPLACE FUNCTION public.handle_item_venda_inserido()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
    v_user_id uuid;
BEGIN
    UPDATE public.produtos SET quantidade = quantidade - NEW.quantidade WHERE id = NEW.produto_id;
    SELECT user_id INTO v_user_id FROM public.vendas WHERE id = NEW.venda_id;
    
    INSERT INTO public.movimentacoes_estoque (user_id, produto_id, tipo, quantidade, motivo)
    VALUES (coalesce(v_user_id, auth.uid()), NEW.produto_id, 'saida', NEW.quantidade, 'venda');
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_item_venda_inserted ON public.itens_venda;
CREATE TRIGGER on_item_venda_inserted AFTER INSERT ON public.itens_venda
FOR EACH ROW EXECUTE FUNCTION public.handle_item_venda_inserido();
/* fim de trigger_baixa_estoque */

/* inicio de trigger_lancamento_financeiro */
CREATE OR REPLACE FUNCTION public.handle_venda_concluida()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
    IF NEW.status = 'concluida' AND (TG_OP = 'INSERT' OR OLD.status <> 'concluida') THEN
        INSERT INTO public.financas (user_id, entidade_id, descricao, valor_total, tipo, categoria, status_lancamento)
        VALUES (
            NEW.user_id, NEW.entidade_id, 
            'Venda PDV #' || substr(NEW.id::text, 1, 8), 
            NEW.valor_total, 'receita', 'Vendas', 'finalizado'
        );
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_venda_concluida ON public.vendas;
CREATE TRIGGER on_venda_concluida AFTER INSERT OR UPDATE ON public.vendas
FOR EACH ROW EXECUTE FUNCTION public.handle_venda_concluida();
/* fim de trigger_lancamento_financeiro */

/* inicio de event_trigger_rls */
CREATE OR REPLACE FUNCTION public.rls_auto_enable_procedure()
RETURNS event_trigger LANGUAGE plpgsql AS $$
DECLARE cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands() WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO') AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
      EXCEPTION WHEN OTHERS THEN RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     END IF;
  END LOOP;
END;
$$;

DROP EVENT TRIGGER IF EXISTS rls_auto_enable;
CREATE EVENT TRIGGER rls_auto_enable ON ddl_command_end
WHEN TAG IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO') EXECUTE FUNCTION public.rls_auto_enable_procedure();
/* fim de event_trigger_rls */

```
# RLS
```
/* inicio de rls_geral_saas */
-- 1. Habilitar segurança em todas as tabelas operacionais
ALTER TABLE public.entidades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categorias ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.servicos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favoritos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.avaliacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.auditoria_produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.movimentacoes_estoque ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itens_venda ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parcelas ENABLE ROW LEVEL SECURITY;

-- 2. Limpar políticas antigas (prevenção de erros caso rode o script duas vezes)
DROP POLICY IF EXISTS "Entidade Privada" ON public.entidades;
DROP POLICY IF EXISTS "Leitura Categorias" ON public.categorias;
DROP POLICY IF EXISTS "Produtos Privados" ON public.produtos;
DROP POLICY IF EXISTS "Movimentacoes Privadas" ON public.movimentacoes_estoque;
DROP POLICY IF EXISTS "Vendas Privadas" ON public.vendas;
DROP POLICY IF EXISTS "Financas Privadas" ON public.financas;
DROP POLICY IF EXISTS "Itens Venda Privados" ON public.itens_venda;
DROP POLICY IF EXISTS "Parcelas Privadas" ON public.parcelas;

-- 3. Criar Políticas de Isolamento (O usuário só vê e edita onde user_id = id dele)
CREATE POLICY "Entidade Privada" ON public.entidades FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "Leitura Categorias" ON public.categorias FOR SELECT TO authenticated USING (true); -- Categorias geralmente são globais/públicas para leitura

CREATE POLICY "Produtos Privados" ON public.produtos FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "Movimentacoes Privadas" ON public.movimentacoes_estoque FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "Vendas Privadas" ON public.vendas FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "Financas Privadas" ON public.financas FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- 4. Tabelas Filhas (Herdam a permissão verificando a tabela "mãe")
CREATE POLICY "Itens Venda Privados" ON public.itens_venda FOR ALL TO authenticated 
USING (venda_id IN (SELECT id FROM public.vendas WHERE user_id = auth.uid())) 
WITH CHECK (venda_id IN (SELECT id FROM public.vendas WHERE user_id = auth.uid()));

CREATE POLICY "Parcelas Privadas" ON public.parcelas FOR ALL TO authenticated 
USING (financa_id IN (SELECT id FROM public.financas WHERE user_id = auth.uid())) 
WITH CHECK (financa_id IN (SELECT id FROM public.financas WHERE user_id = auth.uid()));
/* fim de rls_geral_saas */


/* inicio de rpc_produtos_saas */
-- Função blindada para adicionar produto, garantindo que pertence a quem chamou a função (auth.uid())
CREATE OR REPLACE FUNCTION public.adicionar_produto_seguro(
    p_nome text, p_preco numeric, p_foto_url text DEFAULT NULL, p_codigo_produto text DEFAULT NULL,
    p_ean text DEFAULT NULL, p_ncm text DEFAULT NULL, p_cest text DEFAULT NULL, p_cfop text DEFAULT NULL,
    p_unidade_comercial text DEFAULT NULL, p_quantidade numeric DEFAULT 0, p_valor_total numeric DEFAULT 0,
    p_fornecedor text DEFAULT NULL, p_preco_custo numeric DEFAULT 0, p_estoque_minimo numeric DEFAULT 5,
    p_origem text DEFAULT NULL, p_local_estoque text DEFAULT NULL, p_local_loja text DEFAULT NULL,
    p_tipo_embalagem text DEFAULT NULL, p_categoria text DEFAULT 'Geral', p_peso_liquido numeric DEFAULT 0,
    p_dimensoes text DEFAULT NULL
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE 
    v_novo_id uuid;
BEGIN
    IF p_nome IS NULL OR length(trim(p_nome)) < 3 THEN
        RAISE EXCEPTION 'Erro de Segurança: O nome do produto deve ter pelo menos 3 caracteres.';
    END IF;

    INSERT INTO public.produtos (
        user_id, nome, preco, foto_url, codigo_produto, ean, ncm, cest, cfop, unidade_comercial, quantidade, valor_total,
        fornecedor, preco_custo, estoque_minimo, origem, local_estoque, local_loja, tipo_embalagem, categoria,
        peso_liquido, dimensoes, esta_ativo
    ) VALUES (
        auth.uid(), trim(p_nome), p_preco, p_foto_url, p_codigo_produto, p_ean, p_ncm, p_cest, p_cfop, p_unidade_comercial, p_quantidade, p_valor_total,
        p_fornecedor, p_preco_custo, p_estoque_minimo, p_origem, p_local_estoque, p_local_loja, p_tipo_embalagem, p_categoria,
        p_peso_liquido, p_dimensoes, true
    ) RETURNING id INTO v_novo_id;
    
    RETURN v_novo_id;
END;
$$;

-- Função blindada para atualizar, garantindo que o produto sendo alterado pertença ao usuário logado
CREATE OR REPLACE FUNCTION public.atualizar_produto_seguro(
    p_id uuid, p_nome text, p_preco numeric, p_foto_url text DEFAULT NULL, p_codigo_produto text DEFAULT NULL,
    p_ean text DEFAULT NULL, p_ncm text DEFAULT NULL, p_cest text DEFAULT NULL, p_cfop text DEFAULT NULL,
    p_unidade_comercial text DEFAULT NULL, p_quantidade numeric DEFAULT 0, p_valor_total numeric DEFAULT 0,
    p_fornecedor text DEFAULT NULL, p_preco_custo numeric DEFAULT 0, p_estoque_minimo numeric DEFAULT 5,
    p_origem text DEFAULT NULL, p_local_estoque text DEFAULT NULL, p_local_loja text DEFAULT NULL,
    p_tipo_embalagem text DEFAULT NULL, p_categoria text DEFAULT 'Geral', p_peso_liquido numeric DEFAULT 0,
    p_dimensoes text DEFAULT NULL
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    IF p_nome IS NULL OR length(trim(p_nome)) < 3 THEN
        RAISE EXCEPTION 'Erro de Segurança: O nome do produto deve ter pelo menos 3 caracteres.';
    END IF;

    UPDATE public.produtos SET 
        nome = trim(p_nome), preco = p_preco, foto_url = p_foto_url, codigo_produto = p_codigo_produto,
        ean = p_ean, ncm = p_ncm, cest = p_cest, cfop = p_cfop, unidade_comercial = p_unidade_comercial,
        quantidade = p_quantidade, valor_total = p_valor_total, fornecedor = p_fornecedor, preco_custo = p_preco_custo,
        estoque_minimo = p_estoque_minimo, origem = p_origem, local_estoque = p_local_estoque, local_loja = p_local_loja,
        tipo_embalagem = p_tipo_embalagem, categoria = p_categoria, peso_liquido = p_peso_liquido, dimensoes = p_dimensoes
    WHERE id = p_id AND user_id = auth.uid() AND esta_ativo = true;
END;
$$;

-- Desativar de forma segura garantindo a posse
CREATE OR REPLACE FUNCTION public.desativar_produto_seguro(p_id uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    UPDATE public.produtos SET esta_ativo = false WHERE id = p_id AND user_id = auth.uid();
END;
$$;

-- Atualizar cache do Supabase
NOTIFY pgrst, 'reload schema';
/* fim de rpc_produtos_saas */
```


