
/* inicio de variaveis_globais */
// Conectamos o JavaScript aos elementos HTML através dos seus IDs
const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendButton = document.getElementById('send-button');
/* fim de variaveis_globais */



/* inicio de funcao_adicionar_mensagem */
// Função responsável por criar o balão de mensagem visualmente na tela
function addMessage(text, sender) {
    // 1. Cria um novo elemento HTML do tipo <div> na memória
    const messageDiv = document.createElement('div');
    
    // 2. Adiciona as classes CSS. 'message' dá o formato de balão, 
    // e 'sender' define se é 'received' (branco, esquerda) ou 'sent' (verde, direita)
    messageDiv.classList.add('message', sender);
    
    // 3. Insere o texto passado como parâmetro dentro do balão
    messageDiv.innerText = text;

    // 4. Injeta a div recém-criada dentro do container principal de mensagens
    chatMessages.appendChild(messageDiv);
    
    // 5. Rola a barra lateral automaticamente para baixo para sempre mostrar a última mensagem
    chatMessages.scrollTop = chatMessages.scrollHeight;
}
/* fim de funcao_adicionar_mensagem */



/* inicio de logica_menu_inicial */
// Atualizamos o texto com os novos 4 módulos principais do sistema
const menuInicial = `Olá, aristidesbp! Bem-vindo ao sistema.
Por favor, digite o número da opção desejada:
1 - Entidades (Controle de cadastros)
2 - Produtos (Controle de Estoque)
3 - Financeiro (Controle de Entradas e Saidas)
4 - Catalogo de produtos (Pdv)`;

// Assim que o script carrega, exibimos o novo menu
addMessage(menuInicial, 'received');
/* fim de logica_menu_inicial */

/* inicio_importacao_config */
// Importa o nosso cliente configurado do Supabase
import { supabase } from './supabase_config.js';
/* /fim_importacao_config */


/* inicio de logica_processamento */
// Função que captura o envio e decide o que responder
function handleSend() {
    const text = userInput.value.trim();
    if (text === '') return;

    // Renderiza a mensagem enviada pelo usuário
    addMessage(text, 'sent');
    userInput.value = '';

    // Simulamos o robô "digitando" por meio segundo
    setTimeout(() => {
        // Atualizamos os retornos de acordo com o novo menu
        if (text === '1') {
            addMessage('Você escolheu: 1 - Entidades. (Módulo em construção...)', 'received');
        } else if (text === '2') {
            addMessage('Você escolheu: 2 - Produtos. (Módulo em construção...)', 'received');
        } else if (text === '3') {
            addMessage('Você escolheu: 3 - Financeiro. (Módulo em construção...)', 'received');
        } else if (text === '4') {
            addMessage('Você escolheu: 4 - Catalogo de produtos. (Módulo em construção...)', 'received');
        } else {
            // Se o usuário digitar algo diferente de 1, 2, 3 ou 4
            addMessage('Opção inválida. Por favor, digite um número de 1 a 4.', 'received');
            addMessage(menuInicial, 'received');
        }
    }, 500);
}
/* fim de logica_processamento */







/* inicio de eventos_clique_teclado */
// Ouve o clique do mouse no botão de enviar e dispara a função handleSend
sendButton.addEventListener('click', handleSend);

// Ouve o teclado no campo de texto. Se a tecla pressionada for 'Enter', dispara a função
userInput.addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        handleSend();
    }
});
/* fim de eventos_clique_teclado */
