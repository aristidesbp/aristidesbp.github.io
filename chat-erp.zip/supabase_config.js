/* inicio de importacao_biblioteca_supabase */
// Importa o cliente do Supabase através de um CDN oficial (versão 2)
// Isso permite que o navegador reconheça o objeto global 'supabase'
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';
/* fim de importacao_biblioteca_supabase */

/* inicio de credenciais_projeto */
// Suas credenciais oficiais fornecidas do projeto no Supabase
const SUPABASE_URL = 'https://ynuigtupmaucawcybage.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InludWlndHVwbWF1Y2F3Y3liYWdlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODgyMzczMDYsImV4cCI6MjEwMzgxMzMwNn0.56L06LlozaU3roVhkkfFCYhfcbzqt0hsUobmjeML-lg';
/* fim de credenciais_projeto */

/* inicio de criacao_conexao */
// Inicializa e exporta o cliente do Supabase para uso em todo o sistema
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
/* fim de criacao_conexao */
