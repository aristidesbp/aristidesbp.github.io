// main.js - JavaScript modular básico
document.addEventListener("DOMContentLoaded", () => {
  console.log("Página carregada com sucesso!"); // Confirma o carregamento do DOM
});
