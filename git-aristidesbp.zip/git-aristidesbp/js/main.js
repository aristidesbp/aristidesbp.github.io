// Função que toca o som e faz scroll suave até a seção com id="video"
function playSoundAndScroll() {
  const audio = document.getElementById('clickSound'); // Elemento de áudio

  if (audio) {
    audio.currentTime = 0; // Reinicia o som
    audio.play().catch(error => {
      console.warn("O áudio não pôde ser reproduzido automaticamente:", error); // Captura erro de autoplay
    });
  }

  // Localiza a seção de vídeo e aplica rolagem suave
  const videoSection = document.querySelector('#video');
  if (videoSection) {
    videoSection.scrollIntoView({ behavior: 'smooth' });
  }
}