 /* ============ CONFIGURAÇÕES INICIAIS ================= */
         
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRianFvYnJ1YWp0YnZqdWp5andpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM2OTkyODcsImV4cCI6MjEwOTI3NTI4N30.EKM0j9ErGaLGOIIvuzFCezlhftx3N1wVTLWcC3MckG8';
        
const SUPABASE_URL = 'https://tbjqobruajtbvjujyjwi.supabase.co';

const clienteSupabase = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
