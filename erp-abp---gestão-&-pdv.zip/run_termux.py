#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de Inicialização para Android Termux
Detecta e instala automaticamente Node.js via pkg se necessário, instala dependências npm e roda o servidor em http://localhost:3000
"""

import os
import sys
import shutil
import subprocess

# Cores para o Termux
GREEN = "\033[92m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
RED = "\033[91m"
BOLD = "\033[1m"
RESET = "\033[0m"

def print_banner():
    print(f"{CYAN}{BOLD}")
    print("=" * 60)
    print("         📱 INICIALIZADOR ERP_ABP - ANDROID TERMUX         ")
    print("=" * 60)
    print(f"{RESET}")

def check_and_install_termux_packages():
    print(f"{CYAN} Verificando ambiente Termux...{RESET}")
    node_path = shutil.which("node")

    if not node_path:
        print(f"{YELLOW} Node.js não instalado. Tentando instalar automaticamente via 'pkg install nodejs'...{RESET}")
        try:
            subprocess.run(["pkg", "update", "-y"], check=False)
            subprocess.run(["pkg", "install", "nodejs-lts", "-y"], check=True)
            print(f"{GREEN}✓ Node.js instalado no Termux com sucesso!{RESET}")
        except Exception:
            try:
                subprocess.run(["pkg", "install", "nodejs", "-y"], check=True)
                print(f"{GREEN}✓ Node.js instalado no Termux com sucesso!{RESET}")
            except Exception as e:
                print(f"{RED}❌ Não foi possível instalar o Node.js automaticamente: {e}{RESET}")
                print(f"{YELLOW}Por favor, execute manualmente no Termux: pkg install nodejs{RESET}")
                sys.exit(1)
    else:
        node_ver = subprocess.check_output(["node", "-v"]).decode().strip()
        print(f"{GREEN}✓ Node.js verificado no Termux ({node_ver}){RESET}")

def install_dependencies():
    project_dir = os.path.dirname(os.path.abspath(__file__))
    node_modules = os.path.join(project_dir, "node_modules")

    if not os.path.exists(node_modules):
        print(f"\n{YELLOW}📦 Instalando dependências npm no Termux...{RESET}")
        try:
            subprocess.run(["npm", "install"], cwd=project_dir, check=True)
            print(f"{GREEN}✓ Dependências instaladas com sucesso!{RESET}")
        except subprocess.CalledProcessError as e:
            print(f"{RED}❌ Erro na instalação das dependências: {e}{RESET}")
            sys.exit(1)
    else:
        print(f"{GREEN}✓ Pastas de dependências (node_modules) já configurada.{RESET}")

def run_dev_server():
    project_dir = os.path.dirname(os.path.abspath(__file__))
    
    print(f"\n{GREEN}{BOLD}🚀 Servidor ERP_ABP ativado no Termux!{RESET}")
    print(f"{GREEN}{BOLD}👉 Acesse no seu navegador Android: http://localhost:3000 ou http://127.0.0.1:3000{RESET}")
    print(f"{CYAN}Pressione Ctrl+C para parar o servidor.{RESET}\n")

    try:
        subprocess.run(["npm", "run", "dev"], cwd=project_dir)
    except KeyboardInterrupt:
        print(f"\n{YELLOW}🛑 Servidor encerrado.{RESET}")
        sys.exit(0)

if __name__ == "__main__":
    print_banner()
    check_and_install_termux_packages()
    install_dependencies()
    run_dev_server()
