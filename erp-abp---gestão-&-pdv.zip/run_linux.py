#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script de Inicialização para Linux (Ubuntu/Debian/Fedora/Arch)
Executa a instalação de dependências npm e inicia o servidor ERP_ABP na porta 3000.
"""

import os
import sys
import shutil
import subprocess
import time
import webbrowser

# Cores para o Terminal Linux
GREEN = "\033[92m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
RED = "\033[91m"
BOLD = "\033[1m"
RESET = "\033[0m"

def print_banner():
    print(f"{CYAN}{BOLD}")
    print("=" * 60)
    print("          🚀 INICIALIZADOR ERP_ABP - LINUX          ")
    print("=" * 60)
    print(f"{RESET}")

def check_node():
    node_path = shutil.which("node")
    npm_path = shutil.which("npm")

    if not node_path or not npm_path:
        print(f"{RED}{BOLD}❌ Node.js ou NPM não foram encontrados no sistema.{RESET}")
        print(f"{YELLOW}Para instalar no Ubuntu/Debian, execute:{RESET}")
        print("  sudo apt update && sudo apt install -y nodejs npm\n")
        print(f"{YELLOW}Para instalar no Fedora, execute:{RESET}")
        print("  sudo dnf install -y nodejs npm\n")
        print(f"{YELLOW}Para instalar no Arch Linux, execute:{RESET}")
        print("  sudo pacman -S nodejs npm\n")
        sys.exit(1)

    node_ver = subprocess.check_output(["node", "-v"]).decode().strip()
    npm_ver = subprocess.check_output(["npm", "-v"]).decode().strip()
    print(f"{GREEN}✓ Node.js detectado ({node_ver}){RESET}")
    print(f"{GREEN}✓ NPM detectado ({npm_ver}){RESET}")

def install_dependencies():
    project_dir = os.path.dirname(os.path.abspath(__file__))
    node_modules = os.path.join(project_dir, "node_modules")

    if not os.path.exists(node_modules):
        print(f"\n{YELLOW}📦 Diretório node_modules não encontrado. Instalando dependências...{RESET}")
        try:
            subprocess.run(["npm", "install"], cwd=project_dir, check=True)
            print(f"{GREEN}✓ Dependências instaladas com sucesso!{RESET}")
        except subprocess.CalledProcessError as e:
            print(f"{RED}❌ Erro ao executar 'npm install': {e}{RESET}")
            sys.exit(1)
    else:
        print(f"{GREEN}✓ Dependências do projeto já estão instaladas (node_modules presente).{RESET}")

def run_dev_server():
    project_dir = os.path.dirname(os.path.abspath(__file__))
    url = "http://localhost:3000"

    print(f"\n{GREEN}{BOLD}⚡ Iniciando servidor Web em {url}...{RESET}")
    print(f"{CYAN}Pressione Ctrl+C para encerrar o servidor.{RESET}\n")

    # Tenta abrir o navegador após 2 segundos
    def open_browser():
        time.sleep(2)
        try:
            webbrowser.open(url)
        except Exception:
            pass

    try:
        import threading
        threading.Thread(target=open_browser, daemon=True).start()

        # Executa npm run dev
        subprocess.run(["npm", "run", "dev"], cwd=project_dir)
    except KeyboardInterrupt:
        print(f"\n{YELLOW}🛑 Servidor encerrado pelo usuário.{RESET}")
        sys.exit(0)

if __name__ == "__main__":
    print_banner()
    check_node()
    install_dependencies()
    run_dev_server()
