# 🗺️ Tutorial & Mapa do Sistema ERP_ABP

Este documento serve como o **Guia Arquitetural e Mapa de Desenvolvimento** do **ERP_ABP**. Utilize este manual para entender a estrutura dos arquivos, as regras de negócio aplicadas e como modificar qualquer parte da aplicação com segurança.

---

## 📌 Sumário
1. [Visão Geral & Filosofia](#1-visão-geral--filosofia)
2. [Arquitetura & Estrutura de Pastas](#2-arquitetura--estrutura-de-pastas)
3. [Regras de Negócio por Módulo](#3-regras-de-negócio-por-módulo)
   - [Frente de Caixa (PDV)](#31-frente-de-caixa-pdv)
   - [Estoque & Produtos](#32-estoque--produtos)
   - [Controle Financeiro & Parcelamentos](#33-controle-financeiro--parcelamentos)
   - [Entidades (Clientes/Fornecedores)](#34-entidades-clientesfornecedores)
   - [Motor de Persistência Híbrido](#35-motor-de-persistência-híbrido-supabase--localstorage)
4. [Configuração do Banco de Dados (Supabase)](#4-configuração-do-banco-de-dados-supabase)
5. [Guia Prático de Alterações & Manutenção](#5-guia-prático-de-alterações--manutenção)

---

## 1. Visão Geral & Filosofia

O **ERP_ABP** foi projetado para ser um sistema de gestão empresarial completo, intuitivo e com **alta resiliência**.

- **Offline-First com Nuvem:** Toda operação lê e grava prioritariamente no **Supabase** (PostgreSQL na nuvem). Se a conexão estiver indisponível ou faltarem tabelas configuradas, o sistema usa **LocalStorage** como fallback transparente, evitando que o caixa pare.
- **Visual Responsivo & Escuro/Claro:** Desenvolvido com Tailwind CSS, com suporte completo a Modo Escuro/Claro e atalhos de teclado para PDV.

---

## 2. Arquitetura & Estrutura de Pastas

```
├── .env.example                 # Exemplo de variáveis de ambiente (URL Supabase e Keys)
├── metadata.json                # Configurações do Applet (nome, descrição, permissões)
├── package.json                 # Dependências e scripts do Node/Vite
├── tutorial.md                  # Este guia do desenvolvedor
│
├── src/
│   ├── main.tsx                 # Ponto de entrada do React 18
│   ├── App.tsx                  # Componente Raiz, Roteamento das Abas e Estado Global
│   ├── index.css                # Estilos globais e importações do Tailwind CSS
│   │
│   ├── types/
│   │   └── erp.ts               # Interfaces TypeScript (Produto, Entidade, Financa, Venda, Parcela)
│   │
│   ├── lib/
│   │   ├── supabase.ts          # Inicialização dinâmica do cliente Supabase (Suporta credenciais salvas)
│   │   └── storage.ts           # Motor de persistência híbrido (Supabase + LocalStorage Fallback)
│   │
│   ├── components/
│   │   ├── Header.tsx           # Barra superior com busca, perfil, modo escuro e saudações
│   │   ├── Sidebar.tsx          # Menu de navegação lateral com ícones e marcadores
│   │   ├── LoginModal.tsx       # Modal de autenticação/acesso ao sistema
│   │   ├── BarcodeScannerModal.tsx # Leitor de código de barras via câmera (HTML5 Video)
│   │   └── ThermalReceipt.tsx   # Componente de Cupom Térmico (58mm/80mm) pronto para impressão
│   │
│   └── views/
│       ├── WelcomeView.tsx      # Dashboard Inicial (Métricas do dia, gráficos e ações rápidas)
│       ├── PdvView.tsx          # Frente de Caixa, Sangria e Histórico de Vendas
│       ├── EstoqueView.tsx      # Catálogo de Produtos, Importador de XML de NFe e Margem %
│       ├── FinanceiroView.tsx   # Contas a Pagar/Receber, Parcelamento 48x e Carnê de Pagamento
│       ├── EntidadesView.tsx    # Cadastro de Clientes/Fornecedores com busca por CEP
│       ├── ConfiguracoesView.tsx # Permissões de Câmera, Diretório, Credenciais Supabase e Backup JSON
│       └── DocumentacaoView.tsx # Manual interativo no sistema com script SQL do Supabase
```

---

## 3. Regras de Negócio por Módulo

### 3.1. Frente de Caixa (PDV)
- **Local:** `src/views/PdvView.tsx`
- **Regras Principais:**
  - **Bipar Produto:** Pesquisa por código de barras exato (`codigo_barras`) ou nome parcial.
  - **Atalho F8:** Executa a finalização da venda de forma instantânea.
  - **Estoque Automático:** Ao confirmar uma venda, a quantidade vendida é subtraída do estoque do produto.
  - **Lançamento Financeiro Automático:** Cada venda finalizada gera automaticamente uma **Receita Pago** no módulo financeiro.
  - **Sangria de Caixa:** Lança uma retirada de dinheiro informando o motivo, que registra automaticamente uma **Despesa Pago** no financeiro.
  - **Cupom Térmico:** Formatação otimizada para impressoras térmicas não-fiscais (58mm / 80mm).

---

### 3.2. Estoque & Produtos
- **Local:** `src/views/EstoqueView.tsx`
- **Regras Principais:**
  - **Importação XML NFe:** Utiliza o `DOMParser` para ler arquivos `.xml` de NFe/DANFE, extraindo nome do produto, código EAN (`cEAN`), quantidade comercial (`qCom`) e valor unitário (`vUnCom`), cadastrando os itens no estoque automaticamente.
  - **Cálculo de Margem:** `Margem (%) = ((Preço Venda - Preço Custo) / Preço Custo) * 100`.
  - **Estoque Crítico:** Destaque visual caso `quantidade_estoque <= estoque_minimo`.

---

### 3.3. Controle Financeiro & Parcelamentos
- **Local:** `src/views/FinanceiroView.tsx`
- **Regras Principais:**
  - **Tipos:** *Receita* (Entradas) e *Despesa* (Saídas).
  - **Parcelamento:** Permite dividir qualquer lançamento em até 48 parcelas. As datas de vencimento são geradas mensalmente a partir da data de vencimento inicial.
  - **Baixa de Parcela:** É possível dar baixa individualmente em cada parcela.
  - **Carnê de Pagamento:** Gera a visualização e impressão de carnês de cobrança por parcela ou lote.

---

### 3.4. Entidades (Clientes/Fornecedores)
- **Local:** `src/views/EntidadesView.tsx`
- **Regras Principais:**
  - **Tipos de Entidade:** *Cliente*, *Fornecedor* ou *Colaborador*.
  - **Consulta CEP Automática:** Consulta a API pública ViaCEP (`viacep.com.br/ws/{cep}/json/`) ao digitar o CEP, preenchendo automaticamente logradouro, bairro, cidade e estado.
  - **Validação:** Formatação automática e máscaras de CPF/CNPJ e Telefone.

---

### 3.5. Motor de Persistência Híbrido (Supabase + LocalStorage)
- **Local:** `src/lib/storage.ts` e `src/lib/supabase.ts`
- **Regras Principais:**
  - O arquivo `storage.ts` é o **único ponto de contato com os dados**.
  - Sempre que um método como `saveProduto()` ou `registerVenda()` é chamado:
    1. Tenta salvar no **Supabase** via REST API/Client.
    2. Sincroniza e espelha a versão no **LocalStorage** para consulta offline imediata.
    3. Se o Supabase apresentar erro ou faltarem credenciais/tabelas, o erro é capturado e os dados mantidos no LocalStorage sem travar a interface.

---

## 4. Configuração do Banco de Dados (Supabase)

Caso deseje criar ou resetar as tabelas no seu projeto do Supabase, acesse o painel **Supabase > SQL Editor** e execute o código abaixo:

```sql
-- 1. TABELA DE ENTIDADES
CREATE TABLE IF NOT EXISTS public.entidades (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nome_completo TEXT NOT NULL,
  tipo TEXT CHECK (tipo IN ('Cliente', 'Fornecedor', 'Colaborador')),
  documento TEXT,
  email TEXT,
  telefone TEXT,
  cep TEXT,
  logradouro TEXT,
  numero TEXT,
  bairro TEXT,
  cidade TEXT,
  estado TEXT,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. TABELA DE PRODUTOS
CREATE TABLE IF NOT EXISTS public.produtos (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  codigo_barras TEXT UNIQUE,
  nome TEXT NOT NULL,
  categoria TEXT,
  preco_custo NUMERIC(10,2) DEFAULT 0.00,
  preco_venda NUMERIC(10,2) DEFAULT 0.00,
  quantidade_estoque INTEGER DEFAULT 0,
  estoque_minimo INTEGER DEFAULT 5,
  unidade TEXT DEFAULT 'UN',
  imagem_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. TABELA DE FINANÇAS
CREATE TABLE IF NOT EXISTS public.financas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  descricao TEXT NOT NULL,
  tipo TEXT CHECK (tipo IN ('Receita', 'Despesa')),
  valor_total NUMERIC(10,2) NOT NULL,
  numero_parcelas INTEGER DEFAULT 1,
  entidade_id UUID REFERENCES public.entidades(id) ON DELETE SET NULL,
  categoria TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. TABELA DE PARCELAS
CREATE TABLE IF NOT EXISTS public.parcelas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  financa_id UUID REFERENCES public.financas(id) ON DELETE CASCADE,
  numero_parcela INTEGER NOT NULL,
  valor_parcela NUMERIC(10,2) NOT NULL,
  data_vencimento DATE NOT NULL,
  data_pagamento TIMESTAMP WITH TIME ZONE,
  status TEXT DEFAULT 'Pendente' CHECK (status IN ('Pendente', 'Pago', 'Atrasado')),
  forma_pagamento TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. TABELA DE VENDAS
CREATE TABLE IF NOT EXISTS public.vendas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  cliente_id UUID REFERENCES public.entidades(id) ON DELETE SET NULL,
  valor_total NUMERIC(10,2) NOT NULL,
  desconto NUMERIC(10,2) DEFAULT 0.00,
  forma_pagamento TEXT NOT NULL,
  cupom_html TEXT,
  items JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- HABILITAR SEGURANÇA RLS
ALTER TABLE public.entidades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.financas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parcelas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendas ENABLE ROW LEVEL SECURITY;

-- POLITICAS DE ACESSO
CREATE POLICY "Acesso Publico Entidades" ON public.entidades FOR ALL USING (true);
CREATE POLICY "Acesso Publico Produtos" ON public.produtos FOR ALL USING (true);
CREATE POLICY "Acesso Publico Financas" ON public.financas FOR ALL USING (true);
CREATE POLICY "Acesso Publico Parcelas" ON public.parcelas FOR ALL USING (true);
CREATE POLICY "Acesso Publico Vendas" ON public.vendas FOR ALL USING (true);
```

---

## 5. Guia Prático de Alterações & Manutenção

| Se você deseja... | Arquivo a modificar | Dica de Implementação |
| :--- | :--- | :--- |
| **Adicionar uma nova aba/tela** | `src/components/Sidebar.tsx` e `src/App.tsx` | Adicione o tipo em `ActiveTab` e monte a nova view em `src/views/`. |
| **Adicionar novos campos ao produto** | `src/types/erp.ts` e `src/views/EstoqueView.tsx` | Adicione a propriedade na interface `Produto` e crie o input no formulário de modal. |
| **Alterar layout do Cupom de Venda** | `src/components/ThermalReceipt.tsx` e `PdvView.tsx` | Edite o HTML/JSX que gera o comprovante para impressoras de 58mm/80mm. |
| **Trocar as credenciais do Supabase** | `src/lib/supabase.ts` ou aba **Configurações** no App | As variáveis podem ser definidas em `.env` ou direto na aba de Configurações da aplicação. |
| **Modificar regras de parcelamento** | `src/lib/storage.ts` (`saveLancamentoFinanceiro`) | Altere a lógica que gera as datas e parcelas dentro da função. |

---

## 6. Como Executar via Terminal Python (Linux & Termux)

Para facilitar a inicialização do projeto em qualquer ambiente, foram disponibilizados **dois scripts Python** na raiz do projeto:

### 🐧 Para Terminal Linux (Ubuntu, Debian, Fedora, Arch, etc.)
Execute no terminal:
```bash
python3 run_linux.py
```
* O script verifica o `node` e `npm`, instala as dependências automaticamente se necessário e ativa o servidor em `http://localhost:3000`.

### 📱 Para Android Termux
Execute no terminal do Termux:
```bash
python3 run_termux.py
```
* O script instala o `nodejs` via `pkg` (se não estiver instalado), baixa as dependências npm e roda o servidor em `http://localhost:3000` (ou `http://127.0.0.1:3000`).

---

*Documentação gerada para o sistema **ERP_ABP**.*
