import React, { useState, useEffect } from 'react';
import { storageService } from './lib/storage';
import { Entidade, Produto, Financa, Parcela, Venda } from './types/erp';
import { Header } from './components/Header';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { LoginModal } from './components/LoginModal';

import { WelcomeView } from './views/WelcomeView';
import { EntidadesView } from './views/EntidadesView';
import { EstoqueView } from './views/EstoqueView';
import { FinanceiroView } from './views/FinanceiroView';
import { PdvView } from './views/PdvView';
import { ConfiguracoesView } from './views/ConfiguracoesView';
import { DocumentacaoView } from './views/DocumentacaoView';

export default function App() {
  const [user, setUser] = useState<{ id: string; email: string; name: string } | null>({
    id: 'usr_aristides',
    email: 'aristidesbp@gmail.com',
    name: 'Aristides BP'
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('bem_vindo');
  const [isOpenMobileSidebar, setIsOpenMobileSidebar] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return (
      localStorage.getItem('theme') === 'dark' ||
      window.matchMedia('(prefers-color-scheme: dark)').matches
    );
  });
  const [globalSearchTerm, setGlobalSearchTerm] = useState('');

  // ERP State Collections
  const [entidades, setEntidades] = useState<Entidade[]>([]);
  const [produtos, setProdutos] = useState<Produto[]>([]);
  const [financas, setFinancas] = useState<Financa[]>([]);
  const [parcelas, setParcelas] = useState<Parcela[]>([]);
  const [vendas, setVendas] = useState<Venda[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Apply dark mode class to html document
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  // Load Initial ERP Data
  const reloadData = async () => {
    setIsLoading(true);
    try {
      const entData = await storageService.getEntidades();
      setEntidades(entData);

      const prodData = await storageService.getProdutos();
      setProdutos(prodData);

      const { financas: finData, parcelas: parData } = await storageService.getFinancasWithParcelas();
      setFinancas(finData);
      setParcelas(parData);

      const vendData = await storageService.getVendas();
      setVendas(vendData);
    } catch (err) {
      console.warn('Error reloading data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    reloadData();
  }, []);

  // Handlers for Entidades
  const handleSaveEntidade = async (entData: Partial<Entidade>) => {
    await storageService.saveEntidade(entData);
    await reloadData();
  };

  const handleDeleteEntidades = async (ids: string[]) => {
    await storageService.deleteEntidades(ids);
    await reloadData();
  };

  // Handlers for Produtos
  const handleSaveProduto = async (prodData: Partial<Produto>) => {
    await storageService.saveProduto(prodData);
    await reloadData();
  };

  const handleDeleteProdutos = async (ids: string[]) => {
    await storageService.deleteProdutos(ids);
    await reloadData();
  };

  // Handlers for Financeiro
  const handleSaveLancamento = async (params: any) => {
    await storageService.saveLancamentoFinanceiro(params);
    await reloadData();
  };

  const handleDeleteParcelas = async (ids: string[]) => {
    await storageService.deleteParcelas(ids);
    await reloadData();
  };

  // Handlers for POS Vendas & Sangria
  const handleRegisterVenda = async (params: any) => {
    await storageService.registerVenda(params);
    await reloadData();
  };

  const handleRegisterSangria = async (valor: number, motivo: string) => {
    await storageService.registerSangria(valor, motivo);
    await reloadData();
  };

  const handleDeleteVenda = async (vendaId: string) => {
    await storageService.deleteVenda(vendaId);
    await reloadData();
  };

  const tabTitles: Record<ActiveTab, string> = {
    bem_vindo: 'Início & Visão Geral',
    pdv: 'Frente de Caixa (PDV)',
    estoque: 'Estoque & Produtos',
    financeiro: 'Controle Financeiro',
    entidades: 'Entidades & Clientes',
    configuracoes: 'Configurações',
    documentacao: 'Documentação do Sistema'
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors duration-300">
      {/* Login Screen Modal if not logged in */}
      {!user && (
        <LoginModal
          onSuccess={(loggedUser) => {
            setUser(loggedUser);
            reloadData();
          }}
        />
      )}

      {/* Main App Layout */}
      {user && (
        <>
          <Sidebar
            activeTab={activeTab}
            onSelectTab={(tab) => setActiveTab(tab)}
            isOpenMobile={isOpenMobileSidebar}
            onCloseMobile={() => setIsOpenMobileSidebar(false)}
          />

          <Header
            onToggleMobileSidebar={() => setIsOpenMobileSidebar(!isOpenMobileSidebar)}
            isDarkMode={isDarkMode}
            onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
            userEmail={user.email}
            userName={user.name}
            onLogout={() => setUser(null)}
            searchTerm={globalSearchTerm}
            onSearchChange={(term) => setGlobalSearchTerm(term)}
            activeTabTitle={tabTitles[activeTab]}
          />

          <main className="lg:ml-[260px] pt-24 pb-12 px-4 sm:px-8 max-w-7xl mx-auto">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-24 text-slate-400 space-y-3">
                <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
                <p className="text-xs font-bold uppercase tracking-wider">
                  Carregando dados do ERP_ABP...
                </p>
              </div>
            ) : (
              <>
                {activeTab === 'bem_vindo' && (
                  <WelcomeView
                    entidades={entidades}
                    produtos={produtos}
                    financas={financas}
                    parcelas={parcelas}
                    vendas={vendas}
                    onNavigateTab={(tab) => setActiveTab(tab)}
                  />
                )}

                {activeTab === 'entidades' && (
                  <EntidadesView
                    entidades={entidades}
                    onSaveEntidade={handleSaveEntidade}
                    onDeleteEntidades={handleDeleteEntidades}
                  />
                )}

                {activeTab === 'estoque' && (
                  <EstoqueView
                    produtos={produtos}
                    onSaveProduto={handleSaveProduto}
                    onDeleteProdutos={handleDeleteProdutos}
                  />
                )}

                {activeTab === 'financeiro' && (
                  <FinanceiroView
                    financas={financas}
                    parcelas={parcelas}
                    entidades={entidades}
                    onSaveLancamento={handleSaveLancamento}
                    onDeleteParcelas={handleDeleteParcelas}
                  />
                )}

                {activeTab === 'pdv' && (
                  <PdvView
                    produtos={produtos}
                    entidades={entidades}
                    vendas={vendas}
                    onRegisterVenda={handleRegisterVenda}
                    onRegisterSangria={handleRegisterSangria}
                    onDeleteVenda={handleDeleteVenda}
                  />
                )}

                {activeTab === 'configuracoes' && (
                  <ConfiguracoesView onRefreshData={reloadData} />
                )}

                {activeTab === 'documentacao' && (
                  <DocumentacaoView />
                )}
              </>
            )}
          </main>
        </>
      )}
    </div>
  );
}
