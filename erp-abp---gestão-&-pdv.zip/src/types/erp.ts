export type TipoEntidade = 'cliente' | 'fornecedor' | 'colaborador';
export type StatusEntidade = 'ativo' | 'inativo';

export interface Entidade {
  id: string;
  user_id?: string;
  nome_completo: string;
  cpf?: string;
  data_nascimento?: string;
  email?: string;
  telefone?: string;
  tipo_entidade: TipoEntidade;
  status_entidade: StatusEntidade;
  cep?: string;
  logradouro?: string;
  numero?: string;
  bairro?: string;
  cidade?: string;
  estado?: string;
  foto_url?: string;
  created_at?: string;
}

export interface Produto {
  id: string;
  user_id?: string;
  nome: string;
  descricao?: string;
  codigo_barras?: string;
  preco_custo: number;
  preco_venda: number;
  quantidade_estoque: number;
  estoque_minimo: number;
  categoria: string;
  foto_url?: string;
  created_at?: string;
}

export type TipoFinanca = 'receita' | 'despesa';
export type StatusFinanca = 'aberto' | 'finalizado' | 'cancelado';
export type StatusParcela = 'pendente' | 'pago' | 'atrasado';

export interface Financa {
  id: string;
  user_id?: string;
  entidade_id?: string;
  descricao: string;
  valor_total: number;
  tipo: TipoFinanca;
  num_parcelas: number;
  categoria: string;
  status_lancamento: StatusFinanca;
  created_at?: string;
  entidades?: Partial<Entidade>;
}

export interface Parcela {
  id: string;
  financa_id: string;
  num_parcela: number;
  valor_parcela: number;
  data_vencimento: string;
  data_pagamento?: string | null;
  status: StatusParcela;
  codigo_barra?: string;
  boleto_url?: string;
  comprovante_url?: string;
  created_at?: string;
  financas?: Financa;
}

export type FormaPagamento = 'Dinheiro' | 'PIX' | 'Cartão de Crédito' | 'Cartão de Débito';

export interface Venda {
  id: string;
  user_id?: string;
  entidade_id?: string | null;
  valor_total: number;
  desconto: number;
  forma_pagamento: FormaPagamento;
  status: 'concluida' | 'pendente' | 'cancelada';
  created_at?: string;
  entidades?: Partial<Entidade>;
}

export interface ItemVenda {
  id: string;
  venda_id: string;
  produto_id: string;
  quantidade: number;
  preco_unitario: number;
  subtotal: number;
  created_at?: string;
  produtos?: Partial<Produto>;
}

export interface ItemCarrinho extends Produto {
  quantidadeCarrinho: number;
}
