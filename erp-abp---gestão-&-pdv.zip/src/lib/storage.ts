import { supabase } from './supabase';
import { Entidade, Produto, Financa, Parcela, Venda, ItemVenda } from '../types/erp';

// Initial local seeds so the application is rich and usable immediately out of the box
const initialEntidades: Entidade[] = [
  {
    id: '1',
    nome_completo: 'Maria Oliveira Santos',
    cpf: '123.456.789-00',
    email: 'maria.santos@email.com',
    telefone: '(91) 98877-6655',
    tipo_entidade: 'cliente',
    status_entidade: 'ativo',
    cidade: 'Belém',
    estado: 'PA',
    bairro: 'Umarizal',
    cep: '66050-000',
    logradouro: 'Av. Alcindo Cacela',
    numero: '1200'
  },
  {
    id: '2',
    nome_completo: 'Distribuidora do Pará Ltda',
    cpf: '12.345.678/0001-99',
    email: 'contato@distribuidorapa.com.br',
    telefone: '(91) 3210-4000',
    tipo_entidade: 'fornecedor',
    status_entidade: 'ativo',
    cidade: 'Ananindeua',
    estado: 'PA',
    bairro: 'Coqueiro',
    cep: '67113-000',
    logradouro: 'BR-316 Km 3'
  },
  {
    id: '3',
    nome_completo: 'Carlos Eduardo Ferreira',
    cpf: '987.654.321-11',
    email: 'carlos.eduardo@erp.com',
    telefone: '(91) 99123-4567',
    tipo_entidade: 'colaborador',
    status_entidade: 'ativo',
    cidade: 'Belém',
    estado: 'PA',
    bairro: 'Marco'
  }
];

const initialProdutos: Produto[] = [
  {
    id: 'p1',
    nome: 'Camiseta Polo Algodão Premium',
    categoria: 'Vestuário',
    codigo_barras: '7891234567890',
    preco_custo: 25.00,
    preco_venda: 59.90,
    quantidade_estoque: 45,
    estoque_minimo: 10,
    descricao: 'Camiseta polo 100% algodão cor azul marinho tamanho G'
  },
  {
    id: 'p2',
    nome: 'Café Torrado e Moído 500g',
    categoria: 'Alimentos',
    codigo_barras: '7899876543210',
    preco_custo: 12.50,
    preco_venda: 22.90,
    quantidade_estoque: 8,
    estoque_minimo: 15,
    descricao: 'Café tradicional vácuo 500g'
  },
  {
    id: 'p3',
    nome: 'Fone de Ouvido Bluetooth TWS',
    categoria: 'Eletrônicos',
    codigo_barras: '7895554443332',
    preco_custo: 45.00,
    preco_venda: 119.90,
    quantidade_estoque: 18,
    estoque_minimo: 5,
    descricao: 'Fone sem fio com estojo recarregável'
  },
  {
    id: 'p4',
    nome: 'Garrafa Térmica Inox 1L',
    categoria: 'Geral',
    codigo_barras: '7891112223334',
    preco_custo: 22.00,
    preco_venda: 49.90,
    quantidade_estoque: 3,
    estoque_minimo: 5,
    descricao: 'Mantiene bebidas quentes ou frias por 12h'
  }
];

const initialFinancas: Financa[] = [
  {
    id: 'f1',
    descricao: 'Aluguel do Galpão Comercial',
    valor_total: 2500.00,
    tipo: 'despesa',
    num_parcelas: 1,
    categoria: 'Aluguel',
    status_lancamento: 'finalizado'
  },
  {
    id: 'f2',
    descricao: 'Fornecimento de Mercadorias - Distribuidora',
    valor_total: 1200.00,
    tipo: 'despesa',
    num_parcelas: 2,
    categoria: 'Fornecedores',
    status_lancamento: 'aberto'
  },
  {
    id: 'f3',
    descricao: 'Venda de Produtos em Lote - Maria Santos',
    valor_total: 850.00,
    tipo: 'receita',
    num_parcelas: 1,
    categoria: 'Vendas',
    status_lancamento: 'finalizado'
  }
];

const initialParcelas: Parcela[] = [
  {
    id: 'par1',
    financa_id: 'f1',
    num_parcela: 1,
    valor_parcela: 2500.00,
    data_vencimento: new Date().toISOString().split('T')[0],
    data_pagamento: new Date().toISOString().split('T')[0],
    status: 'pago',
    codigo_barra: '237933812860083013528560000633071890000250000'
  },
  {
    id: 'par2',
    financa_id: 'f2',
    num_parcela: 1,
    valor_parcela: 600.00,
    data_vencimento: new Date(Date.now() - 86400000 * 3).toISOString().split('T')[0],
    status: 'atrasado',
    codigo_barra: '341910900800001234567000000100081890000060000'
  },
  {
    id: 'par3',
    financa_id: 'f2',
    num_parcela: 2,
    valor_parcela: 600.00,
    data_vencimento: new Date(Date.now() + 86400000 * 20).toISOString().split('T')[0],
    status: 'pendente'
  },
  {
    id: 'par4',
    financa_id: 'f3',
    num_parcela: 1,
    valor_parcela: 850.00,
    data_vencimento: new Date().toISOString().split('T')[0],
    data_pagamento: new Date().toISOString().split('T')[0],
    status: 'pago'
  }
];

const initialVendas: Venda[] = [
  {
    id: 'v1',
    valor_total: 142.70,
    desconto: 10.00,
    forma_pagamento: 'PIX',
    status: 'concluida',
    created_at: new Date().toISOString()
  }
];

// Helper to get item from localStorage or seed
function getLocal<T>(key: string, seed: T[]): T[] {
  try {
    const raw = localStorage.getItem(`erp_abp_${key}`);
    if (!raw) {
      localStorage.setItem(`erp_abp_${key}`, JSON.stringify(seed));
      return seed;
    }
    return JSON.parse(raw);
  } catch {
    return seed;
  }
}

function setLocal<T>(key: string, data: T[]): void {
  try {
    localStorage.setItem(`erp_abp_${key}`, JSON.stringify(data));
  } catch (e) {
    console.warn(`Error writing to local storage key ${key}`, e);
  }
}

// Data API Layer
export const storageService = {
  // ENTIDADES
  async getEntidades(): Promise<Entidade[]> {
    try {
      const { data, error } = await supabase.from('entidades').select('*').order('nome_completo', { ascending: true });
      if (!error && data && data.length > 0) {
        setLocal('entidades', data);
        return data;
      }
    } catch (err) {
      console.warn('Supabase fetch entidades offline, using local cache', err);
    }
    return getLocal('entidades', initialEntidades);
  },

  async saveEntidade(entidade: Partial<Entidade>): Promise<Entidade> {
    const id = entidade.id || `ent_${Date.now()}`;
    const newEnt: Entidade = {
      id,
      nome_completo: entidade.nome_completo || 'Sem Nome',
      cpf: entidade.cpf || '',
      data_nascimento: entidade.data_nascimento || '',
      email: entidade.email || '',
      telefone: entidade.telefone || '',
      tipo_entidade: entidade.tipo_entidade || 'cliente',
      status_entidade: entidade.status_entidade || 'ativo',
      cep: entidade.cep || '',
      logradouro: entidade.logradouro || '',
      numero: entidade.numero || '',
      bairro: entidade.bairro || '',
      cidade: entidade.cidade || '',
      estado: entidade.estado || '',
      foto_url: entidade.foto_url || '',
      created_at: entidade.created_at || new Date().toISOString()
    };

    // Attempt Supabase
    try {
      if (entidade.id) {
        await supabase.from('entidades').update(newEnt).eq('id', entidade.id);
      } else {
        await supabase.from('entidades').insert([newEnt]);
      }
    } catch (err) {
      console.warn('Supabase save error, storing locally', err);
    }

    const current = getLocal('entidades', initialEntidades);
    const index = current.findIndex(e => e.id === id);
    if (index >= 0) {
      current[index] = newEnt;
    } else {
      current.unshift(newEnt);
    }
    setLocal('entidades', current);
    return newEnt;
  },

  async deleteEntidades(ids: string[]): Promise<void> {
    try {
      await supabase.from('entidades').delete().in('id', ids);
    } catch (err) {
      console.warn('Supabase delete error', err);
    }
    const current = getLocal('entidades', initialEntidades).filter(e => !ids.includes(e.id));
    setLocal('entidades', current);
  },

  // PRODUTOS
  async getProdutos(): Promise<Produto[]> {
    try {
      const { data, error } = await supabase.from('produtos').select('*').order('nome', { ascending: true });
      if (!error && data && data.length > 0) {
        setLocal('produtos', data);
        return data;
      }
    } catch (err) {
      console.warn('Supabase fetch produtos error', err);
    }
    return getLocal('produtos', initialProdutos);
  },

  async saveProduto(prod: Partial<Produto>): Promise<Produto> {
    const id = prod.id || `prod_${Date.now()}`;
    const newProd: Produto = {
      id,
      nome: prod.nome || 'Produto Sem Nome',
      categoria: prod.categoria || 'Geral',
      codigo_barras: prod.codigo_barras || '',
      preco_custo: Number(prod.preco_custo) || 0,
      preco_venda: Number(prod.preco_venda) || 0,
      quantidade_estoque: Number(prod.quantidade_estoque) || 0,
      estoque_minimo: Number(prod.estoque_minimo) || 5,
      descricao: prod.descricao || '',
      foto_url: prod.foto_url || '',
      created_at: prod.created_at || new Date().toISOString()
    };

    try {
      if (prod.id) {
        await supabase.from('produtos').update(newProd).eq('id', prod.id);
      } else {
        await supabase.from('produtos').insert([newProd]);
      }
    } catch (err) {
      console.warn('Supabase save product error', err);
    }

    const current = getLocal('produtos', initialProdutos);
    const index = current.findIndex(p => p.id === id);
    if (index >= 0) {
      current[index] = newProd;
    } else {
      current.unshift(newProd);
    }
    setLocal('produtos', current);
    return newProd;
  },

  async deleteProdutos(ids: string[]): Promise<void> {
    try {
      await supabase.from('produtos').delete().in('id', ids);
    } catch (err) {
      console.warn('Supabase delete product error', err);
    }
    const current = getLocal('produtos', initialProdutos).filter(p => !ids.includes(p.id));
    setLocal('produtos', current);
  },

  // FINANCAS & PARCELAS
  async getFinancasWithParcelas(): Promise<{ financas: Financa[]; parcelas: Parcela[] }> {
    let financas = getLocal('financas', initialFinancas);
    let parcelas = getLocal('parcelas', initialParcelas);

    try {
      const { data: fData, error: fErr } = await supabase.from('financas').select('*, entidades(nome_completo)');
      const { data: pData, error: pErr } = await supabase.from('parcelas').select('*, financas(*)');

      if (!fErr && fData && fData.length > 0) {
        financas = fData;
        setLocal('financas', financas);
      }
      if (!pErr && pData && pData.length > 0) {
        parcelas = pData;
        setLocal('parcelas', parcelas);
      }
    } catch (err) {
      console.warn('Supabase fetch financas/parcelas error', err);
    }

    return { financas, parcelas };
  },

  async saveLancamentoFinanceiro(params: {
    financaId?: string;
    parcelaId?: string;
    descricao: string;
    valor: number;
    tipo: 'receita' | 'despesa';
    categoria: string;
    statusLancamento: 'aberto' | 'finalizado' | 'cancelado';
    numParcelas: number;
    tipoCalculo: 'total' | 'parcela';
    recorrencia: string;
    dataVencimento: string;
    dataPagamento?: string;
    entidadeId?: string;
    codigoBarras?: string;
    boletoUrl?: string;
    comprovanteUrl?: string;
  }) {
    const {
      financaId,
      parcelaId,
      descricao,
      valor,
      tipo,
      categoria,
      statusLancamento,
      numParcelas,
      tipoCalculo,
      recorrencia,
      dataVencimento,
      dataPagamento,
      entidadeId,
      codigoBarras,
      boletoUrl,
      comprovanteUrl
    } = params;

    let valorTotal = valor;
    let valorParcela = valor;
    if (tipoCalculo === 'total') {
      valorTotal = valor;
      valorParcela = Number((valorTotal / Math.max(1, numParcelas)).toFixed(2));
    } else {
      valorParcela = valor;
      valorTotal = Number((valorParcela * numParcelas).toFixed(2));
    }

    let fId = financaId || `fin_${Date.now()}`;
    const newFinanca: Financa = {
      id: fId,
      descricao,
      valor_total: valorTotal,
      tipo,
      categoria: categoria || 'Geral',
      status_lancamento: statusLancamento,
      num_parcelas: numParcelas,
      entidade_id: entidadeId,
      created_at: new Date().toISOString()
    };

    // Local update
    const currentFinancas = getLocal('financas', initialFinancas);
    const finIndex = currentFinancas.findIndex(f => f.id === fId);
    if (finIndex >= 0) {
      currentFinancas[finIndex] = newFinanca;
    } else {
      currentFinancas.unshift(newFinanca);
    }
    setLocal('financas', currentFinancas);

    // Try Supabase
    try {
      if (financaId) {
        await supabase.from('financas').update(newFinanca).eq('id', financaId);
      } else {
        const { data } = await supabase.from('financas').insert([newFinanca]).select().single();
        if (data?.id) fId = data.id;
      }
    } catch (e) {
      console.warn('Supabase save financa error', e);
    }

    const currentParcelas = getLocal('parcelas', initialParcelas);

    if (parcelaId) {
      // Single parcela edit
      const updatedPar: Parcela = {
        id: parcelaId,
        financa_id: fId,
        num_parcela: 1,
        valor_parcela: valorParcela,
        data_vencimento: dataVencimento,
        data_pagamento: dataPagamento || null,
        status: dataPagamento ? 'pago' : 'pendente',
        codigo_barra: codigoBarras,
        boleto_url: boletoUrl,
        comprovante_url: comprovanteUrl,
        financas: newFinanca
      };

      const parIndex = currentParcelas.findIndex(p => p.id === parcelaId);
      if (parIndex >= 0) currentParcelas[parIndex] = updatedPar;
      else currentParcelas.unshift(updatedPar);
      setLocal('parcelas', currentParcelas);

      try {
        await supabase.from('parcelas').update({
          valor_parcela: valorParcela,
          data_vencimento: dataVencimento,
          data_pagamento: dataPagamento || null,
          status: dataPagamento ? 'pago' : 'pendente',
          codigo_barra: codigoBarras,
          ...(boletoUrl ? { boleto_url: boletoUrl } : {}),
          ...(comprovanteUrl ? { comprovante_url: comprovanteUrl } : {})
        }).eq('id', parcelaId);
      } catch (err) {
        console.warn('Supabase update parcela error', err);
      }
    } else {
      // Generate parcelas
      const createdParcelas: Parcela[] = [];
      for (let i = 1; i <= numParcelas; i++) {
        const baseDate = new Date(dataVencimento + 'T12:00:00');
        if (recorrencia === 'diario') {
          baseDate.setDate(baseDate.getDate() + (i - 1));
        } else {
          const step = parseInt(recorrencia) || 1;
          baseDate.setMonth(baseDate.getMonth() + (i - 1) * step);
        }
        const vencStr = baseDate.toISOString().split('T')[0];
        const isPaid = i === 1 && Boolean(dataPagamento);

        const parObj: Parcela = {
          id: `par_${Date.now()}_${i}`,
          financa_id: fId,
          num_parcela: i,
          valor_parcela: valorParcela,
          data_vencimento: vencStr,
          data_pagamento: isPaid ? dataPagamento : null,
          status: isPaid ? 'pago' : 'pendente',
          codigo_barra: codigoBarras,
          boleto_url: boletoUrl,
          comprovante_url: comprovanteUrl,
          financas: newFinanca
        };

        createdParcelas.push(parObj);
        currentParcelas.unshift(parObj);
      }
      setLocal('parcelas', currentParcelas);

      try {
        await supabase.from('parcelas').insert(
          createdParcelas.map(p => ({
            financa_id: fId,
            num_parcela: p.num_parcela,
            valor_parcela: p.valor_parcela,
            data_vencimento: p.data_vencimento,
            data_pagamento: p.data_pagamento,
            status: p.status,
            codigo_barra: p.codigo_barra,
            boleto_url: p.boleto_url,
            comprovante_url: p.comprovante_url
          }))
        );
      } catch (e) {
        console.warn('Supabase insert parcelas error', e);
      }
    }
  },

  async deleteParcelas(ids: string[]): Promise<void> {
    try {
      await supabase.from('parcelas').delete().in('id', ids);
    } catch (e) {
      console.warn('Supabase delete parcelas error', e);
    }
    const current = getLocal('parcelas', initialParcelas).filter(p => !ids.includes(p.id));
    setLocal('parcelas', current);
  },

  // VENDAS & POS
  async getVendas(): Promise<Venda[]> {
    try {
      const { data, error } = await supabase.from('vendas').select('*, entidades(nome_completo)').order('created_at', { ascending: false });
      if (!error && data && data.length > 0) {
        setLocal('vendas', data);
        return data;
      }
    } catch (e) {
      console.warn('Supabase fetch vendas error', e);
    }
    return getLocal('vendas', initialVendas);
  },

  async registerVenda(params: {
    clienteId?: string;
    carrinho: { id: string; nome: string; quantidadeCarrinho: number; preco_venda: number }[];
    desconto: number;
    formaPagamento: Venda['forma_pagamento'];
    cupomHtml: string;
  }): Promise<Venda> {
    const { clienteId, carrinho, desconto, formaPagamento, cupomHtml } = params;

    const subtotal = carrinho.reduce((acc, i) => acc + i.preco_venda * i.quantidadeCarrinho, 0);
    const total = Math.max(0, subtotal - desconto);
    const vendaId = `venda_${Date.now()}`;
    const nowIso = new Date().toISOString();

    const newVenda: Venda = {
      id: vendaId,
      entidade_id: clienteId || null,
      valor_total: total,
      desconto,
      forma_pagamento: formaPagamento,
      status: 'concluida',
      created_at: nowIso
    };

    // 1. Save Venda locally
    const currentVendas = getLocal('vendas', initialVendas);
    currentVendas.unshift(newVenda);
    setLocal('vendas', currentVendas);

    // 2. Reduce Stock locally
    const currentProds = getLocal('produtos', initialProdutos);
    carrinho.forEach(item => {
      const p = currentProds.find(pr => pr.id === item.id);
      if (p) {
        p.quantidade_estoque = Math.max(0, p.quantidade_estoque - item.quantidadeCarrinho);
      }
    });
    setLocal('produtos', currentProds);

    // 3. Create Receita Financeira & Parcela in Local
    const idCurto = vendaId.substring(0, 8).toUpperCase();
    const financaId = `fin_venda_${vendaId}`;
    const dataUriCupom = `data:text/html;charset=utf-8,${encodeURIComponent(cupomHtml)}`;

    const newFinanca: Financa = {
      id: financaId,
      descricao: `Venda PDV - Cupom #${idCurto} (${formaPagamento})`,
      valor_total: total,
      tipo: 'receita',
      num_parcelas: 1,
      categoria: 'Vendas',
      status_lancamento: 'finalizado',
      entidade_id: clienteId || undefined,
      created_at: nowIso
    };

    const newParcela: Parcela = {
      id: `par_venda_${vendaId}`,
      financa_id: financaId,
      num_parcela: 1,
      valor_parcela: total,
      data_vencimento: nowIso.split('T')[0],
      data_pagamento: nowIso.split('T')[0],
      status: 'pago',
      comprovante_url: dataUriCupom,
      financas: newFinanca
    };

    const currentFin = getLocal('financas', initialFinancas);
    currentFin.unshift(newFinanca);
    setLocal('financas', currentFin);

    const currentPar = getLocal('parcelas', initialParcelas);
    currentPar.unshift(newParcela);
    setLocal('parcelas', currentPar);

    // 4. Try syncing with Supabase in background
    try {
      const { data: vData } = await supabase.from('vendas').insert([{
        entidade_id: clienteId || null,
        valor_total: total,
        desconto,
        forma_pagamento: formaPagamento,
        status: 'concluida'
      }]).select().single();

      const realVendaId = vData?.id || vendaId;

      for (let item of carrinho) {
        await supabase.from('itens_venda').insert([{
          venda_id: realVendaId,
          produto_id: item.id,
          quantidade: item.quantidadeCarrinho,
          preco_unitario: item.preco_venda,
          subtotal: item.preco_venda * item.quantidadeCarrinho
        }]);

        const prodLocal = currentProds.find(pr => pr.id === item.id);
        if (prodLocal) {
          await supabase.from('produtos').update({
            quantidade_estoque: prodLocal.quantidade_estoque
          }).eq('id', item.id);
        }
      }

      const { data: fData } = await supabase.from('financas').insert([{
        entidade_id: clienteId || null,
        descricao: `Venda PDV - Cupom #${idCurto} (${formaPagamento})`,
        valor_total: total,
        tipo: 'receita',
        num_parcelas: 1,
        categoria: 'Vendas',
        status_lancamento: 'finalizado'
      }]).select().single();

      if (fData?.id) {
        await supabase.from('parcelas').insert([{
          financa_id: fData.id,
          num_parcela: 1,
          valor_parcela: total,
          data_vencimento: nowIso.split('T')[0],
          data_pagamento: nowIso.split('T')[0],
          status: 'pago',
          comprovante_url: dataUriCupom
        }]);
      }
    } catch (err) {
      console.warn('Supabase sale register background error, local saved successfully', err);
    }

    return newVenda;
  },

  async registerSangria(valor: number, motivo: string): Promise<void> {
    const fId = `fin_sangria_${Date.now()}`;
    const nowIso = new Date().toISOString();
    const todayStr = nowIso.split('T')[0];

    const newFinanca: Financa = {
      id: fId,
      descricao: `Sangria Caixa: ${motivo}`,
      valor_total: valor,
      tipo: 'despesa',
      num_parcelas: 1,
      categoria: 'Sangria',
      status_lancamento: 'finalizado',
      created_at: nowIso
    };

    const newParcela: Parcela = {
      id: `par_sangria_${Date.now()}`,
      financa_id: fId,
      num_parcela: 1,
      valor_parcela: valor,
      data_vencimento: todayStr,
      data_pagamento: todayStr,
      status: 'pago',
      financas: newFinanca
    };

    const currentFin = getLocal('financas', initialFinancas);
    currentFin.unshift(newFinanca);
    setLocal('financas', currentFin);

    const currentPar = getLocal('parcelas', initialParcelas);
    currentPar.unshift(newParcela);
    setLocal('parcelas', currentPar);

    try {
      const { data: fData } = await supabase.from('financas').insert([{
        descricao: `Sangria Caixa: ${motivo}`,
        valor_total: valor,
        tipo: 'despesa',
        num_parcelas: 1,
        categoria: 'Sangria',
        status_lancamento: 'finalizado'
      }]).select().single();

      if (fData?.id) {
        await supabase.from('parcelas').insert([{
          financa_id: fData.id,
          num_parcela: 1,
          valor_parcela: valor,
          data_vencimento: todayStr,
          data_pagamento: todayStr,
          status: 'pago'
        }]);
      }
    } catch (err) {
      console.warn('Supabase sangria error', err);
    }
  },

  async deleteVenda(vendaId: string): Promise<void> {
    // Revert local
    const currentVendas = getLocal('vendas', initialVendas).filter(v => v.id !== vendaId);
    setLocal('vendas', currentVendas);

    try {
      await supabase.from('vendas').delete().eq('id', vendaId);
    } catch (e) {
      console.warn('Supabase delete sale error', e);
    }
  },

  // Export / Import Full JSON Backup
  exportBackupJSON(): string {
    const data = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      entidades: getLocal('entidades', initialEntidades),
      produtos: getLocal('produtos', initialProdutos),
      financas: getLocal('financas', initialFinancas),
      parcelas: getLocal('parcelas', initialParcelas),
      vendas: getLocal('vendas', initialVendas)
    };
    return JSON.stringify(data, null, 2);
  },

  importBackupJSON(jsonStr: string): boolean {
    try {
      const parsed = JSON.parse(jsonStr);
      if (parsed.entidades) setLocal('entidades', parsed.entidades);
      if (parsed.produtos) setLocal('produtos', parsed.produtos);
      if (parsed.financas) setLocal('financas', parsed.financas);
      if (parsed.parcelas) setLocal('parcelas', parsed.parcelas);
      if (parsed.vendas) setLocal('vendas', parsed.vendas);
      return true;
    } catch {
      return false;
    }
  }
};
