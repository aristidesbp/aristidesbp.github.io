import { createClient } from '@supabase/supabase-js';

const defaultUrl = 'https://fwdyqcrawpmwjmtkdiba.supabase.co';
const defaultKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ3ZHlxY3Jhd3Btd2ptdGtkaWJhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYwMTUxMzAsImV4cCI6MjEwMTU5MTEzMH0.iyOsri9yjNrUzDAMF2EuDRGhEZznWRliN7GE_yuRiZ0';

export const SUPABASE_URL = 
  (typeof window !== 'undefined' && localStorage.getItem('erp_abp_supabase_url')) ||
  ((import.meta as any).env && (import.meta as any).env.VITE_SUPABASE_URL) ||
  defaultUrl;

export const SUPABASE_ANON_KEY = 
  (typeof window !== 'undefined' && localStorage.getItem('erp_abp_supabase_key')) ||
  ((import.meta as any).env && (import.meta as any).env.VITE_SUPABASE_ANON_KEY) ||
  defaultKey;

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

