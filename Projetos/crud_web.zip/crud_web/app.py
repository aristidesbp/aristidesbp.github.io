from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

# Cria o banco se não existir
def init_db():
    conn = sqlite3.connect('dados.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS pessoas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            idade INTEGER NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    conn = sqlite3.connect('dados.db')
    c = conn.cursor()
    c.execute('SELECT * FROM pessoas')
    pessoas = c.fetchall()
    conn.close()
    return render_template('index.html', pessoas=pessoas)

@app.route('/adicionar', methods=['POST'])
def adicionar():
    nome = request.form['nome']
    idade = request.form['idade']
    conn = sqlite3.connect('dados.db')
    c = conn.cursor()
    c.execute('INSERT INTO pessoas (nome, idade) VALUES (?, ?)', (nome, idade))
    conn.commit()
    conn.close()
    return redirect('/')

@app.route('/deletar/<int:id>')
def deletar(id):
    conn = sqlite3.connect('dados.db')
    c = conn.cursor()
    c.execute('DELETE FROM pessoas WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect('/')

@app.route('/editar/<int:id>', methods=['GET', 'POST'])
def editar(id):
    conn = sqlite3.connect('dados.db')
    c = conn.cursor()

    if request.method == 'POST':
        novo_nome = request.form['nome']
        nova_idade = request.form['idade']
        c.execute('UPDATE pessoas SET nome = ?, idade = ? WHERE id = ?', (novo_nome, nova_idade, id))
        conn.commit()
        conn.close()
        return redirect('/')
    else:
        c.execute('SELECT * FROM pessoas WHERE id = ?', (id,))
        pessoa = c.fetchone()
        conn.close()
        return render_template('editar.html', pessoa=pessoa)

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
