```
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão Financeira - ERP ABP</title>
    
    <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
 <style>
:root { 
    --primary: #3ecf8e; 
    --dark: #0f172a; 
    --bg: #f1f5f9; 
    --danger: #ef4444; 
}

* { box-sizing: border-box; }

body { 
    margin: 0; 
    font-family: 'Segoe UI', sans-serif; 
    background: var(--bg); 
    padding-top: 85px; 
}

.container { max-width: 1200px; margin: auto; padding: 20px; }

.card { 
    background: white; 
    padding: 25px; 
    border-radius: 12px; 
    box-shadow: 0 4px 15px rgba(0,0,0,0.05); 
    margin-bottom: 20px; 
}

.navbar { 
    position: fixed; top: 0; left: 0; width: 100%; 
    background: white; padding: 15px 25px; 
    display: flex; justify-content: space-between; align-items: center; 
    box-shadow: 0 2px 10px rgba(0,0,0,0.1); z-index: 1000; 
}

.nav-link { text-decoration: none; color: #64748b; font-weight: bold; margin-right: 15px; }
.btn-exit { background: var(--danger); color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; }

.section-title { 
    color: var(--primary); font-size: 14px; text-transform: uppercase; 
    margin: 20px 0 10px; border-bottom: 1px solid #eee; 
    padding-bottom: 5px; font-weight: bold; 
}

.form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; }
label { display: block; margin-bottom: 5px; font-size: 13px; color: #64748b; font-weight: bold; }
input, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; }

.btn-add { background: var(--primary); color: white; padding: 15px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; width: 100%; margin-top: 20px; }
.btn-cancel { background: #64748b; color: white; margin-top: 10px; border: none; padding: 10px; border-radius: 6px; cursor: pointer; display: none; width: 100%; }

.table-container { background: white; border-radius: 12px; overflow-x: auto; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
table { width: 100%; border-collapse: collapse; min-width: 1100px; }
th { background: #f8fafc; padding: 15px; color: #64748b; font-size: 12px; text-transform: uppercase; text-align: left; }
td { padding: 12px 15px; border-top: 1px solid #f1f5f9; font-size: 14px; }

.status-badge { padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; text-transform: uppercase; }
.status-pago { background: #dcfce7; color: #166534; }
.status-pendente { background: #fef9c3; color: #854d0e; }

.label-tipo { font-size: 10px; font-weight: bold; text-transform: uppercase; margin-right: 5px; }
.tipo-pagar { color: var(--danger); }
.tipo-receber { color: var(--primary); }

.resumo-financeiro { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px; }
.resumo-card { padding: 15px; border-radius: 10px; color: white; text-align: center; }
.resumo-entradas { background: #10b981; }
.resumo-saidas { background: #ef4444; }
.resumo-saldo { background: #3b82f6; }

.bulk-actions { margin-bottom: 10px; display: none; background: #fee2e2; padding: 10px; border-radius: 8px; border: 1px solid #fecaca; }
.btn-delete-bulk { background: var(--danger); color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; margin-left: 15px; }
.btn-action { background: none; border: none; cursor: pointer; font-size: 16px; margin-right: 8px; }
.btn-pdf { background: #334155; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; }
</style>
  
</head>
<body>

<!-- NAVBAR -->
    <style>
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .nav-buttons {
            display: flex;
            gap: 15px;
        }

        .btn-nav {
            background: #ef4444;
            color: white;
            padding: 8px 15px;
            border-radius: 6px;
            font-weight: bold;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-nav:hover {
            background: #dc2626;
            transform: scale(1.05);
        }

        .btn-home {
            background: #3ecf8e !important; /* Verde padrão do seu ERP */
        }

        /* Ajuste para o conteúdo não ficar embaixo da navbar fixa */
        body {
            padding-top: 80px;
        }
    </style>
    
    <div class="navbar">
        <div style="font-weight: bold; color: #0f172a; font-size: 1.2rem;">
            <i class="fas fa-chart-line" style="color: #3ecf8e;"></i> ERP ABP
        </div>
        <div class="nav-buttons">
            <a href="index.html" class="btn-nav btn-home"><i class="fas fa-home"></i> index</a>
            <button class="btn-nav" onclick="sairDaConta()">
                <i class="fas fa-sign-out-alt"></i> Sair
            </button>
        </div>
    </div>`;

    <script>
        async function sairDaConta() {
    if(confirm("Deseja realmente sair do sistema?")) {
        try {
            // Verifica se o cliente supabase existe antes de tentar deslogar
            if (typeof _supabase !== 'undefined') {
                await _supabase.auth.signOut();
            }
            window.location.href = 'login.html';
        } catch (error) {
            console.error("Erro ao sair:", error);
            window.location.href = 'login.html';
        }
    }
        }
    </script>
<!-- FIM DA NAVBAR -->

<div class="container">
    <div class="card">
        <h3 id="form-title">Novo Lançamento</h3>
        <input type="hidden" id="edit-id">
        
        <div class="section-title">Dados e Parcelamento</div>
        <div class="form-grid">
            <div><label>Tipo *</label><select id="tipo"><option value="pagar">Saída</option><option value="receber">Entrada</option></select></div>
            <div style="grid-column: span 2;"><label>Descrição *</label><input type="text" id="descricao"></div>
            <div><label>Valor Parcela (R$) *</label><input type="number" id="valor" step="0.01"></div>
            <div><label>Qtde Parcelas</label><input type="number" id="parcelas" value="1" min="1"></div>
        </div>

        <div class="section-title">Datas e Status</div>
        <div class="form-grid">
            <div><label>1º Vencimento *</label><input type="date" id="data_vencimento"></div>
            <div><label>Data Pagamento</label><input type="date" id="data_pagamento"></div>
            <div><label>Status</label><select id="status"><option value="pendente">Pendente</option><option value="pago">Pago/Recebido</option></select></div>
        </div>

        <div class="section-title">Classificação</div>
        <div class="form-grid">
            <div><label>Entidade</label><select id="entidade_id"><option value="">Selecione...</option></select></div>
            <div><label>Categoria</label><input type="text" id="categoria"></div>
            <div><label>Forma Pagto</label><input type="text" id="forma_pagamento"></div>
        </div>
        
        <button class="btn-add" id="btn-save" onclick="handleSave()">Salvar Lançamento(s)</button>
        <button class="btn-cancel" id="btn-cancel" onclick="resetForm()">Cancelar Edição</button>
    </div>

    <div class="card">
        <div class="form-grid">
            <div style="grid-column: span 2;"><label>Busca Inteligente (Tudo)</label><input type="text" id="inputBusca" onkeyup="filtrarTabela()" placeholder="Busque por descrição, categoria, valor..."></div>
            <div><label>Início</label><input type="date" id="dataInicio" onchange="filtrarTabela()"></div>
            <div><label>Fim</label><input type="date" id="dataFim" onchange="filtrarTabela()"></div>
            <div style="display: flex; align-items: flex-end;">
                <button class="btn-pdf" onclick="exportarPDF()"><i class="fas fa-file-pdf"></i> PDF</button>
            </div>
        </div>
    </div>

    <div class="resumo-financeiro">
        <div class="resumo-card resumo-entradas"><span>Entradas</span><br><b id="total-receber">R$ 0,00</b></div>
        <div class="resumo-card resumo-saidas"><span>Saídas</span><br><b id="total-pagar">R$ 0,00</b></div>
        <div class="resumo-card resumo-saldo"><span>Saldo Filtrado</span><br><b id="total-saldo">R$ 0,00</b></div>
    </div>

    <div id="bulk-area" class="bulk-actions">
        <span id="selected-count" style="font-weight:bold; color:#b91c1c;">0 selecionados</span>
        <button onclick="deleteSelected()" class="btn-delete-bulk"><i class="fas fa-trash"></i> Excluir Selecionados</button>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th width="40"><input type="checkbox" id="select-all" onclick="toggleSelectAll()"></th>
                    <th>Tipo</th>
                    <th>Descrição</th>
                    <th>Categoria</th>
                    <th>Forma Pagto</th>
                    <th>Vencimento</th>
                    <th>Pagamento</th>
                    <th>Valor</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody id="financeiro-list"></tbody>
        </table>
    </div>
</div>
<script>
// --- 1. CONFIGURAÇÃO E INICIALIZAÇÃO ---
const supabaseUrl = 'https://eisruaetsqrratemqswv.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVpc3J1YWV0c3FycmF0ZW1xc3d2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk4MDI4OTAsImV4cCI6MjA4NTM3ODg5MH0.Rb-nu9zBL7TNWoGNYHvETWMfbqO1NF7UID4TdSYyKS4';
const _supabase = supabase.createClient(supabaseUrl, supabaseKey);

let dadosFinanceiros = []; // Cache local para busca e filtros

document.addEventListener('DOMContentLoaded', async () => {
    const { data: { session } } = await _supabase.auth.getSession();
    if (!session) {
        window.location.href = "login.html";
        return;
    }
    carregarEntidades();
    loadFinanceiro();
});

// --- 2. CARREGAMENTO DE DADOS ---

async function carregarEntidades() {
    const { data, error } = await _supabase.from('entidades').select('id, nome_completo');
    if (!error) {
        const select = document.getElementById('entidade_id');
        data.forEach(ent => {
            const opt = document.createElement('option');
            opt.value = ent.id;
            opt.textContent = ent.nome_completo;
            select.appendChild(opt);
        });
    }
}

async function loadFinanceiro() {
    const { data, error } = await _supabase
        .from('financeiro')
        .select(`*, entidades(nome_completo)`)
        .order('data_vencimento', { ascending: true });

    if (error) {
        console.error("Erro ao carregar:", error);
        return;
    }

    dadosFinanceiros = data;
    renderTable(dadosFinanceiros);
}

// --- 3. RENDERIZAÇÃO E CÁLCULOS ---

function renderTable(data) {
    const tbody = document.getElementById('financeiro-list');
    tbody.innerHTML = '';
    
    let totalEntradas = 0;
    let totalSaidas = 0;

    data.forEach(item => {
        const valor = parseFloat(item.valor || 0);
        if (item.tipo.toLowerCase() === 'receber') totalEntradas += valor;
        else totalSaidas += valor;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td><input type="checkbox" class="row-checkbox" value="${item.id}" onclick="updateSelectedCount()"></td>
            <td>
                <span class="label-tipo ${item.tipo.toLowerCase() === 'receber' ? 'tipo-receber' : 'tipo-pagar'}">
                    <i class="fas fa-${item.tipo.toLowerCase() === 'receber' ? 'arrow-up' : 'arrow-down'}"></i> ${item.tipo}
                </span>
            </td>
            <td><strong>${item.descricao}</strong><br><small>${item.entidades?.nome_completo || 'Sem Entidade'}</small></td>
            <td>${item.categoria || '-'}</td>
            <td>${item.forma_pagamento || '-'}</td>
            <td>${item.data_vencimento ? new Date(item.data_vencimento).toLocaleDateString('pt-BR') : '-'}</td>
            <td>${item.data_pagamento ? new Date(item.data_pagamento).toLocaleDateString('pt-BR') : '-'}</td>
            <td><strong>R$ ${valor.toLocaleString('pt-BR', {minimumFractionDigits: 2})}</strong></td>
            <td><span class="status-badge status-${item.status.toLowerCase()}">${item.status}</span></td>
            <td>
                <button class="btn-action" style="color:#6366f1" onclick="editItem('${item.id}')"><i class="fas fa-edit"></i></button>
                <button class="btn-action" style="color:#ef4444" onclick="deleteItem('${item.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tbody.appendChild(row);
    });

    // Atualiza Resumo
    document.getElementById('total-receber').innerText = `R$ ${totalEntradas.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`;
    document.getElementById('total-pagar').innerText = `R$ ${totalSaidas.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`;
    document.getElementById('total-saldo').innerText = `R$ ${(totalEntradas - totalSaidas).toLocaleString('pt-BR', {minimumFractionDigits: 2})}`;
}

// --- 4. SALVAMENTO E PARCELAMENTO ---

async function handleSave() {
    const id = document.getElementById('edit-id').value;
    const qtdeParcelas = parseInt(document.getElementById('parcelas').value) || 1;
    
    const basePayload = {
        tipo: document.getElementById('tipo').value,
        descricao: document.getElementById('descricao').value,
        valor: parseFloat(document.getElementById('valor').value),
        status: document.getElementById('status').value,
        entidade_id: document.getElementById('entidade_id').value || null,
        categoria: document.getElementById('categoria').value,
        forma_pagamento: document.getElementById('forma_pagamento').value,
        data_pagamento: document.getElementById('data_pagamento').value || null
    };

    if (!basePayload.descricao || !basePayload.valor || !document.getElementById('data_vencimento').value) {
        alert("Preencha os campos obrigatórios (*)");
        return;
    }

    try {
        if (id) {
            // Edição simples
            basePayload.data_vencimento = document.getElementById('data_vencimento').value;
            const { error } = await _supabase.from('financeiro').update(basePayload).eq('id', id);
            if (error) throw error;
        } else {
            // Inserção com lógica de parcelas
            const lancamentos = [];
            let dataBase = new Date(document.getElementById('data_vencimento').value + "T12:00:00");

            for (let i = 0; i < qtdeParcelas; i++) {
                const novaData = new Date(dataBase);
                novaData.setMonth(dataBase.getMonth() + i);
                
                lancamentos.push({
                    ...basePayload,
                    descricao: qtdeParcelas > 1 ? `${basePayload.descricao} (${i + 1}/${qtdeParcelas})` : basePayload.descricao,
                    data_vencimento: novaData.toISOString().split('T')[0]
                });
            }
            const { error } = await _supabase.from('financeiro').insert(lancamentos);
            if (error) throw error;
        }

        alert("Sucesso!");
        resetForm();
        loadFinanceiro();
    } catch (err) {
        alert("Erro: " + err.message);
    }
}

// --- 5. AÇÕES (EDITAR, EXCLUIR, BUSCAR) ---

async function editItem(id) {
    const item = dadosFinanceiros.find(i => i.id === id);
    if (!item) return;

    document.getElementById('edit-id').value = item.id;
    document.getElementById('tipo').value = item.tipo.toLowerCase();
    document.getElementById('descricao').value = item.descricao;
    document.getElementById('valor').value = item.valor;
    document.getElementById('data_vencimento').value = item.data_vencimento;
    document.getElementById('data_pagamento').value = item.data_pagamento || '';
    document.getElementById('status').value = item.status.toLowerCase();
    document.getElementById('entidade_id').value = item.entidade_id || '';
    document.getElementById('categoria').value = item.categoria || '';
    document.getElementById('forma_pagamento').value = item.forma_pagamento || '';

    document.getElementById('form-title').innerText = "Editando Lançamento";
    document.getElementById('btn-save').innerText = "Atualizar";
    document.getElementById('btn-cancel').style.display = "block";
    document.getElementById('parcelas').disabled = true;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function deleteItem(id) {
    if (confirm("Excluir este lançamento?")) {
        const { error } = await _supabase.from('financeiro').delete().eq('id', id);
        if (!error) loadFinanceiro();
    }
}

function filtrarTabela() {
    const termo = document.getElementById('inputBusca').value.toLowerCase();
    const inicio = document.getElementById('dataInicio').value;
    const fim = document.getElementById('dataFim').value;

    const filtrados = dadosFinanceiros.filter(item => {
        const matchesTermo = JSON.stringify(item).toLowerCase().includes(termo);
        const dataVenc = item.data_vencimento;
        const matchesData = (!inicio || dataVenc >= inicio) && (!fim || dataVenc <= fim);
        return matchesTermo && matchesData;
    });

    renderTable(filtrados);
}

function resetForm() {
    document.getElementById('edit-id').value = '';
    document.querySelectorAll('input').forEach(i => i.value = i.id === 'parcelas' ? '1' : '');
    document.getElementById('status').value = 'pendente';
    document.getElementById('tipo').value = 'pagar';
    document.getElementById('entidade_id').value = '';
    document.getElementById('form-title').innerText = "Novo Lançamento";
    document.getElementById('btn-save').innerText = "Salvar Lançamento(s)";
    document.getElementById('btn-cancel').style.display = "none";
    document.getElementById('parcelas').disabled = false;
}

// --- 6. AÇÕES EM MASSA ---

function toggleSelectAll() {
    const master = document.getElementById('select-all');
    document.querySelectorAll('.row-checkbox').forEach(cb => cb.checked = master.checked);
    updateSelectedCount();
}

function updateSelectedCount() {
    const selecionados = document.querySelectorAll('.row-checkbox:checked').length;
    document.getElementById('bulk-area').style.display = selecionados > 0 ? 'block' : 'none';
    document.getElementById('selected-count').innerText = `${selecionados} selecionados`;
}

async function deleteSelected() {
    if (!confirm("Excluir todos os selecionados?")) return;
    const ids = Array.from(document.querySelectorAll('.row-checkbox:checked')).map(cb => cb.value);
    const { error } = await _supabase.from('financeiro').delete().in('id', ids);
    if (!error) {
        loadFinanceiro();
        updateSelectedCount();
    }
}

// --- 7. EXPORTAÇÃO PDF ---

function exportarPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('l', 'mm', 'a4');

    doc.text("Relatório Financeiro - ERP ABP", 14, 15);
    
    const rows = dadosFinanceiros.map(i => [
        i.tipo.toUpperCase(),
        i.descricao,
        i.data_vencimento,
        `R$ ${parseFloat(i.valor).toFixed(2)}`,
        i.status.toUpperCase()
    ]);

    doc.autoTable({
        head: [['Tipo', 'Descrição', 'Vencimento', 'Valor', 'Status']],
        body: rows,
        startY: 20
    });

    doc.save("financeiro.pdf");
}
</script>     

</body>
</html>
```