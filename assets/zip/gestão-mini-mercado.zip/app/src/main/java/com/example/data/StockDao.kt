package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StockDao {
    @Query("SELECT * FROM stock_items ORDER BY name ASC")
    fun getAllStockItems(): Flow<List<StockItem>>

    @Query("SELECT * FROM stock_items WHERE category = :category ORDER BY name ASC")
    fun getStockItemsByCategory(category: String): Flow<List<StockItem>>

    @Query("SELECT * FROM stock_items WHERE id = :id")
    suspend fun getStockItemById(id: Int): StockItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStockItem(item: StockItem): Long

    @Delete
    suspend fun deleteStockItem(item: StockItem)

    @Update
    suspend fun updateStockItem(item: StockItem)

    @Query("UPDATE stock_items SET quantity = :newQuantity WHERE id = :itemId")
    suspend fun updateStockQuantity(itemId: Int, newQuantity: Int)
}
