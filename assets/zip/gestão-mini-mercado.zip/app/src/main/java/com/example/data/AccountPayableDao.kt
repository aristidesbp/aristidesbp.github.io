package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountPayableDao {
    @Query("SELECT * FROM accounts_payable ORDER BY dueDate ASC")
    fun getAllAccounts(): Flow<List<AccountPayable>>

    @Query("SELECT * FROM accounts_payable WHERE isPaid = 0 ORDER BY dueDate ASC")
    fun getPendingAccounts(): Flow<List<AccountPayable>>

    @Query("SELECT * FROM accounts_payable WHERE isPaid = 1 ORDER BY paymentDate DESC")
    fun getPaidAccounts(): Flow<List<AccountPayable>>

    @Query("SELECT * FROM accounts_payable WHERE id = :id")
    suspend fun getAccountById(id: Int): AccountPayable?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccount(account: AccountPayable): Long

    @Delete
    suspend fun deleteAccount(account: AccountPayable)

    @Update
    suspend fun updateAccount(account: AccountPayable)

    @Query("UPDATE accounts_payable SET isPaid = 1, paymentDate = :paymentDate WHERE id = :accountId")
    suspend fun markAsPaid(accountId: Int, paymentDate: Long)
}
