package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Organic Supermarket Theme Colors
val GreenPrimary = Color(0xFF1F4E3D) // Elegant Deep Forest Green
val GreenPrimaryLight = Color(0xFFD2E8DD) // Refreshing Sage
val AmberAccent = Color(0xFFE28743) // Warm Bread / Sunset Amber
val RedIndicator = Color(0xFFC94A4A) // Warning Red for low stock
val GreenIndicator = Color(0xFF4C9A60) // Paid, healthy stock
val LightBackground = Color(0xFFFDFCF9) // Cream Off-white
val LightSurface = Color(0xFFF5F3EC) // Warmer Ivory Surface
val DarkBackground = Color(0xFF141916) // Deep Spruce charcoal
val DarkSurface = Color(0xFF1D2622) // Slate Spruce container
val TextDark = Color(0xFF1A1F1C)
val TextLight = Color(0xFFEDF0EE)

