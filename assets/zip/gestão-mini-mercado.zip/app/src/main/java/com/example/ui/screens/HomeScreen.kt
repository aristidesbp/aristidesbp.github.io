package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.AccountPayable
import com.example.data.StockItem
import com.example.ui.SupermarketViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: SupermarketViewModel,
    modifier: Modifier = Modifier
) {
    val stockList by viewModel.stockItems.collectAsStateWithLifecycle()
    val accountsList by viewModel.accountsPayable.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf("estoque") } // "estoque" or "contas"
    
    // Add item state dialogs
    var showAddStockDialog by remember { mutableStateOf(false) }
    var showAddAccountDialog by remember { mutableStateOf(false) }

    // Search and filters
    var stockSearchQuery by remember { mutableStateOf("") }
    var selectedStockCategory by remember { mutableStateOf("Todos") }
    
    var accountStatusFilter by remember { mutableStateOf("Todos") } // "Todos", "Pendentes", "Pagas"

    val stockCategories = listOf("Todos", "Alimentos básicos", "Bebidas", "Frios & Laticínios", "Higiene & Limpeza", "Outros")
    val accountCategories = listOf("Todos", "Fornecedor", "Serviços/Utilidades", "Aluguel", "Outros")

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SuperEstoque & Contas",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (activeTab == "estoque") {
                        showAddStockDialog = true
                    } else {
                        showAddAccountDialog = true
                    }
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag(if (activeTab == "estoque") "add_stock_btn" else "add_account_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = if (activeTab == "estoque") "Adicionar Produto" else "Lançar Conta"
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Dashboard Summary (Vibrant metrics segment)
            DashboardSummarySection(
                stockList = stockList,
                accountsList = accountsList
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Navigation Tabs Selector
            TabSelectorRow(
                activeTab = activeTab,
                onTabSelected = { activeTab = it }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Tab Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                if (activeTab == "estoque") {
                    // STOCK TAB
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Search bar
                        OutlinedTextField(
                            value = stockSearchQuery,
                            onValueChange = { stockSearchQuery = it },
                            placeholder = { Text("Buscar no estoque...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (stockSearchQuery.isNotEmpty()) {
                                    IconButton(onClick = { stockSearchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Limpar busca")
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Category chips
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(vertical = 4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(stockCategories) { category ->
                                FilterChip(
                                    selected = selectedStockCategory == category,
                                    onClick = { selectedStockCategory = category },
                                    label = { Text(category) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                    )
                                )
                            }
                        }

                        // Filtered Stock List
                        val filteredStock = stockList.filter {
                            val matchesSearch = it.name.contains(stockSearchQuery, ignoreCase = true) || 
                                                it.supplier.contains(stockSearchQuery, ignoreCase = true)
                            val matchesCategory = selectedStockCategory == "Todos" || it.category == selectedStockCategory
                            matchesSearch && matchesCategory
                        }

                        if (filteredStock.isEmpty()) {
                            EmptyStatePlaceholder(
                                icon = Icons.Outlined.Inventory,
                                title = "Nenhum produto encontrado",
                                subtitle = "Cadastre novos produtos no botão '+' ou ajuste seus filtros acima."
                            )
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(bottom = 80.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(filteredStock, key = { it.id }) { item ->
                                    StockItemCard(
                                        item = item,
                                        onIncrement = { viewModel.adjustQuantity(item.id, 1) },
                                        onDecrement = { viewModel.adjustQuantity(item.id, -1) },
                                        onDelete = { viewModel.deleteStockItem(item) },
                                        onEdit = { updated -> viewModel.updateStockItem(updated) }
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // ACCOUNTS PAYABLE TAB
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Quick status segments (Todos, Pendentes, Pagas)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val statuses = listOf("Todos", "Pendentes", "Pagas")
                            statuses.forEach { status ->
                                FilledTonalButton(
                                    onClick = { accountStatusFilter = status },
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = if (accountStatusFilter == status) {
                                            MaterialTheme.colorScheme.primaryContainer
                                        } else {
                                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                        },
                                        contentColor = if (accountStatusFilter == status) {
                                            MaterialTheme.colorScheme.onPrimaryContainer
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        }
                                    ),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = status,
                                        fontWeight = if (accountStatusFilter == status) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Filtered Accounts
                        val filteredAccounts = accountsList.filter {
                            when (accountStatusFilter) {
                                "Pendentes" -> !it.isPaid
                                "Pagas" -> it.isPaid
                                else -> true
                            }
                        }

                        if (filteredAccounts.isEmpty()) {
                            EmptyStatePlaceholder(
                                icon = Icons.Outlined.Receipt,
                                title = "Nenhuma conta pendente",
                                subtitle = "Tudo em dia! Caso precise, lance novas duplicatas ou faturas de mercadorias no botão '+'."
                            )
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                contentPadding = PaddingValues(bottom = 80.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(filteredAccounts, key = { it.id }) { account ->
                                    AccountPayableCard(
                                        account = account,
                                        onTogglePayment = { viewModel.togglePayment(account) },
                                        onDelete = { viewModel.deleteAccount(account) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal dialog for adding Stock Items
    if (showAddStockDialog) {
        AddStockItemDialog(
            categories = stockCategories.filter { it != "Todos" },
            onDismiss = { showAddStockDialog = false },
            onConfirm = { name, cat, qty, min, purchase, sell, supplier ->
                viewModel.addStockItem(name, cat, qty, min, purchase, sell, supplier)
                showAddStockDialog = false
            }
        )
    }

    // Modal dialog for adding Accounts Payable
    if (showAddAccountDialog) {
        AddAccountDialog(
            categories = accountCategories.filter { it != "Todos" },
            onDismiss = { showAddAccountDialog = false },
            onConfirm = { desc, amount, dueDate, category, supplier ->
                viewModel.addAccount(desc, amount, dueDate, category, supplier)
                showAddAccountDialog = false
            }
        )
    }
}

// FORMAT HELPER: Currency in Brazilian Real (R$)
fun formatPrice(value: Double): String {
    return String.format(Locale("pt", "BR"), "R$ %,.2f", value)
}

// FORMAT HELPER: Elegant date format
fun formatDate(millis: Long): String {
    val formatter = SimpleDateFormat("dd 'de' MMM, yyyy", Locale("pt", "BR"))
    return formatter.format(Date(millis))
}

@Composable
fun DashboardSummarySection(
    stockList: List<StockItem>,
    accountsList: List<AccountPayable>
) {
    // Calculative values
    val totalStockInvested = stockList.sumOf { it.purchasePrice * it.quantity }
    val totalStockPotentialSale = stockList.sumOf { it.sellPrice * it.quantity }
    val lowStockCount = stockList.count { it.quantity <= it.minQuantity }

    val totalPendingAccounts = accountsList.filter { !it.isPaid }.sumOf { it.amount }
    val overdueAccounts = accountsList.filter { !it.isPaid && it.dueDate < System.currentTimeMillis() }
    val totalOverdueAmount = overdueAccounts.sumOf { it.amount }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                        )
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Patrimônio em Estoque",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatPrice(totalStockInvested),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                // Badges
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (lowStockCount > 0) {
                        Surface(
                            color = RedIndicator.copy(alpha = 0.15f),
                            contentColor = RedIndicator,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "$lowStockCount Baixo",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }

                    if (totalOverdueAmount > 0.00) {
                        Surface(
                            color = RedIndicator,
                            contentColor = Color.White,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.AttachMoney, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "Atrasado!",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 12.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Potential retail projection
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = GreenIndicator,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Previsão de Vendas",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = formatPrice(totalStockPotentialSale),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Total unpaid bills
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.List,
                            contentDescription = null,
                            tint = if (totalOverdueAmount > 0) RedIndicator else MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Total Contas a Pagar",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = formatPrice(totalPendingAccounts),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (totalOverdueAmount > 0) RedIndicator else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun TabSelectorRow(
    activeTab: String,
    onTabSelected: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(48.dp)
            .background(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                shape = RoundedCornerShape(24.dp)
            )
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Tab 1: ESTOQUE
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (activeTab == "estoque") MaterialTheme.colorScheme.surface else Color.Transparent
                )
                .clickable { onTabSelected("estoque") }
                .testTag("tab_estoque"),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (activeTab == "estoque") Icons.Filled.Inventory else Icons.Outlined.Inventory,
                    contentDescription = null,
                    tint = if (activeTab == "estoque") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Estoque",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = if (activeTab == "estoque") FontWeight.Bold else FontWeight.Medium
                    ),
                    color = if (activeTab == "estoque") MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Tab 2: CONTAS A PAGAR
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (activeTab == "contas") MaterialTheme.colorScheme.surface else Color.Transparent
                )
                .clickable { onTabSelected("contas") }
                .testTag("tab_contas"),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (activeTab == "contas") Icons.Filled.Payment else Icons.Outlined.Payment,
                    contentDescription = null,
                    tint = if (activeTab == "contas") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Contas a Pagar",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = if (activeTab == "contas") FontWeight.Bold else FontWeight.Medium
                    ),
                    color = if (activeTab == "contas") MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun EmptyStatePlaceholder(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
            modifier = Modifier.size(72.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
fun StockItemCard(
    item: StockItem,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onDelete: () -> Unit,
    onEdit: (StockItem) -> Unit
) {
    val isLowStock = item.quantity <= item.minQuantity
    var showEditDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("stock_item_${item.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isLowStock) {
                RedIndicator.copy(alpha = 0.03f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            },
            // Draw a red outline if stock is critical
        ),
        border = if (isLowStock) {
            androidx.compose.foundation.BorderStroke(1.dp, RedIndicator.copy(alpha = 0.3f))
        } else {
            null
        }
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Category pill
                        SuggestionChip(
                            onClick = {},
                            label = { Text(item.category, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.height(24.dp)
                        )
                        
                        if (item.supplier.isNotBlank() && item.supplier != "Nenhum") {
                            Text(
                                text = "• " + item.supplier,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(onClick = { showEditDialog = true }) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Editar produto",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Deletar produto",
                            tint = RedIndicator,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Info block
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Qtd: ${item.quantity}",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isLowStock) RedIndicator else GreenIndicator
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "(Mín: ${item.minQuantity})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Venda: ${formatPrice(item.sellPrice)} | Compra: ${formatPrice(item.purchasePrice)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Incrementor/Decrementor quick controls (Touch elements >= 48dp)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(2.dp)
                    ) {
                        IconButton(
                            onClick = onDecrement,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                Icons.Default.Remove,
                                contentDescription = "Diminuir estoque",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        
                        Text(
                            text = "${item.quantity}",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        IconButton(
                            onClick = onIncrement,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                Icons.Default.Add,
                                contentDescription = "Aumentar estoque",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }

    if (showEditDialog) {
        EditStockItemDialog(
            item = item,
            onDismiss = { showEditDialog = false },
            onConfirm = { updated ->
                onEdit(updated)
                showEditDialog = false
            }
        )
    }
}

@Composable
fun AccountPayableCard(
    account: AccountPayable,
    onTogglePayment: () -> Unit,
    onDelete: () -> Unit
) {
    val isOverdue = !account.isPaid && account.dueDate < System.currentTimeMillis()
    val isPaid = account.isPaid

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("account_item_${account.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPaid) {
                GreenIndicator.copy(alpha = 0.04f)
            } else if (isOverdue) {
                RedIndicator.copy(alpha = 0.05f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SuggestionChip(
                            onClick = {},
                            label = { Text(account.category, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.height(24.dp)
                        )
                        
                        if (account.supplier.isNotBlank() && account.supplier != "Nenhum") {
                            Text(
                                text = "• " + account.supplier,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = account.description,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Deletar conta",
                        tint = RedIndicator,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text(
                        text = formatPrice(account.amount),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isPaid) GreenIndicator else if (isOverdue) RedIndicator else MaterialTheme.colorScheme.onSurface
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isPaid) Icons.Default.CheckCircle else Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = if (isPaid) GreenIndicator else if (isOverdue) RedIndicator else MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (isPaid) {
                                "Pago em: " + formatDate(account.paymentDate ?: account.dueDate)
                            } else {
                                "Vence em: " + formatDate(account.dueDate)
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isPaid) GreenIndicator else if (isOverdue) RedIndicator else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Paying Checkbox toggle or action button
                Button(
                    onClick = onTogglePayment,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPaid) {
                            MaterialTheme.colorScheme.surfaceVariant
                        } else {
                            MaterialTheme.colorScheme.primary
                        },
                        contentColor = if (isPaid) {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        } else {
                            MaterialTheme.colorScheme.onPrimary
                        }
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(
                        text = if (isPaid) "Reabrir" else "Pagar",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@Composable
fun AddStockItemDialog(
    categories: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (String, String, Int, Int, Double, Double, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var minQuantity by remember { mutableStateOf("") }
    var purchasePrice by remember { mutableStateOf("") }
    var sellPrice by remember { mutableStateOf("") }
    var supplier by remember { mutableStateOf("") }
    
    var selectedCategory by remember { mutableStateOf(categories.firstOrNull() ?: "Outros") }
    var categoryDropdownExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Cadastrar Novo Produto",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome do Produto") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // Category drop down menu
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { categoryDropdownExpanded = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Categoria: $selectedCategory", color = MaterialTheme.colorScheme.onSurface)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                    }
                    DropdownMenu(
                        expanded = categoryDropdownExpanded,
                        onDismissRequest = { categoryDropdownExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        categories.forEach { category ->
                            DropdownMenuItem(
                                text = { Text(category) },
                                onClick = {
                                    selectedCategory = category
                                    categoryDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text("Qtd Atual") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = minQuantity,
                        onValueChange = { minQuantity = it },
                        label = { Text("Mín. Alerta") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = purchasePrice,
                        onValueChange = { purchasePrice = it },
                        label = { Text("R$ Custo") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = sellPrice,
                        onValueChange = { sellPrice = it },
                        label = { Text("R$ Venda") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = supplier,
                    onValueChange = { supplier = it },
                    label = { Text("Fornecedor / Distribuidor") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancelar")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val qty = quantity.toIntOrNull() ?: 0
                            val min = minQuantity.toIntOrNull() ?: 1
                            val pPrice = purchasePrice.toDoubleOrNull() ?: 0.0
                            val sPrice = sellPrice.toDoubleOrNull() ?: 0.0
                            if (name.isNotBlank()) {
                                onConfirm(name, selectedCategory, qty, min, pPrice, sPrice, supplier)
                            }
                        },
                        enabled = name.isNotBlank()
                    ) {
                        Text("Salvar")
                    }
                }
            }
        }
    }
}

@Composable
fun EditStockItemDialog(
    item: StockItem,
    onDismiss: () -> Unit,
    onConfirm: (StockItem) -> Unit
) {
    var name by remember { mutableStateOf(item.name) }
    var quantity by remember { mutableStateOf(item.quantity.toString()) }
    var minQuantity by remember { mutableStateOf(item.minQuantity.toString()) }
    var purchasePrice by remember { mutableStateOf(item.purchasePrice.toString()) }
    var sellPrice by remember { mutableStateOf(item.sellPrice.toString()) }
    var supplier by remember { mutableStateOf(item.supplier) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Editar Produto",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome do Produto") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text("Qtd Atual") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = minQuantity,
                        onValueChange = { minQuantity = it },
                        label = { Text("Mín. Alerta") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = purchasePrice,
                        onValueChange = { purchasePrice = it },
                        label = { Text("R$ Custo") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = sellPrice,
                        onValueChange = { sellPrice = it },
                        label = { Text("R$ Venda") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = supplier,
                    onValueChange = { supplier = it },
                    label = { Text("Fornecedor / Distribuidor") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancelar")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val qty = quantity.toIntOrNull() ?: item.quantity
                            val min = minQuantity.toIntOrNull() ?: item.minQuantity
                            val pPrice = purchasePrice.toDoubleOrNull() ?: item.purchasePrice
                            val sPrice = sellPrice.toDoubleOrNull() ?: item.sellPrice
                            if (name.isNotBlank()) {
                                onConfirm(
                                    item.copy(
                                        name = name,
                                        quantity = qty,
                                        minQuantity = min,
                                        purchasePrice = pPrice,
                                        sellPrice = sPrice,
                                        supplier = supplier
                                    )
                                )
                            }
                        },
                        enabled = name.isNotBlank()
                    ) {
                        Text("Salvar")
                    }
                }
            }
        }
    }
}

@Composable
fun AddAccountDialog(
    categories: List<String>,
    onDismiss: () -> Unit,
    onConfirm: (String, Double, Long, String, String) -> Unit
) {
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var supplier by remember { mutableStateOf("") }
    
    var selectedCategory by remember { mutableStateOf(categories.firstOrNull() ?: "Outros") }
    var categoryDropdownExpanded by remember { mutableStateOf(false) }

    // Date chooser
    val context = LocalContext.current
    val calendar = Calendar.getInstance()
    var selectedDateInMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    var dateLabel by remember { mutableStateOf(formatDate(selectedDateInMillis)) }

    val datePickerDialog = DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val selCal = Calendar.getInstance()
            selCal.set(year, month, dayOfMonth)
            selectedDateInMillis = selCal.timeInMillis
            dateLabel = formatDate(selectedDateInMillis)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Lançar Nova Conta",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Descrição / Identificação da Conta") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        label = { Text("Valor (R$)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1.2f),
                        singleLine = true
                    )

                    // Date Button Chooser
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Vencimento",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(
                            onClick = { datePickerDialog.show() },
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = dateLabel,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // Category list picker
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { categoryDropdownExpanded = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Categoria: $selectedCategory", color = MaterialTheme.colorScheme.onSurface)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                    }
                    DropdownMenu(
                        expanded = categoryDropdownExpanded,
                        onDismissRequest = { categoryDropdownExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        categories.forEach { category ->
                            DropdownMenuItem(
                                text = { Text(category) },
                                onClick = {
                                    selectedCategory = category
                                    categoryDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = supplier,
                    onValueChange = { supplier = it },
                    label = { Text("Credor / Fornecedor Cobrador") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancelar")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val accValue = amount.replace(",", ".").toDoubleOrNull() ?: 0.0
                            if (description.isNotBlank() && accValue > 0.0) {
                                onConfirm(description, accValue, selectedDateInMillis, selectedCategory, supplier)
                            }
                        },
                        enabled = description.isNotBlank() && amount.isNotBlank()
                    ) {
                        Text("Confirmar")
                    }
                }
            }
        }
    }
}
