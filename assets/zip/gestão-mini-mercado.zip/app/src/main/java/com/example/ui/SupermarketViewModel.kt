package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AccountPayable
import com.example.data.StockItem
import com.example.data.SupermarketRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

class SupermarketViewModel(private val repository: SupermarketRepository) : ViewModel() {

    // Stock state
    val stockItems: StateFlow<List<StockItem>> = repository.allStockItems
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Accounts state
    val accountsPayable: StateFlow<List<AccountPayable>> = repository.allAccounts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        // Pre-populate database with friendly mock data if empty
        viewModelScope.launch {
            stockItems.first() // wait for initial value
            val currentStock = repository.allStockItems.first()
            if (currentStock.isEmpty()) {
                prePopulateStock()
            }
            
            val currentAccounts = repository.allAccounts.first()
            if (currentAccounts.isEmpty()) {
                prePopulateAccounts()
            }
        }
    }

    private suspend fun prePopulateStock() {
        val defaultItems = listOf(
            StockItem(name = "Arroz Tipo 1 (5kg)", category = "Alimentos básicos", quantity = 15, minQuantity = 5, purchasePrice = 18.50, sellPrice = 24.90, supplier = "Arroz Tio João"),
            StockItem(name = "Feijão Carioca (1kg)", category = "Alimentos básicos", quantity = 22, minQuantity = 8, purchasePrice = 4.80, sellPrice = 7.50, supplier = "Feijão Camil"),
            StockItem(name = "Óleo de Soja (900ml)", category = "Alimentos básicos", quantity = 30, minQuantity = 10, purchasePrice = 5.20, sellPrice = 6.99, supplier = "Cargill Ltda"),
            StockItem(name = "Café Torrado e Moído (500g)", category = "Alimentos básicos", quantity = 3, minQuantity = 6, purchasePrice = 12.00, sellPrice = 16.50, supplier = "Café Pilão"), // Low stock
            StockItem(name = "Coca-Cola Original (2L)", category = "Bebidas", quantity = 40, minQuantity = 15, purchasePrice = 6.50, sellPrice = 9.50, supplier = "Coca-Cola Femsa"),
            StockItem(name = "Leite Integral UHT (1L)", category = "Frios & Laticínios", quantity = 5, minQuantity = 12, purchasePrice = 3.40, sellPrice = 4.80, supplier = "Laticínios Itambé"), // Low stock
            StockItem(name = "Sabão de Coco em Pó (1kg)", category = "Higiene & Limpeza", quantity = 12, minQuantity = 4, purchasePrice = 7.50, sellPrice = 11.20, supplier = "Unilever Brasil"),
            StockItem(name = "Detergente Líquido (500ml)", category = "Higiene & Limpeza", quantity = 25, minQuantity = 8, purchasePrice = 1.30, sellPrice = 2.49, supplier = "Química Amparo (Ypê)")
        )
        for (item in defaultItems) {
            repository.insertStockItem(item)
        }
    }

    private suspend fun prePopulateAccounts() {
        val calendar = Calendar.getInstance()
        
        // Account 1: Overdue
        calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) - 3)
        val overdueDate = calendar.timeInMillis
        
        // Account 2: Due Tomorrow
        calendar.setTimeInMillis(System.currentTimeMillis())
        calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) + 1)
        val dueTomorrowDate = calendar.timeInMillis

        // Account 3: Due in 5 Days
        calendar.setTimeInMillis(System.currentTimeMillis())
        calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) + 5)
        val dueInFiveDaysDate = calendar.timeInMillis

        // Account 4: Paid
        calendar.setTimeInMillis(System.currentTimeMillis())
        calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) - 10)
        val paidDateOriginal = calendar.timeInMillis
        
        val defaultAccounts = listOf(
            AccountPayable(
                description = "Carga de refrigerantes",
                amount = 1250.00,
                dueDate = overdueDate,
                category = "Fornecedor",
                isPaid = false,
                supplier = "Coca-Cola Femsa"
            ),
            AccountPayable(
                description = "Fornecimento de Óleo e Açúcar",
                amount = 890.50,
                dueDate = dueTomorrowDate,
                category = "Fornecedor",
                isPaid = false,
                supplier = "Cargill Ltda"
            ),
            AccountPayable(
                description = "Fatura de Energia Elétrica",
                amount = 425.80,
                dueDate = dueInFiveDaysDate,
                category = "Serviços/Utilidades",
                isPaid = false,
                supplier = "Neoenergia Coelba"
            ),
            AccountPayable(
                description = "Aluguel Mensal do Imóvel",
                amount = 2200.00,
                dueDate = paidDateOriginal,
                category = "Aluguel",
                isPaid = true,
                supplier = "Imobiliária Central",
                paymentDate = paidDateOriginal + 86400000 // Paid 1 day later
            )
        )
        for (acc in defaultAccounts) {
            repository.insertAccount(acc)
        }
    }

    // ACTIONS: Stock Items
    fun addStockItem(name: String, category: String, quantity: Int, minQuantity: Int, purchasePrice: Double, sellPrice: Double, supplier: String) {
        viewModelScope.launch {
            val item = StockItem(
                name = name,
                category = category,
                quantity = quantity,
                minQuantity = minQuantity,
                purchasePrice = purchasePrice,
                sellPrice = sellPrice,
                supplier = supplier.ifBlank { "Nenhum" }
            )
            repository.insertStockItem(item)
        }
    }

    fun updateStockItem(item: StockItem) {
        viewModelScope.launch {
            repository.updateStockItem(item)
        }
    }

    fun adjustQuantity(itemId: Int, quantityDiff: Int) {
        viewModelScope.launch {
            val item = repository.getStockItemById(itemId)
            if (item != null) {
                val newQty = (item.quantity + quantityDiff).coerceAtLeast(0)
                repository.updateStockQuantity(itemId, newQty)
            }
        }
    }

    fun deleteStockItem(item: StockItem) {
        viewModelScope.launch {
            repository.deleteStockItem(item)
        }
    }

    // ACTIONS: Accounts Payable
    fun addAccount(description: String, amount: Double, dueDate: Long, category: String, supplier: String) {
        viewModelScope.launch {
            val acc = AccountPayable(
                description = description,
                amount = amount,
                dueDate = dueDate,
                category = category,
                isPaid = false,
                supplier = supplier.ifBlank { "Nenhum" }
            )
            repository.insertAccount(acc)
        }
    }

    fun deleteAccount(account: AccountPayable) {
        viewModelScope.launch {
            repository.deleteAccount(account)
        }
    }

    fun togglePayment(account: AccountPayable) {
        viewModelScope.launch {
            if (account.isPaid) {
                // Mark as unpaid
                val updated = account.copy(isPaid = false, paymentDate = null)
                repository.updateAccount(updated)
            } else {
                // Mark as paid today
                val updated = account.copy(isPaid = true, paymentDate = System.currentTimeMillis())
                repository.updateAccount(updated)
            }
        }
    }
}
