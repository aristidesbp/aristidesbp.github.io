package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "accounts_payable")
data class AccountPayable(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val description: String,
    val amount: Double,
    val dueDate: Long,
    val category: String,
    val isPaid: Boolean,
    val supplier: String,
    val paymentDate: Long? = null
)
