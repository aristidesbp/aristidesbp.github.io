package com.example.data

import kotlinx.coroutines.flow.Flow

class SupermarketRepository(
    private val stockDao: StockDao,
    private val accountPayableDao: AccountPayableDao
) {
    // Stock APIs
    val allStockItems: Flow<List<StockItem>> = stockDao.getAllStockItems()
    
    fun getStockItemsByCategory(category: String): Flow<List<StockItem>> = 
        stockDao.getStockItemsByCategory(category)
        
    suspend fun getStockItemById(id: Int): StockItem? = stockDao.getStockItemById(id)

    suspend fun insertStockItem(item: StockItem) = stockDao.insertStockItem(item)

    suspend fun deleteStockItem(item: StockItem) = stockDao.deleteStockItem(item)

    suspend fun updateStockItem(item: StockItem) = stockDao.updateStockItem(item)

    suspend fun updateStockQuantity(itemId: Int, newQuantity: Int) = 
        stockDao.updateStockQuantity(itemId, newQuantity)

    // Accounts Payable APIs
    val allAccounts: Flow<List<AccountPayable>> = accountPayableDao.getAllAccounts()
    val pendingAccounts: Flow<List<AccountPayable>> = accountPayableDao.getPendingAccounts()
    val paidAccounts: Flow<List<AccountPayable>> = accountPayableDao.getPaidAccounts()

    suspend fun getAccountById(id: Int): AccountPayable? = accountPayableDao.getAccountById(id)

    suspend fun insertAccount(account: AccountPayable) = accountPayableDao.insertAccount(account)

    suspend fun deleteAccount(account: AccountPayable) = accountPayableDao.deleteAccount(account)

    suspend fun updateAccount(account: AccountPayable) = accountPayableDao.updateAccount(account)

    suspend fun markAsPaid(accountId: Int, paymentDate: Long) = 
        accountPayableDao.markAsPaid(accountId, paymentDate)
}
