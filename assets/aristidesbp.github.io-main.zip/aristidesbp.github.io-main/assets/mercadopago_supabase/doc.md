🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# SITE DE VENDAS E PAGAMENTOS
* ESTRUTURA SITE DE VENDAS E PAGAMENTOS:
```
/aristidesbp.github.io  (Sua pasta local e no GitHub)
│
├── index.html          <-- (A página principal que te enviei agora)
└── assets
     └── mercadopago_supabase
           ├── pagamento.html      <-- (A página universal de checkout)
           ├── sucesso.html        <-- (Página de agradecimento após o Pix)
           ├── services/           <-- (Opcional: Para organizar seus JSONs)
           │    └── serviços.json   <-- (Onde você pode listar os preços e descrições)
           │
           ├── assets/             <-- (Para suas imagens e logos)
           │   └── foto-perfil.jpg
           |
           └── supabase/           <-- (Pasta que contém sua inteligência de backend)
                └── functions/
                       └── checkout/
                             └── index.ts <-- (O código TypeScript que gera o Mercado Pago)
```

🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥         
# index.html (pagina de vendas do sistema)
```

<!DOCTYPE html>
<html class="dark" lang="pt-BR">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Aristidesbp | Digital Solutions</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;900&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#2563eb",
                        "background-light": "#f6f6f8",
                        "background-dark": "#020617",
                        "slate-border": "#1e293b",
                    },
                    fontFamily: { "display": ["Inter", "sans-serif"] },
                },
            },
        }
    </script>
    <style type="text/tailwindcss">
        @layer components {
            .glass {
                backdrop-filter: blur(12px);
                -webkit-backdrop-filter: blur(12px);
                background: rgba(15, 23, 42, 0.6);
                border: 1px solid rgba(255, 255, 255, 0.1);
            }
            .dark .glass { background: rgba(15, 23, 42, 0.6); }
            .light .glass { background: rgba(255, 255, 255, 0.7); border: 1px solid rgba(0, 0, 0, 0.1); }
        }
        .light body { background-color: #f6f6f8; color: #1e293b; }
        .light .service-card { background: white; border-color: #e2e8f0; }
        .service-card:hover { border-color: #2563eb; transform: translateY(-4px); }
    </style>
</head>
<body class="bg-background-light dark:bg-background-dark text-[#f8fafc] dark:text-[#f8fafc] font-display transition-colors duration-300">  
    

    <!-- navbar ##################################################################################################################### -->
<nav class="fixed w-full z-50 glass border-b border-gray-200 dark:border-slate-border">
    <div class="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <div class="flex items-center gap-2">
            <span class="material-symbols-outlined text-primary text-3xl">terminal</span>
            <span class="font-black text-xl tracking-tighter dark:text-white">ABP<span class="text-primary text-xs uppercase ml-1">Digital</span></span>
        </div>

        <div class="flex items-center gap-6">
            <div class="hidden md:flex gap-6 text-sm font-bold uppercase tracking-widest text-gray-600 dark:text-gray-400">
                <a href="#home" class="hover:text-primary transition-colors">Home</a>
                <a href="#projetos" class="hover:text-primary transition-colors">Projetos</a>
            </div>

            <select id="langSelect" onchange="changeLang()" class="bg-transparent border-none text-xs font-bold uppercase cursor-pointer focus:ring-0 dark:text-white">
                <option value="pt">PT</option>
                <option value="es">ES</option>
                <option value="en">EN</option>
            </select>

            <a href="assets/login.html" id="nav_login_btn" 
               class="flex items-center gap-2 bg-primary hover:bg-blue-700 text-white px-5 py-2 rounded-full text-xs font-black uppercase tracking-widest transition-all shadow-lg shadow-primary/20">
                <span class="material-symbols-outlined text-sm">login</span>
                ÁREA DO CLIENTE
            </a>

            <button onclick="toggleTheme()" class="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-white/5 transition-colors">
                <span id="themeIcon" class="material-symbols-outlined text-gray-600 dark:text-gray-400">dark_mode</span>
            </button>
        </div>
    </div>
</nav>

        <div class="flex items-center gap-3">
            <button onclick="toggleTheme()" class="p-2 rounded-lg bg-slate-800 border border-slate-border hover:bg-slate-700 transition-all">
                <span id="themeIcon" class="material-symbols-outlined text-white text-sm">light_mode</span>
            </button>
            <select id="langSelect" onchange="changeLang()" class="bg-slate-800 border-slate-border text-white text-xs font-bold rounded-lg py-1.5">
                <option value="pt">PT-BR</option>
                <option value="es">ES-ES</option>
            </select>
        </div>



<main class="pt-20">
    <section class="relative min-h-[85vh] flex items-center justify-center px-4 overflow-hidden" id="home">
        <div class="relative z-10 max-w-4xl text-center flex flex-col items-center gap-8">
            <h1 class="text-4xl md:text-7xl font-black leading-[1.1] tracking-tight" id="heroTitle">
                Transformando Necessidades Reais em <span class="text-primary">Soluções Digitais</span> Funcionais
            </h1>
            <p class="text-lg md:text-xl text-slate-400 max-w-2xl">
                Escalando negócios e automatizando processos através de tecnologia de ponta.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 mt-4">
                <a class="px-8 py-4 bg-primary hover:bg-primary/90 text-white font-bold rounded-xl transition-all shadow-lg shadow-primary/20" href="#services">Ver Serviços</a>
                <a class="px-8 py-4 glass hover:bg-white/5 font-bold rounded-xl transition-all border border-slate-border" href="#about">Saiba Mais</a>
            </div>
        </div>
    </section>

    <section class="py-24 px-6 md:px-16" id="about">
        <div class="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
            <div class="aspect-square rounded-2xl overflow-hidden bg-slate-800 border border-slate-border">
                <div class="w-full h-full bg-cover bg-center" style="background-image: url('https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1000&auto=format&fit=crop');"></div>
            </div>
            <div class="flex flex-col gap-6">
                <h2 class="text-3xl md:text-5xl font-bold">Sobre o Especialista</h2>
                <p class="text-slate-400 text-lg leading-relaxed">Analista de Sistemas e Programador com foco no desenvolvimento de soluções digitais práticas, eficientes e orientadas a resultados. Atuo desde a concepção até a entrega final.</p>
            </div>
        </div>
    </section>

    <section class="py-24 px-6 md:px-16" id="services">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-3xl md:text-5xl font-bold mb-16 text-center">Pacote Completo de Soluções</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div class="glass p-6 border border-slate-border rounded-xl flex flex-col hover:border-primary transition-all">
                    <span class="material-symbols-outlined text-primary text-4xl mb-4">developer_mode_tv</span>
                    <h3 class="text-xl font-bold mb-2">Desenvolvimento Web</h3>
                    <p class="text-slate-400 text-sm mb-6 flex-grow">Sistemas web personalizados e sites institucionais.</p>
                    <div class="flex items-center justify-between mt-auto">
                        <span class="font-bold">R$ 3.500,00</span>
                        <button onclick="addServico(this, 'Dev Web', 3500)" class="btn-add px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1">
                            <span class="material-symbols-outlined text-sm">add</span> Adicionar
                        </button>
                    </div>
                </div>
                <div class="glass p-6 border border-slate-border rounded-xl flex flex-col hover:border-primary transition-all">
                    <span class="material-symbols-outlined text-primary text-4xl mb-4">query_stats</span>
                    <h3 class="text-xl font-bold mb-2">Tráfego Pago</h3>
                    <p class="text-slate-400 text-sm mb-6 flex-grow">Gestão de anúncios focada em conversão.</p>
                    <div class="flex items-center justify-between mt-auto">
                        <span class="font-bold">R$ 1.500,00</span>
                        <button onclick="addServico(this, 'Tráfego', 1500)" class="btn-add px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1">
                            <span class="material-symbols-outlined text-sm">add</span> Adicionar
                        </button>
                    </div>
                </div>
                <div class="glass p-6 border border-slate-border rounded-xl flex flex-col hover:border-primary transition-all">
                    <span class="material-symbols-outlined text-primary text-4xl mb-4">terminal</span>
                    <h3 class="text-xl font-bold mb-2">Consultoria Técnica</h3>
                    <p class="text-slate-400 text-sm mb-6 flex-grow">Arquitetura de sistemas e suporte especializado.</p>
                    <div class="flex items-center justify-between mt-auto">
                        <span class="font-bold">R$ 1.000,00</span>
                        <button onclick="addServico(this, 'Consultoria', 1000)" class="btn-add px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1">
                            <span class="material-symbols-outlined text-sm">add</span> Adicionar
                        </button>
                    </div>
                </div>
                <div class="glass p-6 border-primary bg-primary/5 rounded-xl flex flex-col">
                    <span class="material-symbols-outlined text-primary text-4xl mb-4">picture_as_pdf</span>
                    <h3 class="text-xl font-bold mb-2">PDF Misterioso</h3>
                    <p class="text-slate-400 text-sm mb-6 flex-grow">Guia completo de automação e criação de PDF.</p>
                    <div class="flex items-center justify-between mt-auto">
                        <span class="font-bold text-primary">R$ 2,00</span>
                        <button onclick="addServico(this, 'PDF Misterioso', 2)" class="btn-add px-3 py-1.5 bg-primary text-white rounded-lg text-xs font-bold transition-all flex items-center gap-1">
                            <span class="material-symbols-outlined text-sm">shopping_cart</span> Comprar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-24 px-6 md:px-16" id="contact">
        <div class="max-w-4xl mx-auto glass p-8 rounded-2xl border border-slate-border">
            <h2 class="text-2xl font-bold mb-8">Checkout Seguro</h2>
            <form id="payForm" class="space-y-4">
                <input id="cliente_nome" class="w-full bg-slate-900 border-slate-border rounded-xl p-3 text-white" placeholder="Nome Completo" required/>
                <input id="cliente_email" class="w-full bg-slate-900 border-slate-border rounded-xl p-3 text-white" type="email" placeholder="E-mail" required/>
                <div class="p-6 bg-primary/10 rounded-xl border border-primary/20 flex justify-between items-center">
                    <div>
                        <span class="block text-xs uppercase font-bold text-slate-500">Valor Total</span>
                        <span class="text-3xl font-black text-primary">R$ <span id="resumoTotal">0.00</span></span>
                    </div>
                    <span class="material-symbols-outlined text-4xl text-primary opacity-50">account_balance_wallet</span>
                </div>
                <button type="button" onclick="processarPagamento()" id="btnPagar" class="w-full py-4 bg-primary text-white font-bold rounded-xl hover:bg-primary/90 transition-all shadow-lg shadow-primary/25">
                    FINALIZAR NO MERCADO PAGO
                </button>
            </form>
        </div>
    </section>
</main>

<script>
    let carrinho = [];
    const functionUrl = 'https://eisruaetsqrratemqswv.functions.supabase.co/checkout';

    function toggleTheme() {
        const html = document.documentElement;
        const icon = document.getElementById('themeIcon');
        if (html.classList.contains('dark')) {
            html.classList.remove('dark'); html.classList.add('light');
            icon.innerText = 'dark_mode';
        } else {
            html.classList.remove('light'); html.classList.add('dark');
            icon.innerText = 'light_mode';
        }
    }

    function changeLang() {
        const lang = document.getElementById('langSelect').value;
        const title = document.getElementById('heroTitle');
        title.innerHTML = lang === 'es' ? 
            'Transformando Necesidades Reales en <span class="text-primary">Soluciones Digitales</span>' : 
            'Transformando Necessidades Reais em <span class="text-primary">Soluções Digitais</span> Funcionais';
    }

    function addServico(btn, nome, preco) {
        // Lógica de Carrinho
        carrinho.push({ nome, preco });
        const total = carrinho.reduce((sum, item) => sum + item.preco, 0);
        document.getElementById('resumoTotal').innerText = total.toFixed(2);

        // Feedback Visual (Botão Verde)
        btn.classList.remove('bg-primary');
        btn.classList.add('bg-success');
        btn.innerHTML = `<span class="material-symbols-outlined text-sm">check_circle</span> Adicionado`;
    }

    async function processarPagamento() {
        const total = carrinho.reduce((sum, item) => sum + item.preco, 0);
        if (total <= 0) return alert("Selecione um serviço primeiro.");
        
        const nome = document.getElementById('cliente_nome').value;
        const email = document.getElementById('cliente_email').value;
        if(!nome || !email) return alert("Preencha nome e e-mail.");

        const btn = document.getElementById('btnPagar');
        btn.disabled = true;
        btn.innerHTML = `<div class="flex items-center justify-center gap-2"><div class="loading-spinner"></div> PROCESSANDO...</div>`;

        try {
            const response = await fetch(functionUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    nome, email, total,
                    itens: carrinho.map(i => ({ nome: i.nome, preco: i.preco, qtd: 1 }))
                })
            });
            const data = await response.json();
            if (data.init_point) window.location.href = data.init_point;
        } catch (e) {
            alert("Erro ao conectar. Tente novamente.");
            btn.disabled = false;
            btn.innerText = "FINALIZAR NO MERCADO PAGO";
        }
    }
</script>
</body>
</html>
```

🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# INTALANDO O DOCKER
É importante mencionar: o Supabase CLI funciona "dentro" do Docker para simular o ambiente de nuvem no seu computador. Sem ele, você não conseguirá rodar supabase init ou fazer o deploy das funções.
No Linux Mint, você instala o Docker assim:
```
sudo apt update
sudo apt install docker.io
sudo systemctl start docker
sudo systemctl enable docker
# Permite rodar o docker sem usar 'sudo' toda hora
sudo usermod -aG docker $USER
```
##  Nota: Após rodar o comando usermod, você precisará reiniciar o computador ou fazer logoff para as alterações surtirem efeito.
Verificação Final ,Assim que conseguir instalar, rode: 
```
supabase --version
```
## O que acontece depois?
*  O instalador vai concluir a configuração dos arquivos.
*  Assim que ele terminar e você voltar para a linha de comando comum (onde aparece seu nome de usuário), lembre-se de rodar aquele comando importante para não precisar usar sudo toda hora:
```  
 sudo usermod -aG docker $USER
```  
* Dica: Depois de rodar o comando acima, você precisará reiniciar o seu computador para que o Linux entenda que agora você tem permissão total para usar o Docker e o Supabase CLI.
* Assim que reiniciar, tente rodar docker --version no terminal. Se funcionar, já podemos partir para o deploy da sua função !

## Docker está rodando perfeitamente no seu Linux Mint. Agora o seu computador tem a "ferramenta" necessária para empacotar e enviar o código para os servidores do Supabase.
* Como você já reiniciou (ou aplicou as permissões), vamos colocar  para processar pagamentos reais.
  **Siga estes passos no terminal, dentro da pasta onde está o seu projeto (seu repositório do GitHub)**:
* Inicialize o Supabase no seu Projeto
```
# Este comando vai criar uma pasta chamada supabase no seu diretório.
supabase init
```
* Crie a Estrutura da Função
```
# Vamos criar o espaço para a função de checkout:
supabase functions new checkout
```

* Cole o Código da Função index.ts
🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# mercadopago_supabase/supabase/functions/checkout/index.ts
```
// Adicione os dados do comprador (Payer) para habilitar os botões
const preferenceData = {
  items: body.itens.map((i: any) => ({
    title: i.nome,
    unit_price: i.preco,
    quantity: i.qtd,
    currency_id: 'BRL'
  })),
  payer: {
    name: body.nome,
    email: body.email, // O Mercado Pago exige e-mail válido para liberar o botão
  },
  // Garante que o cliente possa pagar com qualquer método
  payment_methods: {
    excluded_payment_types: [],
    installments: 12
  },
  // Redirecionamento automático após pagar
  back_urls: {
    success: "https://aristidesbp.github.io/sucesso.html",
    failure: "https://aristidesbp.github.io/pagamento.html",
    pending: "https://aristidesbp.github.io/sucesso.html", // Adicionado para Pix pendente
},
auto_return: "all", // Mude de "approved" para "all"
};
```

🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# Configure as Variáveis de Ambiente
* Para não deixar sua chave do Mercado Pago exposta no código, vamos salvá-la de forma segura no Supabase:
```
supabase secrets set MP_ACCESS_TOKEN=seu_token_aqui
```

🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# Faça o Deploy (Envio)
* Agora, com o Docker rodando, execute o comando para subir a função para a nuvem:
```
supabase functions deploy checkout
```
**Verificação no Painel do Supabase**
* Após o comando terminar, você poderá ver a função listada no seu painel do Supabase em Edge Functions.
* Informação Importante: Lembre-se de que no seu arquivo index.html (o que vai para o GitHub), a URL para chamar essa função será: https://[SEU-ID-DO-PROJETO].supabase.co/functions/v1/checkout
  

🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# mercadopago_supabase/index.html
```
<!DOCTYPE html>
<html class="dark" lang="pt-BR">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Checkout Seguro | Aristidesbp</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #020617; color: #f8fafc; }
        .glass { background: rgba(30, 41, 59, 0.4); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.1); }
        .loading-spinner {
            border: 3px solid rgba(255,255,255,0.3); border-top: 3px solid #2563eb;
            border-radius: 50%; width: 24px; height: 24px; animation: spin 0.8s linear infinite;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">

    <div class="max-w-md w-full glass rounded-3xl p-8 shadow-2xl">
        <div class="text-center mb-8">
            <div class="size-12 bg-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-600/20">
                <span class="material-symbols-outlined text-white">shield_with_heart</span>
            </div>
            <h1 class="text-2xl font-black uppercase tracking-tight">Checkout Seguro</h1>
            <p class="text-slate-400 text-sm">Aristidesbp Digital Solutions</p>
        </div>

        <div class="bg-slate-900/50 rounded-2xl p-6 border border-white/5 mb-6">
            <div class="flex justify-between items-start mb-4">
                <div>
                    <span class="text-[10px] uppercase font-bold text-blue-500 tracking-wider">Produto/Serviço</span>
                    <h2 id="displayItem" class="font-bold text-lg leading-tight">Carregando...</h2>
                </div>
                <span class="material-symbols-outlined text-slate-600">shopping_bag</span>
            </div>
            <div class="flex justify-between items-end">
                <div>
                    <span class="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Total a pagar</span>
                    <div class="text-3xl font-black text-white">R$ <span id="displayValor">0,00</span></div>
                </div>
            </div>
        </div>

        <form id="payForm" class="space-y-4">
            <div>
                <label class="text-[10px] uppercase font-bold text-slate-500 ml-1">Seu Nome</label>
                <input id="nome" type="text" required class="w-full bg-slate-900 border-white/10 rounded-xl p-3 text-sm focus:border-blue-500 focus:ring-0 transition-all" placeholder="Nome completo">
            </div>
            <div>
                <label class="text-[10px] uppercase font-bold text-slate-500 ml-1">Seu Melhor E-mail</label>
                <input id="email" type="email" required class="w-full bg-slate-900 border-white/10 rounded-xl p-3 text-sm focus:border-blue-500 focus:ring-0 transition-all" placeholder="email@exemplo.com">
            </div>

            <button type="submit" id="btnPagar" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-600/20 transition-all flex items-center justify-center gap-3">
                PAGAR AGORA
            </button>
        </form>

        <div class="mt-6 flex items-center justify-center gap-4 opacity-40 grayscale">
            <img src="https://img.icons8.com/color/48/000000/visa.png" class="h-4">
            <img src="https://img.icons8.com/color/48/000000/mastercard.png" class="h-4">
            <img src="https://upload.wikimedia.org/wikipedia/commons/a/a2/Logo_Pix.png" class="h-3">
        </div>
    </div>

    <script>
        // Capturar dados da URL (?item=NOME&valor=000)
        const params = new URLSearchParams(window.location.search);
        const itemNome = params.get('item') || "Serviço Digital";
        const itemValor = parseFloat(params.get('valor')) || 0;

        document.getElementById('displayItem').innerText = itemNome;
        document.getElementById('displayValor').innerText = itemValor.toLocaleString('pt-br', {minimumFractionDigits: 2});

        const functionUrl = 'https://eisruaetsqrratemqswv.functions.supabase.co/checkout';

        document.getElementById('payForm').onsubmit = async (e) => {
            e.preventDefault();
            const btn = document.getElementById('btnPagar');
            
            if(itemValor <= 0) return alert("Valor inválido.");

            btn.disabled = true;
            btn.innerHTML = `<div class="loading-spinner"></div> PROCESSANDO...`;

            try {
                const response = await fetch(functionUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        nome: document.getElementById('nome').value,
                        email: document.getElementById('email').value,
                        total: itemValor,
                        itens: [{ nome: itemNome, preco: itemValor, qtd: 1 }]
                    })
                });

                const data = await response.json();
                if (data.init_point) {
                    window.location.href = data.init_point;
                } else {
                    throw new Error();
                }
            } catch (err) {
                alert("Erro ao gerar pagamento. Tente novamente.");
                btn.disabled = false;
                btn.innerHTML = "PAGAR AGORA";
            }
        };
    </script>
</body>
</html>
```
🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# mercadopago_supabase/services/servicos.json
```
{
  "servicos": [
    {
      "id": "dev_web",
      "categoria": "Desenvolvimento",
      "nome": "Desenvolvimento Web",
      "descricao": "Sistemas web personalizados e sites institucionais responsivos.",
      "preco": 3500.00,
      "icone": "developer_mode_tv"
    },
    {
      "id": "trafego_pago",
      "categoria": "Marketing",
      "nome": "Tráfego Pago",
      "descricao": "Gestão estratégica de anúncios Google e Meta Ads para conversão.",
      "preco": 1500.00,
      "icone": "query_stats"
    },
    {
      "id": "consultoria_tec",
      "categoria": "Sistemas",
      "nome": "Consultoria Técnica",
      "descricao": "Análise de sistemas e arquitetura de banco de dados.",
      "preco": 1000.00,
      "icone": "terminal"
    },
    {
      "id": "pdf_misterioso",
      "categoria": "Infoproduto",
      "nome": "PDF Misterioso",
      "descricao": "Acesso a documentação desse sistema",
      "preco": 2.00,
      "icone": "picture_as_pdf"
    }
  ]
}
```
🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# mercadopago_supabase/sucesso.html
```
<!DOCTYPE html>
<html class="dark" lang="pt-BR">
<head>
    <meta charset="utf-8"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <title>Pagamento Confirmado | Aristidesbp</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #020617; color: #f8fafc; }
        .glass { background: rgba(30, 41, 59, 0.4); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.1); }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="max-w-md w-full glass rounded-3xl p-10 text-center shadow-2xl border-green-500/20">
        <div class="size-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-green-500/20">
            <span class="material-symbols-outlined text-white text-4xl">check_circle</span>
        </div>
        
        <h1 class="text-3xl font-black uppercase tracking-tight mb-2">Sucesso!</h1>
        <p class="text-slate-400 mb-8">Recebemos o seu pagamento. O seu projeto ou produto já está em processamento.</p>

        <div class="bg-slate-900/50 rounded-2xl p-6 border border-white/5 mb-8 text-left">
            <h3 class="text-xs font-bold uppercase text-blue-500 mb-4 tracking-widest">Próximos Passos</h3>
            <ul class="space-y-4">
                <li class="flex gap-3 text-sm">
                    <span class="material-symbols-outlined text-green-500 text-sm">task_alt</span>
                    <span>Você receberá um e-mail com os detalhes.</span>
                </li>
                <li class="flex gap-3 text-sm">
                    <span class="material-symbols-outlined text-green-500 text-sm">task_alt</span>
                    <span>Entrarei em contato via WhatsApp em até 24h.</span>
                </li>
            </ul>
        </div>

        <a href="index.html" class="inline-flex items-center gap-2 text-blue-500 font-bold hover:text-blue-400 transition-colors">
            <span class="material-symbols-outlined">arrow_back</span>
            Voltar para o site
        </a>
    </div>
</body>
</html>
```
🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# mercadopago_supabase/supabase/.gitignore
```
# Supabase
.branches
.temp

# dotenvx
.env.keys
.env.local
.env.*.local
```
🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# mercadopago_supabase/supabase/config.toml
```
# For detailed configuration reference documentation, visit:
# https://supabase.com/docs/guides/local-development/cli/config
# A string used to distinguish different Supabase projects on the same host. Defaults to the
# working directory name when running `supabase init`.
project_id = "aristidesbp.github.io"

[api]
enabled = true
# Port to use for the API URL.
port = 54321
# Schemas to expose in your API. Tables, views and stored procedures in this schema will get API
# endpoints. `public` and `graphql_public` schemas are included by default.
schemas = ["public", "graphql_public"]
# Extra schemas to add to the search_path of every request.
extra_search_path = ["public", "extensions"]
# The maximum number of rows returns from a view, table, or stored procedure. Limits payload size
# for accidental or malicious requests.
max_rows = 1000

[api.tls]
# Enable HTTPS endpoints locally using a self-signed certificate.
enabled = false
# Paths to self-signed certificate pair.
# cert_path = "../certs/my-cert.pem"
# key_path = "../certs/my-key.pem"

[db]
# Port to use for the local database URL.
port = 54322
# Port used by db diff command to initialize the shadow database.
shadow_port = 54320
# Maximum amount of time to wait for health check when starting the local database.
health_timeout = "2m"
# The database major version to use. This has to be the same as your remote database's. Run `SHOW
# server_version;` on the remote database to check.
major_version = 17

[db.pooler]
enabled = false
# Port to use for the local connection pooler.
port = 54329
# Specifies when a server connection can be reused by other clients.
# Configure one of the supported pooler modes: `transaction`, `session`.
pool_mode = "transaction"
# How many server connections to allow per user/database pair.
default_pool_size = 20
# Maximum number of client connections allowed.
max_client_conn = 100

# [db.vault]
# secret_key = "env(SECRET_VALUE)"

[db.migrations]
# If disabled, migrations will be skipped during a db push or reset.
enabled = true
# Specifies an ordered list of schema files that describe your database.
# Supports glob patterns relative to supabase directory: "./schemas/*.sql"
schema_paths = []

[db.seed]
# If enabled, seeds the database after migrations during a db reset.
enabled = true
# Specifies an ordered list of seed files to load during db reset.
# Supports glob patterns relative to supabase directory: "./seeds/*.sql"
sql_paths = ["./seed.sql"]

[db.network_restrictions]
# Enable management of network restrictions.
enabled = false
# List of IPv4 CIDR blocks allowed to connect to the database.
# Defaults to allow all IPv4 connections. Set empty array to block all IPs.
allowed_cidrs = ["0.0.0.0/0"]
# List of IPv6 CIDR blocks allowed to connect to the database.
# Defaults to allow all IPv6 connections. Set empty array to block all IPs.
allowed_cidrs_v6 = ["::/0"]

[realtime]
enabled = true
# Bind realtime via either IPv4 or IPv6. (default: IPv4)
# ip_version = "IPv6"
# The maximum length in bytes of HTTP request headers. (default: 4096)
# max_header_length = 4096

[studio]
enabled = true
# Port to use for Supabase Studio.
port = 54323
# External URL of the API server that frontend connects to.
api_url = "http://127.0.0.1"
# OpenAI API Key to use for Supabase AI in the Supabase Studio.
openai_api_key = "env(OPENAI_API_KEY)"

# Email testing server. Emails sent with the local dev setup are not actually sent - rather, they
# are monitored, and you can view the emails that would have been sent from the web interface.
[inbucket]
enabled = true
# Port to use for the email testing server web interface.
port = 54324
# Uncomment to expose additional ports for testing user applications that send emails.
# smtp_port = 54325
# pop3_port = 54326
# admin_email = "admin@email.com"
# sender_name = "Admin"

[storage]
enabled = true
# The maximum file size allowed (e.g. "5MB", "500KB").
file_size_limit = "50MiB"

# Uncomment to configure local storage buckets
# [storage.buckets.images]
# public = false
# file_size_limit = "50MiB"
# allowed_mime_types = ["image/png", "image/jpeg"]
# objects_path = "./images"

# Allow connections via S3 compatible clients
[storage.s3_protocol]
enabled = true

# Image transformation API is available to Supabase Pro plan.
# [storage.image_transformation]
# enabled = true

# Store analytical data in S3 for running ETL jobs over Iceberg Catalog
# This feature is only available on the hosted platform.
[storage.analytics]
enabled = false
max_namespaces = 5
max_tables = 10
max_catalogs = 2

# Analytics Buckets is available to Supabase Pro plan.
# [storage.analytics.buckets.my-warehouse]

# Store vector embeddings in S3 for large and durable datasets
# This feature is only available on the hosted platform.
[storage.vector]
enabled = false
max_buckets = 10
max_indexes = 5

# Vector Buckets is available to Supabase Pro plan.
# [storage.vector.buckets.documents-openai]

[auth]
enabled = true
# The base URL of your website. Used as an allow-list for redirects and for constructing URLs used
# in emails.
site_url = "http://127.0.0.1:3000"
# A list of *exact* URLs that auth providers are permitted to redirect to post authentication.
additional_redirect_urls = ["https://127.0.0.1:3000"]
# How long tokens are valid for, in seconds. Defaults to 3600 (1 hour), maximum 604,800 (1 week).
jwt_expiry = 3600
# JWT issuer URL. If not set, defaults to the local API URL (http://127.0.0.1:<port>/auth/v1).
# jwt_issuer = ""
# Path to JWT signing key. DO NOT commit your signing keys file to git.
# signing_keys_path = "./signing_keys.json"
# If disabled, the refresh token will never expire.
enable_refresh_token_rotation = true
# Allows refresh tokens to be reused after expiry, up to the specified interval in seconds.
# Requires enable_refresh_token_rotation = true.
refresh_token_reuse_interval = 10
# Allow/disallow new user signups to your project.
enable_signup = true
# Allow/disallow anonymous sign-ins to your project.
enable_anonymous_sign_ins = false
# Allow/disallow testing manual linking of accounts
enable_manual_linking = false
# Passwords shorter than this value will be rejected as weak. Minimum 6, recommended 8 or more.
minimum_password_length = 6
# Passwords that do not meet the following requirements will be rejected as weak. Supported values
# are: `letters_digits`, `lower_upper_letters_digits`, `lower_upper_letters_digits_symbols`
password_requirements = ""

[auth.rate_limit]
# Number of emails that can be sent per hour. Requires auth.email.smtp to be enabled.
email_sent = 2
# Number of SMS messages that can be sent per hour. Requires auth.sms to be enabled.
sms_sent = 30
# Number of anonymous sign-ins that can be made per hour per IP address. Requires enable_anonymous_sign_ins = true.
anonymous_users = 30
# Number of sessions that can be refreshed in a 5 minute interval per IP address.
token_refresh = 150
# Number of sign up and sign-in requests that can be made in a 5 minute interval per IP address (excludes anonymous users).
sign_in_sign_ups = 30
# Number of OTP / Magic link verifications that can be made in a 5 minute interval per IP address.
token_verifications = 30
# Number of Web3 logins that can be made in a 5 minute interval per IP address.
web3 = 30

# Configure one of the supported captcha providers: `hcaptcha`, `turnstile`.
# [auth.captcha]
# enabled = true
# provider = "hcaptcha"
# secret = ""

[auth.email]
# Allow/disallow new user signups via email to your project.
enable_signup = true
# If enabled, a user will be required to confirm any email change on both the old, and new email
# addresses. If disabled, only the new email is required to confirm.
double_confirm_changes = true
# If enabled, users need to confirm their email address before signing in.
enable_confirmations = false
# If enabled, users will need to reauthenticate or have logged in recently to change their password.
secure_password_change = false
# Controls the minimum amount of time that must pass before sending another signup confirmation or password reset email.
max_frequency = "1s"
# Number of characters used in the email OTP.
otp_length = 6
# Number of seconds before the email OTP expires (defaults to 1 hour).
otp_expiry = 3600

# Use a production-ready SMTP server
# [auth.email.smtp]
# enabled = true
# host = "smtp.sendgrid.net"
# port = 587
# user = "apikey"
# pass = "env(SENDGRID_API_KEY)"
# admin_email = "admin@email.com"
# sender_name = "Admin"

# Uncomment to customize email template
# [auth.email.template.invite]
# subject = "You have been invited"
# content_path = "./supabase/templates/invite.html"

# Uncomment to customize notification email template
# [auth.email.notification.password_changed]
# enabled = true
# subject = "Your password has been changed"
# content_path = "./templates/password_changed_notification.html"

[auth.sms]
# Allow/disallow new user signups via SMS to your project.
enable_signup = false
# If enabled, users need to confirm their phone number before signing in.
enable_confirmations = false
# Template for sending OTP to users
template = "Your code is {{ .Code }}"
# Controls the minimum amount of time that must pass before sending another sms otp.
max_frequency = "5s"

# Use pre-defined map of phone number to OTP for testing.
# [auth.sms.test_otp]
# 4152127777 = "123456"

# Configure logged in session timeouts.
# [auth.sessions]
# Force log out after the specified duration.
# timebox = "24h"
# Force log out if the user has been inactive longer than the specified duration.
# inactivity_timeout = "8h"

# This hook runs before a new user is created and allows developers to reject the request based on the incoming user object.
# [auth.hook.before_user_created]
# enabled = true
# uri = "pg-functions://postgres/auth/before-user-created-hook"

# This hook runs before a token is issued and allows you to add additional claims based on the authentication method used.
# [auth.hook.custom_access_token]
# enabled = true
# uri = "pg-functions://<database>/<schema>/<hook_name>"

# Configure one of the supported SMS providers: `twilio`, `twilio_verify`, `messagebird`, `textlocal`, `vonage`.
[auth.sms.twilio]
enabled = false
account_sid = ""
message_service_sid = ""
# DO NOT commit your Twilio auth token to git. Use environment variable substitution instead:
auth_token = "env(SUPABASE_AUTH_SMS_TWILIO_AUTH_TOKEN)"

# Multi-factor-authentication is available to Supabase Pro plan.
[auth.mfa]
# Control how many MFA factors can be enrolled at once per user.
max_enrolled_factors = 10

# Control MFA via App Authenticator (TOTP)
[auth.mfa.totp]
enroll_enabled = false
verify_enabled = false

# Configure MFA via Phone Messaging
[auth.mfa.phone]
enroll_enabled = false
verify_enabled = false
otp_length = 6
template = "Your code is {{ .Code }}"
max_frequency = "5s"

# Configure MFA via WebAuthn
# [auth.mfa.web_authn]
# enroll_enabled = true
# verify_enabled = true

# Use an external OAuth provider. The full list of providers are: `apple`, `azure`, `bitbucket`,
# `discord`, `facebook`, `github`, `gitlab`, `google`, `keycloak`, `linkedin_oidc`, `notion`, `twitch`,
# `twitter`, `x`, `slack`, `spotify`, `workos`, `zoom`.
[auth.external.apple]
enabled = false
client_id = ""
# DO NOT commit your OAuth provider secret to git. Use environment variable substitution instead:
secret = "env(SUPABASE_AUTH_EXTERNAL_APPLE_SECRET)"
# Overrides the default auth redirectUrl.
redirect_uri = ""
# Overrides the default auth provider URL. Used to support self-hosted gitlab, single-tenant Azure,
# or any other third-party OIDC providers.
url = ""
# If enabled, the nonce check will be skipped. Required for local sign in with Google auth.
skip_nonce_check = false
# If enabled, it will allow the user to successfully authenticate when the provider does not return an email address.
email_optional = false

# Allow Solana wallet holders to sign in to your project via the Sign in with Solana (SIWS, EIP-4361) standard.
# You can configure "web3" rate limit in the [auth.rate_limit] section and set up [auth.captcha] if self-hosting.
[auth.web3.solana]
enabled = false

# Use Firebase Auth as a third-party provider alongside Supabase Auth.
[auth.third_party.firebase]
enabled = false
# project_id = "my-firebase-project"

# Use Auth0 as a third-party provider alongside Supabase Auth.
[auth.third_party.auth0]
enabled = false
# tenant = "my-auth0-tenant"
# tenant_region = "us"

# Use AWS Cognito (Amplify) as a third-party provider alongside Supabase Auth.
[auth.third_party.aws_cognito]
enabled = false
# user_pool_id = "my-user-pool-id"
# user_pool_region = "us-east-1"

# Use Clerk as a third-party provider alongside Supabase Auth.
[auth.third_party.clerk]
enabled = false
# Obtain from https://clerk.com/setup/supabase
# domain = "example.clerk.accounts.dev"

# OAuth server configuration
[auth.oauth_server]
# Enable OAuth server functionality
enabled = false
# Path for OAuth consent flow UI
authorization_url_path = "/oauth/consent"
# Allow dynamic client registration
allow_dynamic_registration = false

[edge_runtime]
enabled = true
# Supported request policies: `oneshot`, `per_worker`.
# `per_worker` (default) — enables hot reload during local development.
# `oneshot` — fallback mode if hot reload causes issues (e.g. in large repos or with symlinks).
policy = "per_worker"
# Port to attach the Chrome inspector for debugging edge functions.
inspector_port = 8083
# The Deno major version to use.
deno_version = 2

# [edge_runtime.secrets]
# secret_key = "env(SECRET_VALUE)"

[analytics]
enabled = true
port = 54327
# Configure one of the supported backends: `postgres`, `bigquery`.
backend = "postgres"

# Experimental features may be deprecated any time
[experimental]
# Configures Postgres storage engine to use OrioleDB (S3)
orioledb_version = ""
# Configures S3 bucket URL, eg. <bucket_name>.s3-<region>.amazonaws.com
s3_host = "env(S3_HOST)"
# Configures S3 bucket region, eg. us-east-1
s3_region = "env(S3_REGION)"
# Configures AWS_ACCESS_KEY_ID for S3 bucket
s3_access_key = "env(S3_ACCESS_KEY)"
# Configures AWS_SECRET_ACCESS_KEY for S3 bucket
s3_secret_key = "env(S3_SECRET_KEY)"

[functions.checkout]
enabled = true
verify_jwt = true
import_map = "./functions/checkout/deno.json"
# Uncomment to specify a custom file path to the entrypoint.
# Supported file extensions are: .ts, .js, .mjs, .jsx, .tsx
entrypoint = "./functions/checkout/index.ts"
# Specifies static files to be bundled with the function. Supports glob patterns.
# For example, if you want to serve static HTML pages in your function:
# static_files = [ "./functions/checkout/*.html" ]
```
🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# mercadopago_supabase/supabase/functions/checkout/.npmrc
```
# Configuration for private npm package dependencies
# For more information on using private registries with Edge Functions, see:
# https://supabase.com/docs/guides/functions/import-maps#importing-from-private-registries
```
🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥🟥
# mercadopago_supabase/supabase/functions/checkout/deno.json
```
{
  "imports": {
    "@supabase/functions-js": "jsr:@supabase/functions-js@^2"
  }
}
```
