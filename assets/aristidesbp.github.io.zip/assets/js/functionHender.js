/* (1)->COLOQUE NO SEU HTML:
<div id="functionHender"></div>
<script src="js/portifolio-aristides/functionHender.js"></script>
<script>functionHender();</script>
(2)-> RETIRE AS LINHA (1 & 2) DESTE COMENTARIO!*/

function functionHender() {
const functionHender = document.getElementById("functionHender");
functionHender.innerHTML = `<!-- PAGINA_HTML -->

  <h1> ola mundo</h1>


<!-- /PAGINA_HTML -->
`;}/*## FINAL DA FUNCTION ##*/
