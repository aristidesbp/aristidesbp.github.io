<!DOCTYPE html>
<html class="light" lang="pt-BR"><head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Lista de Entidades com Menu de Navegação Completo</title>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#137fec",
                        "background-light": "#f6f7f8",
                        "background-dark": "#101922",
                    },
                    fontFamily: {
                        "display": ["Inter", "sans-serif"]
                    },
                    borderRadius: {
                        "DEFAULT": "0.25rem",
                        "lg": "0.5rem",
                        "xl": "0.75rem",
                        "full": "9999px"
                    },
                },
            },
        }
    </script>
<style type="text/tailwindcss">
        body {
            font-family: 'Inter', sans-serif;
            -webkit-tap-highlight-color: transparent;
            min-height: max(884px, 100dvh);
        }
        .ios-shadow {
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
    </style>
<style>
    body {
      min-height: max(884px, 100dvh);
    }
  </style>
  </head>
<body class="bg-background-light dark:bg-background-dark min-h-screen font-display">
<header class="sticky top-0 z-20 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-gray-100 dark:border-gray-800">
<div class="flex items-center justify-between px-4 py-4">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-[#111418] dark:text-white cursor-pointer">arrow_back_ios</span>
<h1 class="text-[#111418] dark:text-white text-xl font-bold tracking-tight">Lista de Entidades</h1>
</div>
<div class="flex gap-2">
<button class="p-2 text-[#111418] dark:text-white">
<span class="material-symbols-outlined">filter_list</span>
</button>
</div>
</div>
<div class="px-4 pb-4">
<div class="relative flex items-center">
<span class="material-symbols-outlined absolute left-3 text-gray-400 dark:text-gray-500">search</span>
<input class="w-full h-11 pl-10 pr-4 bg-gray-100 dark:bg-gray-800 border-none rounded-xl text-sm focus:ring-2 focus:ring-primary/50 placeholder:text-gray-500 dark:text-white" placeholder="Pesquisar por nome ou cargo..." type="text"/>
</div>
</div>
</header>
<div class="flex gap-2 px-4 py-3 overflow-x-auto no-scrollbar">
<button class="flex h-8 shrink-0 items-center justify-center gap-x-1 rounded-full bg-primary px-4">
<p class="text-white text-xs font-semibold">Todos</p>
</button>
<button class="flex h-8 shrink-0 items-center justify-center gap-x-1 rounded-full bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 px-4">
<p class="text-[#111418] dark:text-gray-300 text-xs font-medium">Fornecedores</p>
<span class="material-symbols-outlined text-xs text-gray-400">expand_more</span>
</button>
<button class="flex h-8 shrink-0 items-center justify-center gap-x-1 rounded-full bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 px-4">
<p class="text-[#111418] dark:text-gray-300 text-xs font-medium">Clientes</p>
<span class="material-symbols-outlined text-xs text-gray-400">expand_more</span>
</button>
<button class="flex h-8 shrink-0 items-center justify-center gap-x-1 rounded-full bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 px-4">
<p class="text-[#111418] dark:text-gray-300 text-xs font-medium">Parceiros</p>
<span class="material-symbols-outlined text-xs text-gray-400">expand_more</span>
</button>
</div>
<main class="px-4 pb-32">
<div class="space-y-3">
<div class="flex items-center gap-4 bg-white dark:bg-gray-900 p-3 rounded-xl ios-shadow border border-gray-50 dark:border-gray-800 active:bg-gray-50 transition-colors cursor-pointer">
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-12 w-12 shrink-0" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuBCtK2xyE8gXoBQtg59rYcQOCSdSaDz9asC2xiBlAP-cCVH2zNclEak_Sosqp0rwQ8G12nMxxc-MOnSBoxbRyOcfi3mKmLmYwhIRR9Aj9akI6WvPuoN9yHfXMdvPKp7s-SUrYB0f2BE1rHW8k0bdw8LcmuPGTrl65_PpRMNLPgKpaJNdln2AuyFqblKMWcc8zCdM9XMHvGdM272SOZ_MhT98PWPpUbbABtm4CL5K3XAWCEFLtJMia2v5vrqWZ9K7-hwSWTbSepIqbA");'></div>
<div class="flex flex-col flex-1 min-w-0">
<p class="text-[#111418] dark:text-white text-base font-semibold leading-tight truncate">Tech Solutions Ltda</p>
<p class="text-gray-500 dark:text-gray-400 text-xs font-normal leading-normal">Fornecedor</p>
</div>
<div class="flex items-center gap-3">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-[#EA4335] text-xl">mail</span>
<span class="material-symbols-outlined text-[#25D366] text-xl">chat_bubble</span>
</div>
<div class="shrink-0 text-gray-400">
<span class="material-symbols-outlined">chevron_right</span>
</div>
</div>
</div>
<div class="flex items-center gap-4 bg-white dark:bg-gray-900 p-3 rounded-xl ios-shadow border border-gray-50 dark:border-gray-800 active:bg-gray-50 transition-colors cursor-pointer">
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-12 w-12 shrink-0" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuD1z289Glor6T9pFl1iFWtD0YYvRsD8V_NGVuXQjMhovcxFEAaNP0elpwDCnTeXBoqbHsrDYWI65m2CZiO4_YnwAFMOlp6M1W2_V8l507df9FW4H1T4Mz0mTrm18GP5_8UKWjMWSDi0fv4CF_q9sJC98--U2CFCUn3yfmEtF_3JPMnXeUaXb23nNmOxfsxPUVC1vAe6y3MsvHeHoACnpK7MYgNsY_bdF5UDdgbbF5ZmkxYrAh7pEjOLzb829syaAMZtB3Qm_fUIJn8");'></div>
<div class="flex flex-col flex-1 min-w-0">
<p class="text-[#111418] dark:text-white text-base font-semibold leading-tight truncate">Ana Beatriz Silva</p>
<p class="text-gray-500 dark:text-gray-400 text-xs font-normal leading-normal">Gerente de Projetos</p>
</div>
<div class="flex items-center gap-3">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-[#EA4335] text-xl">mail</span>
<span class="material-symbols-outlined text-[#25D366] text-xl">chat_bubble</span>
</div>
<div class="shrink-0 text-gray-400">
<span class="material-symbols-outlined">chevron_right</span>
</div>
</div>
</div>
<div class="flex items-center gap-4 bg-white dark:bg-gray-900 p-3 rounded-xl ios-shadow border border-gray-50 dark:border-gray-800 active:bg-gray-50 transition-colors cursor-pointer">
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-12 w-12 shrink-0" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuBmLtJ9hE5o3b2k48RhB0pwFiT_ENsIPxcwNpL59eF76fkaHqZE67kiov2r7-wknfH4YSj9EdkCcS8NhoSx-vcDyfM8XQ91lbm61RVk6CCb1i8Nn7bF_74lEt6jD1dCBwVMbqFAQEo7ybfpO7YtLtvB6uzwrOOW5PX2604S3Y6-lwEIndzrxrL8NAbddP3IutTmna7vkfNGvHqMccPhnLg-meV5_zTE75H96wBnfZ_mYKSy7i8wwEmrdkqzsKSQq2VpasjmC28nVm0");'></div>
<div class="flex flex-col flex-1 min-w-0">
<p class="text-[#111418] dark:text-white text-base font-semibold leading-tight truncate">Global Logistics S.A.</p>
<p class="text-gray-500 dark:text-gray-400 text-xs font-normal leading-normal">Parceiro Estratégico</p>
</div>
<div class="flex items-center gap-3">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-[#EA4335] text-xl">mail</span>
<span class="material-symbols-outlined text-[#25D366] text-xl">chat_bubble</span>
</div>
<div class="shrink-0 text-gray-400">
<span class="material-symbols-outlined">chevron_right</span>
</div>
</div>
</div>
<div class="flex items-center gap-4 bg-white dark:bg-gray-900 p-3 rounded-xl ios-shadow border border-gray-50 dark:border-gray-800 active:bg-gray-50 transition-colors cursor-pointer">
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-12 w-12 shrink-0" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuC21VJSwJE4S8KXY4kmUk8ykx6Q-mCvvhjv3aTBi7bQ5SEI1nsScjWtJjnbPi4P2mZQx25hISDTVcAYehgjaSA-oN8HJA2DJlXogMwQ0Zfq5M-1iiN-3oxY45Sw-uKX8F7Fa6lNZRsxA99TZQmsQnN3E3SYB0aMU3YntSUZFObz5-uIRB1hqvF0WD3qYmyr0DVrQCG007ZwAwLacCseJl-VDlxPxi0AaPZbwxiyFxfntn5qGT6R-_0QCf6W2BvjSGMpIWPha__cIg8");'></div>
<div class="flex flex-col flex-1 min-w-0">
<p class="text-[#111418] dark:text-white text-base font-semibold leading-tight truncate">Alpha Marketing Hub</p>
<p class="text-gray-500 dark:text-gray-400 text-xs font-normal leading-normal">Cliente Premium</p>
</div>
<div class="flex items-center gap-3">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-[#EA4335] text-xl">mail</span>
<span class="material-symbols-outlined text-[#25D366] text-xl">chat_bubble</span>
</div>
<div class="shrink-0 text-gray-400">
<span class="material-symbols-outlined">chevron_right</span>
</div>
</div>
</div>
<div class="flex items-center gap-4 bg-white dark:bg-gray-900 p-3 rounded-xl ios-shadow border border-gray-50 dark:border-gray-800 active:bg-gray-50 transition-colors cursor-pointer">
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-12 w-12 shrink-0" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuAwbN-1fuY5YV4jNhSCXgcCzwhR_E7a1IvyssYnHc5cP7wqnB0s_FydJ-v-usYWXxomIUCfWBMooW4tai7NQeP0ZmVa0xTbnVhW-nMbiNTiajdAlO42B5z5noLeGBXTowyqLVIEEbQk7NsCwVAz7Q3zRnX8SW1kXnP79_8ALo_iG-i2y2u0qVCCh9H7DOeIMDz9BE3_uMz7Lt6MTH-w_nhnCrZ7wAxDS9AtYU5P-WcwlqcUozNj5H-A4LieOlLq67SM6QcMxBRIlhc");'></div>
<div class="flex flex-col flex-1 min-w-0">
<p class="text-[#111418] dark:text-white text-base font-semibold leading-tight truncate">Ricardo Oliveira</p>
<p class="text-gray-500 dark:text-gray-400 text-xs font-normal leading-normal">Diretor Comercial</p>
</div>
<div class="flex items-center gap-3">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-[#EA4335] text-xl">mail</span>
<span class="material-symbols-outlined text-[#25D366] text-xl">chat_bubble</span>
</div>
<div class="shrink-0 text-gray-400">
<span class="material-symbols-outlined">chevron_right</span>
</div>
</div>
</div>
<div class="flex items-center gap-4 bg-white dark:bg-gray-900 p-3 rounded-xl ios-shadow border border-gray-50 dark:border-gray-800 active:bg-gray-50 transition-colors cursor-pointer">
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-12 w-12 shrink-0" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuAkS5eUXvlKYq4YXROpk6bsdhOg-122tWz4n4BCfmWoUwOYJKce26byWSwpxIKTKEbVOAauEXH0ZIb_FRLimmJhm6YermmlrCifJxpgqxPq309adg80FpgnkRhVt8LTUoPQy2hq9xz5lrwhyRvFRgYZ9LfYuiqwV2kSgh3BDPUyRy4nGrb7L_BIlvDeGUFIzAC2b6kDkqlAiOAZT6POhNhlSqT3fpzpxGIfjFALgx_fRgsaXw_Oyty2CtKpwv-xDkR6nuk77ks6LeI");'></div>
<div class="flex flex-col flex-1 min-w-0">
<p class="text-[#111418] dark:text-white text-base font-semibold leading-tight truncate">Eco Friendly Supplies</p>
<p class="text-gray-500 dark:text-gray-400 text-xs font-normal leading-normal">Fornecedor</p>
</div>
<div class="flex items-center gap-3">
<div class="flex items-center gap-2">
<span class="material-symbols-outlined text-[#EA4335] text-xl">mail</span>
<span class="material-symbols-outlined text-[#25D366] text-xl">chat_bubble</span>
</div>
<div class="shrink-0 text-gray-400">
<span class="material-symbols-outlined">chevron_right</span>
</div>
</div>
</div>
</div>
</main>
<button class="fixed bottom-24 right-6 w-14 h-14 bg-primary text-white rounded-full shadow-lg flex items-center justify-center hover:bg-primary/90 active:scale-95 transition-all z-30">
<span class="material-symbols-outlined text-3xl">add</span>
</button>
<nav class="fixed bottom-0 left-0 right-0 bg-white/90 dark:bg-background-dark/90 backdrop-blur-lg border-t border-gray-100 dark:border-gray-800 h-20 flex items-center justify-around px-2 z-20 pb-4">
<div class="flex flex-col items-center gap-1 text-gray-400 min-w-[64px]">
<span class="material-symbols-outlined">logout</span>
<span class="text-[10px] font-medium">Sair</span>
</div>
<div class="flex flex-col items-center gap-1 text-primary min-w-[64px]">
<span class="material-symbols-outlined">group</span>
<span class="text-[10px] font-medium">Entidades</span>
</div>
<div class="flex flex-col items-center gap-1 text-gray-400 min-w-[64px]">
<span class="material-symbols-outlined">payments</span>
<span class="text-[10px] font-medium">Parcelas</span>
</div>
<div class="flex flex-col items-center gap-1 text-gray-400 min-w-[64px]">
<span class="material-symbols-outlined">dashboard</span>
<span class="text-[10px] font-medium">Painel</span>
</div>
<div class="flex flex-col items-center gap-1 text-gray-400 min-w-[64px]">
<span class="material-symbols-outlined">settings</span>
<span class="text-[10px] font-medium">Ajustes</span>
</div>
</nav>

</body></html>