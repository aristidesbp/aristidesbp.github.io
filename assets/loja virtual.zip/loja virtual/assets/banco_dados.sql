CREATE TABLE produtos (nome TEXT, categoria TEXT, preco REAL);
INSERT INTO produtos VALUES ('bola', 'produto', 10);
INSERT INTO produtos VALUES ('carrinho', 'produto', 5);
