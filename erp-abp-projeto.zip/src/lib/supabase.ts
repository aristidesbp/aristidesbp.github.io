import { createClient } from '@supabase/supabase-js';

const DEFAULT_URL = 'https://cbsfujkzozgcnkjahvoj.supabase.co';
const DEFAULT_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNic2Z1amt6b3pnY25ramFodm9qIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYxODQwODEsImV4cCI6MjEwMTc2MDA4MX0.8s42MDYblfaTn6GiXo9NE8r4EISihjXCUHhtVaPJ4u4';

function local(key: string): string | null {
  if (typeof window === 'undefined') return null;
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

export const SUPABASE_URL = local('erp_abp_supabase_url') || DEFAULT_URL;
export const SUPABASE_ANON_KEY = local('erp_abp_supabase_key') || DEFAULT_KEY;

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

export function isOnline(): boolean {
  return typeof navigator === 'undefined' ? true : navigator.onLine !== false;
}
