import { supabase, isOnline } from './supabase';

export interface SessionUser {
  id: string;
  username: string;
  nome: string;
  papel: string;
}

const SESSION_KEY = 'erp_abp_session';
const OFFLINE_KEY = 'erp_abp_offline_credentials';

/** Credenciais padrão de primeiro acesso. */
export const DEFAULT_USERNAME = 'admin';
export const DEFAULT_PASSWORD = 'admin';

export async function sha256(text: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export function getSession(): SessionUser | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as SessionUser) : null;
  } catch {
    return null;
  }
}

export function setSession(user: SessionUser | null): void {
  if (typeof window === 'undefined') return;
  if (user) localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  else localStorage.removeItem(SESSION_KEY);
}

function cacheOfflineCredentials(username: string, hash: string, user: SessionUser) {
  try {
    localStorage.setItem(OFFLINE_KEY, JSON.stringify({ username, hash, user }));
  } catch {
    /* ignore */
  }
}

async function offlineLogin(username: string, password: string): Promise<SessionUser | null> {
  const hash = await sha256(password);
  try {
    const raw = localStorage.getItem(OFFLINE_KEY);
    if (raw) {
      const cached = JSON.parse(raw) as { username: string; hash: string; user: SessionUser };
      if (cached.username === username && cached.hash === hash) return cached.user;
    }
  } catch {
    /* ignore */
  }
  if (username === DEFAULT_USERNAME && password === DEFAULT_PASSWORD) {
    return { id: 'offline-admin', username, nome: 'Administrador', papel: 'admin' };
  }
  return null;
}

export interface LoginResult {
  user: SessionUser | null;
  error?: string;
  bootstrapped?: boolean;
  offline?: boolean;
}

/**
 * Autentica contra a tabela `usuarios` do Supabase (fonte da verdade).
 * No primeiro acesso, se não existir nenhum usuário, cria automaticamente
 * o usuário "admin" com a senha "admin".
 */
export async function login(usernameRaw: string, password: string): Promise<LoginResult> {
  const username = usernameRaw.trim().toLowerCase();
  if (!username || !password) return { user: null, error: 'Informe usuário e senha.' };

  if (!isOnline()) {
    const user = await offlineLogin(username, password);
    return user
      ? { user, offline: true }
      : { user: null, error: 'Sem conexão e credenciais offline inválidas.' };
  }

  const hash = await sha256(password);

  try {
    const { data, error } = await supabase
      .from('usuarios')
      .select('id, username, nome, papel, senha_hash, ativo')
      .eq('username', username)
      .maybeSingle();

    if (error) throw error;

    if (data) {
      if (data.ativo === false) return { user: null, error: 'Usuário inativo.' };
      if (data.senha_hash !== hash) return { user: null, error: 'Usuário ou senha inválidos.' };
      const user: SessionUser = {
        id: String(data.id),
        username: data.username,
        nome: data.nome || data.username,
        papel: data.papel || 'operador',
      };
      cacheOfflineCredentials(username, hash, user);
      return { user };
    }

    // Nenhum registro: permite o bootstrap do admin padrão
    if (username === DEFAULT_USERNAME && password === DEFAULT_PASSWORD) {
      const adminHash = await sha256(DEFAULT_PASSWORD);
      const { data: created, error: insertError } = await supabase
        .from('usuarios')
        .insert({
          username: DEFAULT_USERNAME,
          senha_hash: adminHash,
          nome: 'Administrador',
          papel: 'admin',
          ativo: true,
        })
        .select('id, username, nome, papel')
        .maybeSingle();

      const user: SessionUser = created
        ? {
            id: String(created.id),
            username: created.username,
            nome: created.nome || 'Administrador',
            papel: created.papel || 'admin',
          }
        : { id: 'offline-admin', username, nome: 'Administrador', papel: 'admin' };

      cacheOfflineCredentials(username, adminHash, user);
      return { user, bootstrapped: !insertError };
    }

    return { user: null, error: 'Usuário ou senha inválidos.' };
  } catch (err) {
    console.warn('[ERP] Tabela `usuarios` indisponível, tentando modo offline.', err);
    const user = await offlineLogin(username, password);
    return user
      ? { user, offline: true }
      : {
          user: null,
          error:
            'Não foi possível validar no Supabase. Crie a tabela `usuarios` (veja o README) ou use admin/admin.',
        };
  }
}

export async function changePassword(username: string, novaSenha: string): Promise<boolean> {
  try {
    const hash = await sha256(novaSenha);
    const { error } = await supabase
      .from('usuarios')
      .update({ senha_hash: hash })
      .eq('username', username.toLowerCase());
    if (error) throw error;
    return true;
  } catch (err) {
    console.warn('[ERP] Falha ao alterar senha', err);
    return false;
  }
}

export function logout(): void {
  setSession(null);
}
