/* inicio de 0_SCHEMAS_E_SEGURANCA_BASE */
DROP SCHEMA IF EXISTS public CASCADE;
DROP SCHEMA IF EXISTS private CASCADE;

CREATE SCHEMA public;
CREATE SCHEMA private;

GRANT ALL ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO authenticated, anon;
GRANT USAGE ON SCHEMA private TO postgres;

ALTER DEFAULT PRIVILEGES REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;
/* fim de 0_SCHEMAS_E_SEGURANCA_BASE */


/* inicio de 1_TABELAS_PLANOS_SAAS */
CREATE TABLE public.planos (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    nome text NOT NULL UNIQUE,
    limite_empresas integer NOT NULL DEFAULT 1 CHECK (limite_empresas > 0),
    ativo boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.usuarios_planos (
    auth_user_id uuid PRIMARY KEY,
    plano_id uuid NOT NULL REFERENCES public.planos(id) ON DELETE RESTRICT,
    created_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO public.planos (nome, limite_empresas) VALUES 
('Free', 1),
('Pro', 3),
('Enterprise', 9999);
/* fim de 1_TABELAS_PLANOS_SAAS */


/* inicio de 2_NUCLEO_MULTI_TENANT */
CREATE TABLE public.empresas (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    razao_social text NOT NULL,
    nome_fantasia text NOT NULL,
    cnpj text UNIQUE CHECK (cnpj IS NULL OR cnpj ~ '^\d{14}$'),
    permite_estoque_negativo boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.usuarios_empresa (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id uuid NOT NULL REFERENCES public.empresas(id) ON DELETE CASCADE,
    auth_user_id uuid NOT NULL, 
    perfil text NOT NULL CHECK (perfil IN ('admin', 'gerente', 'caixa', 'estoquista')),
    ativo boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE(empresa_id, auth_user_id),
    UNIQUE(empresa_id, id)
);
CREATE INDEX idx_usuarios_empresa_auth ON public.usuarios_empresa(auth_user_id);
/* fim de 2_NUCLEO_MULTI_TENANT */


/* inicio de 3_CADASTROS_BASE */
CREATE TABLE public.pessoas (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id uuid NOT NULL REFERENCES public.empresas(id),
    tipo_pessoa text NOT NULL CHECK (tipo_pessoa IN ('cliente', 'fornecedor', 'funcionario')),
    nome_completo text NOT NULL,
    documento text,
    telefone text,
    email text,
    endereco jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE(empresa_id, id)
);
CREATE INDEX idx_pessoas_empresa ON public.pessoas(empresa_id);

CREATE TABLE public.produtos (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id uuid NOT NULL REFERENCES public.empresas(id),
    codigo_barras text,
    nome text NOT NULL,
    categoria text NOT NULL DEFAULT 'Geral',
    unidade_medida text NOT NULL DEFAULT 'UN',
    fator_conversao numeric(15,4) NOT NULL DEFAULT 1 CHECK (fator_conversao > 0),
    preco_custo numeric(15,4) NOT NULL DEFAULT 0 CHECK (preco_custo >= 0),
    preco_venda numeric(15,2) NOT NULL DEFAULT 0 CHECK (preco_venda >= 0),
    estoque_minimo numeric(15,4) NOT NULL DEFAULT 0,
    estoque_atual numeric(15,4) NOT NULL DEFAULT 0,
    ativo boolean NOT NULL DEFAULT true,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE(empresa_id, id)
);
CREATE INDEX idx_produtos_empresa ON public.produtos(empresa_id);
/* fim de 3_CADASTROS_BASE */


/* inicio de 4_OPERACIONAL_E_FINANCEIRO */
CREATE TABLE public.vendas (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id uuid NOT NULL REFERENCES public.empresas(id),
    cliente_id uuid,
    vendedor_id uuid NOT NULL,
    status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'concluida', 'cancelada')),
    valor_subtotal numeric(15,2) NOT NULL DEFAULT 0 CHECK (valor_subtotal >= 0),
    valor_desconto numeric(15,2) NOT NULL DEFAULT 0 CHECK (valor_desconto >= 0),
    valor_total numeric(15,2) NOT NULL DEFAULT 0 CHECK (valor_total >= 0),
    forma_pagamento text,
    data_venda timestamptz NOT NULL DEFAULT now(),
    data_cancelamento timestamptz,
    UNIQUE(empresa_id, id),
    FOREIGN KEY (empresa_id, cliente_id) REFERENCES public.pessoas(empresa_id, id),
    FOREIGN KEY (empresa_id, vendedor_id) REFERENCES public.usuarios_empresa(empresa_id, id)
);

CREATE TABLE public.itens_venda (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id uuid NOT NULL,
    venda_id uuid NOT NULL,
    produto_id uuid NOT NULL,
    quantidade numeric(15,4) NOT NULL CHECK (quantidade > 0),
    preco_unitario numeric(15,2) NOT NULL CHECK (preco_unitario >= 0),
    subtotal numeric(15,2) GENERATED ALWAYS AS (quantidade * preco_unitario) STORED,
    FOREIGN KEY (empresa_id, venda_id) REFERENCES public.vendas(empresa_id, id) ON DELETE CASCADE,
    FOREIGN KEY (empresa_id, produto_id) REFERENCES public.produtos(empresa_id, id)
);

CREATE TABLE public.estoque_movimentos (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id uuid NOT NULL,
    produto_id uuid NOT NULL,
    venda_id uuid,
    tipo text NOT NULL CHECK (tipo IN ('entrada', 'saida')),
    quantidade numeric(15,4) NOT NULL CHECK (quantidade > 0),
    motivo text NOT NULL,
    auth_user_id uuid,
    data_movimento timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (empresa_id, produto_id) REFERENCES public.produtos(empresa_id, id),
    FOREIGN KEY (empresa_id, venda_id) REFERENCES public.vendas(empresa_id, id)
);

CREATE TABLE public.titulos_financeiros (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id uuid NOT NULL,
    pessoa_id uuid,
    venda_id uuid,
    tipo text NOT NULL CHECK (tipo IN ('receita', 'despesa')),
    descricao text NOT NULL,
    valor numeric(15,2) NOT NULL CHECK (valor > 0),
    status text NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'pago', 'cancelado')),
    data_vencimento date NOT NULL,
    data_pagamento date,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (empresa_id, pessoa_id) REFERENCES public.pessoas(empresa_id, id),
    FOREIGN KEY (empresa_id, venda_id) REFERENCES public.vendas(empresa_id, id)
);

CREATE TABLE public.logs_auditoria (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id uuid,
    auth_user_id uuid,
    acao text NOT NULL,
    tabela text NOT NULL,
    registro_id uuid,
    dados_anteriores jsonb,
    dados_novos jsonb,
    created_at timestamptz NOT NULL DEFAULT now()
);
/* fim de 4_OPERACIONAL_E_FINANCEIRO */


/* inicio de 5_PERMISSOES_FISICAS */
REVOKE ALL ON TABLE public.vendas, public.itens_venda, public.estoque_movimentos, public.titulos_financeiros FROM anon, authenticated;
GRANT SELECT ON TABLE public.vendas, public.itens_venda, public.estoque_movimentos, public.titulos_financeiros TO authenticated;

REVOKE ALL ON TABLE public.logs_auditoria FROM anon, authenticated;
GRANT SELECT ON TABLE public.logs_auditoria TO authenticated;

REVOKE ALL ON TABLE public.empresas, public.pessoas, public.produtos, public.usuarios_empresa FROM anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.empresas, public.pessoas, public.produtos TO authenticated;
GRANT SELECT ON TABLE public.usuarios_empresa TO authenticated;

REVOKE ALL ON TABLE public.planos, public.usuarios_planos FROM anon, authenticated;
GRANT SELECT ON TABLE public.planos, public.usuarios_planos TO authenticated;
/* fim de 5_PERMISSOES_FISICAS */


/* inicio de 6_FUNCOES_BASE_RBAC */
CREATE OR REPLACE FUNCTION public.get_minhas_empresas()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
    SELECT empresa_id FROM public.usuarios_empresa
    WHERE auth_user_id = (current_setting('request.jwt.claims', true)::json->>'sub')::uuid AND ativo = true;
$$;
REVOKE EXECUTE ON FUNCTION public.get_minhas_empresas() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_minhas_empresas() TO authenticated;

CREATE OR REPLACE FUNCTION public.tem_perfil(p_empresa_id uuid, VARIADIC p_perfis text[])
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.usuarios_empresa
        WHERE auth_user_id = (current_setting('request.jwt.claims', true)::json->>'sub')::uuid
          AND empresa_id = p_empresa_id
          AND ativo = true
          AND perfil = ANY(p_perfis)
    );
$$;
REVOKE EXECUTE ON FUNCTION public.tem_perfil(uuid, text[]) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.tem_perfil(uuid, text[]) TO authenticated;
/* fim de 6_FUNCOES_BASE_RBAC */


/* inicio de 7_TRIGGERS_DE_PROTECAO */
CREATE OR REPLACE FUNCTION public.impede_alteracao_empresa_id()
RETURNS trigger LANGUAGE plpgsql SET search_path = '' AS $$
BEGIN
    IF NEW.empresa_id IS DISTINCT FROM OLD.empresa_id THEN
        RAISE EXCEPTION 'Segurança: empresa_id é imutável e não pode ser transferido.';
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_imutable_empresa_pessoas BEFORE UPDATE ON public.pessoas FOR EACH ROW EXECUTE FUNCTION public.impede_alteracao_empresa_id();
CREATE TRIGGER trg_imutable_empresa_produtos BEFORE UPDATE ON public.produtos FOR EACH ROW EXECUTE FUNCTION public.impede_alteracao_empresa_id();
CREATE TRIGGER trg_imutable_empresa_vendas BEFORE UPDATE ON public.vendas FOR EACH ROW EXECUTE FUNCTION public.impede_alteracao_empresa_id();

CREATE OR REPLACE FUNCTION public.fn_auditoria_log()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_empresa_id uuid;
    v_registro_id uuid;
BEGIN
    IF TG_TABLE_NAME = 'empresas' THEN
        v_empresa_id := COALESCE(NEW.id, OLD.id);
        v_registro_id := COALESCE(NEW.id, OLD.id);
    ELSE
        v_empresa_id := COALESCE(NEW.empresa_id, OLD.empresa_id);
        v_registro_id := COALESCE(NEW.id, OLD.id);
    END IF;

    INSERT INTO public.logs_auditoria (empresa_id, auth_user_id, acao, tabela, registro_id, dados_anteriores, dados_novos)
    VALUES (
        v_empresa_id, (current_setting('request.jwt.claims', true)::json->>'sub')::uuid, TG_OP, TG_TABLE_NAME, v_registro_id,
        CASE WHEN TG_OP IN ('UPDATE', 'DELETE') THEN row_to_json(OLD) ELSE NULL END,
        CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN row_to_json(NEW) ELSE NULL END
    );
    RETURN COALESCE(NEW, OLD);
END;
$$;
CREATE TRIGGER trg_audit_empresas AFTER INSERT OR UPDATE OR DELETE ON public.empresas FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_usuarios AFTER INSERT OR UPDATE OR DELETE ON public.usuarios_empresa FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_pessoas AFTER INSERT OR UPDATE OR DELETE ON public.pessoas FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_produtos AFTER INSERT OR UPDATE OR DELETE ON public.produtos FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_vendas AFTER INSERT OR UPDATE OR DELETE ON public.vendas FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_itens AFTER INSERT OR UPDATE OR DELETE ON public.itens_venda FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_estoque AFTER INSERT OR UPDATE OR DELETE ON public.estoque_movimentos FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_financeiro AFTER INSERT OR UPDATE OR DELETE ON public.titulos_financeiros FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();

CREATE OR REPLACE FUNCTION public.impede_alteracao_ledger()
RETURNS trigger LANGUAGE plpgsql SET search_path = '' AS $$
BEGIN
    RAISE EXCEPTION 'Segurança: Ledger imutável. UPDATE e DELETE proibidos.';
END;
$$;
CREATE TRIGGER bloqueia_kardex BEFORE UPDATE OR DELETE ON public.estoque_movimentos FOR EACH ROW EXECUTE FUNCTION public.impede_alteracao_ledger();

CREATE OR REPLACE FUNCTION public.protege_estoque_atual()
RETURNS trigger LANGUAGE plpgsql SET search_path = '' AS $$
BEGIN
    IF NEW.estoque_atual IS DISTINCT FROM OLD.estoque_atual THEN
        IF current_setting('erp.estoque_bypass', true) IS DISTINCT FROM 'on' THEN
            RAISE EXCEPTION 'Segurança: estoque_atual só pode ser alterado via RPC de movimentação.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER tgr_protege_estoque BEFORE UPDATE ON public.produtos FOR EACH ROW EXECUTE FUNCTION public.protege_estoque_atual();
/* fim de 7_TRIGGERS_DE_PROTECAO */


/* inicio de 8_RPCS_PRIVATE_CQRS */
ALTER ROLE authenticated SET search_path = public, private;

CREATE OR REPLACE FUNCTION private.rpc_criar_empresa(
    p_razao_social text,
    p_nome_fantasia text,
    p_cnpj text DEFAULT NULL
)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_empresa_id uuid;
    v_user_id uuid := (current_setting('request.jwt.claims', true)::json->>'sub')::uuid;
    v_cnpj_norm text;
    v_total_empresas integer;
    v_limite_empresas integer;
BEGIN
    IF v_user_id IS NULL THEN RAISE EXCEPTION 'Acesso Negado: Usuário não autenticado.'; END IF;
    IF length(trim(p_razao_social)) < 3 THEN RAISE EXCEPTION 'Validação falhou: Razão social exige mínimo de 3 caracteres.'; END IF;
    IF length(trim(p_nome_fantasia)) < 2 THEN RAISE EXCEPTION 'Validação falhou: Nome fantasia inválido.'; END IF;

    -- Trava lógica para prevenir Race Condition
    PERFORM pg_advisory_xact_lock(hashtext(v_user_id::text));

    SELECT COALESCE(p.limite_empresas, 1) INTO v_limite_empresas
    FROM public.usuarios_planos up
    JOIN public.planos p ON p.id = up.plano_id
    WHERE up.auth_user_id = v_user_id;

    SELECT COUNT(*) INTO v_total_empresas 
    FROM public.usuarios_empresa 
    WHERE auth_user_id = v_user_id AND perfil = 'admin';

    IF v_total_empresas >= v_limite_empresas THEN
        RAISE EXCEPTION 'Acesso Negado: Limite de cota atingido (%).', v_limite_empresas;
    END IF;

    IF p_cnpj IS NOT NULL THEN
        v_cnpj_norm := regexp_replace(p_cnpj, '[^0-9]', '', 'g');
        IF length(v_cnpj_norm) != 14 THEN
            RAISE EXCEPTION 'Validação falhou: CNPJ exige 14 dígitos.';
        END IF;
    END IF;

    INSERT INTO public.empresas (razao_social, nome_fantasia, cnpj)
    VALUES (trim(p_razao_social), trim(p_nome_fantasia), v_cnpj_norm)
    RETURNING id INTO v_empresa_id;

    INSERT INTO public.usuarios_empresa (empresa_id, auth_user_id, perfil)
    VALUES (v_empresa_id, v_user_id, 'admin');

    RETURN v_empresa_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_criar_empresa(text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.rpc_criar_empresa(text, text, text) TO authenticated;

CREATE OR REPLACE FUNCTION private.rpc_gerenciar_usuario(
    p_empresa_id uuid,
    p_acao text,
    p_auth_user_id uuid,
    p_perfil text DEFAULT NULL
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_existe boolean;
    v_admin_id uuid := (current_setting('request.jwt.claims', true)::json->>'sub')::uuid;
BEGIN
    IF NOT public.tem_perfil(p_empresa_id, 'admin') THEN RAISE EXCEPTION 'Acesso Negado.'; END IF;
    IF p_auth_user_id = v_admin_id THEN RAISE EXCEPTION 'Validação falhou: Proibido auto-gerenciamento.'; END IF;
    IF p_acao NOT IN ('convidar', 'alterar_perfil', 'desativar', 'reativar') THEN RAISE EXCEPTION 'Ação inválida.'; END IF;

    IF p_acao IN ('convidar', 'alterar_perfil') THEN
        IF p_perfil IS NULL OR p_perfil NOT IN ('admin', 'gerente', 'caixa', 'estoquista') THEN
            RAISE EXCEPTION 'Perfil inválido.';
        END IF;
    END IF;

    SELECT EXISTS (SELECT 1 FROM public.usuarios_empresa WHERE empresa_id = p_empresa_id AND auth_user_id = p_auth_user_id) INTO v_existe;

    IF p_acao = 'convidar' THEN
        IF v_existe THEN RAISE EXCEPTION 'Usuário já vinculado.'; END IF;
        INSERT INTO public.usuarios_empresa (empresa_id, auth_user_id, perfil, ativo) VALUES (p_empresa_id, p_auth_user_id, p_perfil, true);
    ELSIF p_acao = 'alterar_perfil' THEN
        IF NOT v_existe THEN RAISE EXCEPTION 'Usuário inexistente na empresa.'; END IF;
        UPDATE public.usuarios_empresa SET perfil = p_perfil WHERE empresa_id = p_empresa_id AND auth_user_id = p_auth_user_id;
    ELSIF p_acao = 'desativar' THEN
        IF NOT v_existe THEN RAISE EXCEPTION 'Usuário inexistente na empresa.'; END IF;
        UPDATE public.usuarios_empresa SET ativo = false WHERE empresa_id = p_empresa_id AND auth_user_id = p_auth_user_id;
    ELSIF p_acao = 'reativar' THEN
        IF NOT v_existe THEN RAISE EXCEPTION 'Usuário inexistente na empresa.'; END IF;
        UPDATE public.usuarios_empresa SET ativo = true WHERE empresa_id = p_empresa_id AND auth_user_id = p_auth_user_id;
    END IF;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_gerenciar_usuario(uuid, text, uuid, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.rpc_gerenciar_usuario(uuid, text, uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION private.rpc_iniciar_venda(p_empresa_id uuid, p_cliente_id uuid DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_venda_id uuid;
    v_vendedor_id uuid;
BEGIN
    IF NOT public.tem_perfil(p_empresa_id, 'admin', 'gerente', 'caixa') THEN RAISE EXCEPTION 'Acesso Negado.'; END IF;

    SELECT id INTO v_vendedor_id FROM public.usuarios_empresa 
    WHERE auth_user_id = (current_setting('request.jwt.claims', true)::json->>'sub')::uuid AND empresa_id = p_empresa_id AND ativo = true;
    IF NOT FOUND THEN RAISE EXCEPTION 'Vendedor não vinculado.'; END IF;

    IF p_cliente_id IS NOT NULL THEN
        IF NOT EXISTS (SELECT 1 FROM public.pessoas WHERE id = p_cliente_id AND empresa_id = p_empresa_id) THEN
            RAISE EXCEPTION 'Cliente inexistente na empresa.';
        END IF;
    END IF;

    INSERT INTO public.vendas (empresa_id, cliente_id, vendedor_id, status) VALUES (p_empresa_id, p_cliente_id, v_vendedor_id, 'pendente') RETURNING id INTO v_venda_id;
    RETURN v_venda_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_iniciar_venda(uuid, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.rpc_iniciar_venda(uuid, uuid) TO authenticated;

CREATE OR REPLACE FUNCTION private.rpc_adicionar_item_venda(p_venda_id uuid, p_produto_id uuid, p_quantidade numeric)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_venda RECORD;
    v_preco numeric(15,2);
BEGIN
    IF p_quantidade <= 0 THEN RAISE EXCEPTION 'Quantidade inválida.'; END IF;

    SELECT * INTO v_venda FROM public.vendas WHERE id = p_venda_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Venda inexistente.'; END IF;
    IF v_venda.status != 'pendente' THEN RAISE EXCEPTION 'Acesso Negado: Venda não está pendente.'; END IF;
    IF NOT public.tem_perfil(v_venda.empresa_id, 'admin', 'gerente', 'caixa') THEN RAISE EXCEPTION 'Acesso Negado.'; END IF;

    SELECT preco_venda INTO v_preco FROM public.produtos WHERE id = p_produto_id AND empresa_id = v_venda.empresa_id AND ativo = true;
    IF NOT FOUND THEN RAISE EXCEPTION 'Produto inativo ou inexistente na empresa.'; END IF;

    INSERT INTO public.itens_venda (empresa_id, venda_id, produto_id, quantidade, preco_unitario) VALUES (v_venda.empresa_id, p_venda_id, p_produto_id, p_quantidade, v_preco);

    UPDATE public.vendas SET valor_subtotal = valor_subtotal + (p_quantidade * v_preco), valor_total = valor_total + (p_quantidade * v_preco) WHERE id = p_venda_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_adicionar_item_venda(uuid, uuid, numeric) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.rpc_adicionar_item_venda(uuid, uuid, numeric) TO authenticated;

CREATE OR REPLACE FUNCTION private.rpc_concluir_venda(p_venda_id uuid, p_forma_pagamento text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_venda RECORD;
    v_item RECORD;
    v_permite_negativo boolean;
    v_estoque numeric(15,4);
    v_qtd_itens int;
BEGIN
    SELECT * INTO v_venda FROM public.vendas WHERE id = p_venda_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Venda inexistente.'; END IF;
    IF v_venda.status != 'pendente' THEN RAISE EXCEPTION 'Venda já processada.'; END IF;
    IF NOT public.tem_perfil(v_venda.empresa_id, 'admin', 'gerente', 'caixa') THEN RAISE EXCEPTION 'Acesso Negado.'; END IF;
    IF length(trim(coalesce(p_forma_pagamento, ''))) < 2 THEN RAISE EXCEPTION 'Forma de pagamento inválida.'; END IF;

    SELECT COUNT(*) INTO v_qtd_itens FROM public.itens_venda WHERE venda_id = p_venda_id;
    IF v_qtd_itens = 0 THEN RAISE EXCEPTION 'Proibido concluir venda vazia.'; END IF;

    SELECT permite_estoque_negativo INTO v_permite_negativo FROM public.empresas WHERE id = v_venda.empresa_id;

    PERFORM set_config('erp.estoque_bypass', 'on', true);

    FOR v_item IN SELECT * FROM public.itens_venda WHERE venda_id = p_venda_id LOOP
        UPDATE public.produtos SET estoque_atual = estoque_atual - v_item.quantidade WHERE id = v_item.produto_id RETURNING estoque_atual INTO v_estoque;
        IF v_estoque < 0 AND NOT v_permite_negativo THEN RAISE EXCEPTION 'Estoque insuficiente: Produto ID %.', v_item.produto_id; END IF;

        INSERT INTO public.estoque_movimentos (empresa_id, produto_id, venda_id, tipo, quantidade, motivo, auth_user_id)
        VALUES (v_venda.empresa_id, v_item.produto_id, p_venda_id, 'saida', v_item.quantidade, 'Venda PDV', (current_setting('request.jwt.claims', true)::json->>'sub')::uuid);
    END LOOP;

    INSERT INTO public.titulos_financeiros (empresa_id, pessoa_id, venda_id, tipo, descricao, valor, data_vencimento, status)
    VALUES (v_venda.empresa_id, v_venda.cliente_id, p_venda_id, 'receita', 'Venda #' || substr(p_venda_id::text, 1, 8), v_venda.valor_total, current_date, 'pago');

    UPDATE public.vendas SET status = 'concluida', forma_pagamento = p_forma_pagamento WHERE id = p_venda_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_concluir_venda(uuid, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.rpc_concluir_venda(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION private.rpc_cancelar_venda(p_venda_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_venda RECORD;
    v_item RECORD;
BEGIN
    SELECT * INTO v_venda FROM public.vendas WHERE id = p_venda_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Venda inexistente.'; END IF;
    IF v_venda.status != 'concluida' THEN RAISE EXCEPTION 'Apenas vendas concluídas podem ser canceladas.'; END IF;
    IF NOT public.tem_perfil(v_venda.empresa_id, 'admin', 'gerente') THEN RAISE EXCEPTION 'Acesso Negado.'; END IF;

    PERFORM set_config('erp.estoque_bypass', 'on', true);

    FOR v_item IN SELECT * FROM public.itens_venda WHERE venda_id = p_venda_id LOOP
        UPDATE public.produtos SET estoque_atual = estoque_atual + v_item.quantidade WHERE id = v_item.produto_id;
        INSERT INTO public.estoque_movimentos (empresa_id, produto_id, venda_id, tipo, quantidade, motivo, auth_user_id)
        VALUES (v_venda.empresa_id, v_item.produto_id, p_venda_id, 'entrada', v_item.quantidade, 'Estorno Venda', (current_setting('request.jwt.claims', true)::json->>'sub')::uuid);
    END LOOP;

    UPDATE public.titulos_financeiros SET status = 'cancelado', descricao = descricao || ' (ESTORNADO)' WHERE venda_id = p_venda_id;
    UPDATE public.vendas SET status = 'cancelada', data_cancelamento = now() WHERE id = p_venda_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_cancelar_venda(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.rpc_cancelar_venda(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION private.rpc_ajuste_estoque(p_produto_id uuid, p_tipo text, p_quantidade numeric, p_motivo text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_empresa_id uuid;
    v_permite_negativo boolean;
    v_estoque_atual numeric(15,4);
BEGIN
    IF p_tipo NOT IN ('entrada', 'saida') THEN RAISE EXCEPTION 'Validação falhou: Tipo inválido.'; END IF;
    IF p_quantidade <= 0 THEN RAISE EXCEPTION 'Validação falhou: Quantidade inválida.'; END IF;
    IF length(trim(coalesce(p_motivo, ''))) < 3 THEN RAISE EXCEPTION 'Validação falhou: Motivo obrigatório.'; END IF;

    SELECT empresa_id, estoque_atual INTO v_empresa_id, v_estoque_atual FROM public.produtos WHERE id = p_produto_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Produto inexistente.'; END IF;
    IF NOT public.tem_perfil(v_empresa_id, 'admin', 'gerente', 'estoquista') THEN RAISE EXCEPTION 'Acesso Negado.'; END IF;

    SELECT permite_estoque_negativo INTO v_permite_negativo FROM public.empresas WHERE id = v_empresa_id;

    IF p_tipo = 'saida' AND (v_estoque_atual - p_quantidade) < 0 AND NOT v_permite_negativo THEN
        RAISE EXCEPTION 'Ajuste negado: Resultará em estoque negativo.';
    END IF;

    PERFORM set_config('erp.estoque_bypass', 'on', true);

    IF p_tipo = 'entrada' THEN
        UPDATE public.produtos SET estoque_atual = estoque_atual + p_quantidade WHERE id = p_produto_id;
    ELSE
        UPDATE public.produtos SET estoque_atual = estoque_atual - p_quantidade WHERE id = p_produto_id;
    END IF;

    INSERT INTO public.estoque_movimentos (empresa_id, produto_id, tipo, quantidade, motivo, auth_user_id)
    VALUES (v_empresa_id, p_produto_id, p_tipo, p_quantidade, p_motivo, (current_setting('request.jwt.claims', true)::json->>'sub')::uuid);
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_ajuste_estoque(uuid, text, numeric, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.rpc_ajuste_estoque(uuid, text, numeric, text) TO authenticated;
/* fim de 8_RPCS_PRIVATE_CQRS */


/* inicio de 9_ROW_LEVEL_SECURITY */
ALTER TABLE public.planos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.usuarios_planos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.empresas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.usuarios_empresa ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pessoas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itens_venda ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.estoque_movimentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.titulos_financeiros ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.logs_auditoria ENABLE ROW LEVEL SECURITY;

CREATE POLICY "rls_planos_select" ON public.planos FOR SELECT USING (true);
CREATE POLICY "rls_usuarios_planos_select" ON public.usuarios_planos FOR SELECT USING (auth_user_id = (current_setting('request.jwt.claims', true)::json->>'sub')::uuid);
CREATE POLICY "rls_empresas_select" ON public.empresas FOR SELECT USING (id IN (SELECT public.get_minhas_empresas()));
CREATE POLICY "rls_usuarios_select" ON public.usuarios_empresa FOR SELECT USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa', 'estoquista'));
CREATE POLICY "rls_pessoas_select" ON public.pessoas FOR SELECT USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa', 'estoquista'));
CREATE POLICY "rls_pessoas_insert" ON public.pessoas FOR INSERT WITH CHECK (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa'));
CREATE POLICY "rls_pessoas_update" ON public.pessoas FOR UPDATE USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa')) WITH CHECK (empresa_id IN (SELECT public.get_minhas_empresas()));
CREATE POLICY "rls_produtos_select" ON public.produtos FOR SELECT USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa', 'estoquista'));
CREATE POLICY "rls_produtos_insert" ON public.produtos FOR INSERT WITH CHECK (public.tem_perfil(empresa_id, 'admin', 'gerente'));
CREATE POLICY "rls_produtos_update" ON public.produtos FOR UPDATE USING (public.tem_perfil(empresa_id, 'admin', 'gerente')) WITH CHECK (empresa_id IN (SELECT public.get_minhas_empresas()));
CREATE POLICY "rls_vendas_select" ON public.vendas FOR SELECT USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa'));
CREATE POLICY "rls_itens_select" ON public.itens_venda FOR SELECT USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa'));
CREATE POLICY "rls_estoque_select" ON public.estoque_movimentos FOR SELECT USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa', 'estoquista'));
CREATE POLICY "rls_financeiro_select" ON public.titulos_financeiros FOR SELECT USING (public.tem_perfil(empresa_id, 'admin', 'gerente'));
CREATE POLICY "rls_auditoria_select" ON public.logs_auditoria FOR SELECT USING (public.tem_perfil(empresa_id, 'admin'));
/* fim de 9_ROW_LEVEL_SECURITY */
