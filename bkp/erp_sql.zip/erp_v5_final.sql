/* =====================================================================
   ERP BACKEND MASTER — V5 FINAL (Claude Edition)
   Supabase / PostgreSQL — Candidata à Produção

   Correções em relação à V4:
   1. Bug crítico: fn_auditoria_log agora trata tabelas sem empresa_id (ex: empresas)
   2. RPCs SECURITY DEFINER sensíveis movidas para schema `private`
   3. Nova RPC: rpc_gerenciar_usuario (convidar, alterar perfil, desativar)
   4. Inconsistência de GRANTs em usuarios_empresa resolvida
   ===================================================================== */


/* =====================================================================
   0. SCHEMAS E SEGURANÇA BASE
   ===================================================================== */
-- ATENÇÃO: apenas em desenvolvimento. Em produção, use migrations incrementais.
DROP SCHEMA IF EXISTS public  CASCADE;
DROP SCHEMA IF EXISTS private CASCADE;

CREATE SCHEMA public;
CREATE SCHEMA private; -- RPCs privilegiadas ficam aqui, fora da Data API

GRANT ALL   ON SCHEMA public   TO postgres;
GRANT USAGE ON SCHEMA public   TO authenticated, anon;
GRANT USAGE ON SCHEMA private  TO postgres;       -- roles da aplicação não acessam diretamente

-- Revoga execução pública de funções criadas a partir daqui
ALTER DEFAULT PRIVILEGES REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;


/* =====================================================================
   1. NÚCLEO MULTI-TENANT
   ===================================================================== */
CREATE TABLE public.empresas (
    id                       uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
    razao_social             text        NOT NULL,
    nome_fantasia            text        NOT NULL,
    -- CNPJ armazenado APENAS em dígitos para unicidade real (12345678000190)
    cnpj                     text        UNIQUE
                                         CHECK (cnpj IS NULL OR cnpj ~ '^\d{14}$'),
    permite_estoque_negativo boolean     NOT NULL DEFAULT false,
    created_at               timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.usuarios_empresa (
    id           uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id   uuid NOT NULL REFERENCES public.empresas(id) ON DELETE CASCADE,
    auth_user_id uuid NOT NULL REFERENCES auth.users(id)      ON DELETE CASCADE,
    perfil       text NOT NULL CHECK (perfil IN ('admin', 'gerente', 'caixa', 'estoquista')),
    ativo        boolean     NOT NULL DEFAULT true,
    created_at   timestamptz NOT NULL DEFAULT now(),
    UNIQUE(empresa_id, auth_user_id),
    UNIQUE(empresa_id, id)  -- habilita Compound FKs nas tabelas filhas
);
CREATE INDEX idx_usuarios_empresa_auth ON public.usuarios_empresa(auth_user_id);


/* =====================================================================
   2. CADASTROS BASE
   ===================================================================== */
CREATE TABLE public.pessoas (
    id            uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id    uuid NOT NULL REFERENCES public.empresas(id),
    tipo_pessoa   text NOT NULL CHECK (tipo_pessoa IN ('cliente', 'fornecedor', 'funcionario')),
    nome_completo text NOT NULL,
    documento     text,
    telefone      text,
    email         text,
    endereco      jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at    timestamptz NOT NULL DEFAULT now(),
    UNIQUE(empresa_id, id)
);
CREATE INDEX idx_pessoas_empresa ON public.pessoas(empresa_id);

CREATE TABLE public.produtos (
    id              uuid          DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id      uuid          NOT NULL REFERENCES public.empresas(id),
    codigo_barras   text,
    nome            text          NOT NULL,
    categoria       text          NOT NULL DEFAULT 'Geral',
    unidade_medida  text          NOT NULL DEFAULT 'UN',
    fator_conversao numeric(15,4) NOT NULL DEFAULT 1   CHECK (fator_conversao > 0),
    preco_custo     numeric(15,4) NOT NULL DEFAULT 0   CHECK (preco_custo >= 0),
    preco_venda     numeric(15,2) NOT NULL DEFAULT 0   CHECK (preco_venda >= 0),
    estoque_minimo  numeric(15,4) NOT NULL DEFAULT 0,
    estoque_atual   numeric(15,4) NOT NULL DEFAULT 0,
    ativo           boolean       NOT NULL DEFAULT true,
    created_at      timestamptz   NOT NULL DEFAULT now(),
    UNIQUE(empresa_id, id)
);
CREATE INDEX idx_produtos_empresa ON public.produtos(empresa_id);


/* =====================================================================
   3. OPERACIONAL, LEDGER E FINANCEIRO (Compound FKs)
   ===================================================================== */
CREATE TABLE public.vendas (
    id                uuid          DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id        uuid          NOT NULL REFERENCES public.empresas(id),
    cliente_id        uuid,
    vendedor_id       uuid          NOT NULL,
    status            text          NOT NULL DEFAULT 'pendente'
                                    CHECK (status IN ('pendente', 'concluida', 'cancelada')),
    valor_subtotal    numeric(15,2) NOT NULL DEFAULT 0 CHECK (valor_subtotal >= 0),
    valor_desconto    numeric(15,2) NOT NULL DEFAULT 0 CHECK (valor_desconto >= 0),
    valor_total       numeric(15,2) NOT NULL DEFAULT 0 CHECK (valor_total >= 0),
    forma_pagamento   text,
    data_venda        timestamptz   NOT NULL DEFAULT now(),
    data_cancelamento timestamptz,
    UNIQUE(empresa_id, id),
    FOREIGN KEY (empresa_id, cliente_id)  REFERENCES public.pessoas(empresa_id, id),
    FOREIGN KEY (empresa_id, vendedor_id) REFERENCES public.usuarios_empresa(empresa_id, id)
);

CREATE TABLE public.itens_venda (
    id             uuid          DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id     uuid          NOT NULL,
    venda_id       uuid          NOT NULL,
    produto_id     uuid          NOT NULL,
    quantidade     numeric(15,4) NOT NULL CHECK (quantidade > 0),
    preco_unitario numeric(15,2) NOT NULL CHECK (preco_unitario >= 0),
    subtotal       numeric(15,2) GENERATED ALWAYS AS (quantidade * preco_unitario) STORED,
    FOREIGN KEY (empresa_id, venda_id)   REFERENCES public.vendas(empresa_id, id)   ON DELETE CASCADE,
    FOREIGN KEY (empresa_id, produto_id) REFERENCES public.produtos(empresa_id, id)
);

-- Ledger: INSERT via RPC; UPDATE/DELETE bloqueados por trigger
CREATE TABLE public.estoque_movimentos (
    id             uuid          DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id     uuid          NOT NULL,
    produto_id     uuid          NOT NULL,
    venda_id       uuid,
    tipo           text          NOT NULL CHECK (tipo IN ('entrada', 'saida')),
    quantidade     numeric(15,4) NOT NULL CHECK (quantidade > 0),
    motivo         text          NOT NULL,
    auth_user_id   uuid,
    data_movimento timestamptz   NOT NULL DEFAULT now(),
    FOREIGN KEY (empresa_id, produto_id) REFERENCES public.produtos(empresa_id, id),
    FOREIGN KEY (empresa_id, venda_id)   REFERENCES public.vendas(empresa_id, id)
);

CREATE TABLE public.titulos_financeiros (
    id              uuid          DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id      uuid          NOT NULL,
    pessoa_id       uuid,
    venda_id        uuid,
    tipo            text          NOT NULL CHECK (tipo IN ('receita', 'despesa')),
    descricao       text          NOT NULL,
    valor           numeric(15,2) NOT NULL CHECK (valor > 0),
    status          text          NOT NULL DEFAULT 'pendente'
                                  CHECK (status IN ('pendente', 'pago', 'cancelado')),
    data_vencimento date          NOT NULL,
    data_pagamento  date,
    created_at      timestamptz   NOT NULL DEFAULT now(),
    FOREIGN KEY (empresa_id, pessoa_id) REFERENCES public.pessoas(empresa_id, id),
    FOREIGN KEY (empresa_id, venda_id)  REFERENCES public.vendas(empresa_id, id)
);

CREATE TABLE public.logs_auditoria (
    id               uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id       uuid,       -- NULL quando tabela auditada não tem empresa_id (ex: empresas)
    auth_user_id     uuid,
    acao             text        NOT NULL,
    tabela           text        NOT NULL,
    registro_id      uuid,
    dados_anteriores jsonb,
    dados_novos      jsonb,
    created_at       timestamptz NOT NULL DEFAULT now()
);


/* =====================================================================
   4. PERMISSÕES FÍSICAS (GRANT / REVOKE)
   Duas camadas obrigatórias: GRANT controla o objeto, RLS controla as linhas.
   ===================================================================== */

-- Tabelas transacionais: só leitura via API. Mutação exclusiva por RPCs.
REVOKE ALL ON TABLE
    public.vendas, public.itens_venda,
    public.estoque_movimentos, public.titulos_financeiros
FROM anon, authenticated;
GRANT SELECT ON TABLE
    public.vendas, public.itens_venda,
    public.estoque_movimentos, public.titulos_financeiros
TO authenticated;

-- Auditoria: só leitura. INSERT feito por SECURITY DEFINER via trigger.
REVOKE ALL  ON TABLE public.logs_auditoria FROM anon, authenticated;
GRANT SELECT ON TABLE public.logs_auditoria TO authenticated;

-- Cadastros base: CRUD direto, protegido por RLS.
-- usuarios_empresa: INSERT/UPDATE apenas via RPC de gestão (sem GRANT direto para authenticated)
REVOKE ALL ON TABLE
    public.empresas, public.pessoas, public.produtos, public.usuarios_empresa
FROM anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON TABLE public.empresas,  public.pessoas, public.produtos TO authenticated;
GRANT SELECT                 ON TABLE public.usuarios_empresa TO authenticated;
-- INSERT/UPDATE em usuarios_empresa é feito pelas RPCs SECURITY DEFINER (que bypassam o GRANT)


/* =====================================================================
   5. FUNÇÕES BASE PÚBLICAS (RBAC)
   Ficam em public pois são usadas por RLS policies diretamente.
   ===================================================================== */
CREATE OR REPLACE FUNCTION public.get_minhas_empresas()
RETURNS SETOF uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
    SELECT empresa_id FROM public.usuarios_empresa
    WHERE auth_user_id = auth.uid() AND ativo = true;
$$;
REVOKE EXECUTE ON FUNCTION public.get_minhas_empresas() FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION public.get_minhas_empresas() TO authenticated;

CREATE OR REPLACE FUNCTION public.tem_perfil(p_empresa_id uuid, VARIADIC p_perfis text[])
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.usuarios_empresa
        WHERE auth_user_id = auth.uid()
          AND empresa_id   = p_empresa_id
          AND ativo        = true
          AND perfil       = ANY(p_perfis)
    );
$$;
REVOKE EXECUTE ON FUNCTION public.tem_perfil(uuid, text[]) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION public.tem_perfil(uuid, text[]) TO authenticated;


/* =====================================================================
   6. TRIGGERS DE PROTEÇÃO, AUDITORIA E LEDGER
   ===================================================================== */

-- 6.1 empresa_id imutável
CREATE OR REPLACE FUNCTION public.impede_alteracao_empresa_id()
RETURNS trigger LANGUAGE plpgsql SET search_path = '' AS $$
BEGIN
    IF NEW.empresa_id IS DISTINCT FROM OLD.empresa_id THEN
        RAISE EXCEPTION 'Segurança: empresa_id é imutável e não pode ser transferido.';
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER trg_imutable_empresa_pessoas  BEFORE UPDATE ON public.pessoas  FOR EACH ROW EXECUTE FUNCTION public.impede_alteracao_empresa_id();
CREATE TRIGGER trg_imutable_empresa_produtos BEFORE UPDATE ON public.produtos FOR EACH ROW EXECUTE FUNCTION public.impede_alteracao_empresa_id();
CREATE TRIGGER trg_imutable_empresa_vendas   BEFORE UPDATE ON public.vendas   FOR EACH ROW EXECUTE FUNCTION public.impede_alteracao_empresa_id();

-- 6.2 Auditoria universal
-- CORREÇÃO V5: a tabela `empresas` não possui coluna empresa_id.
-- A função agora resolve o empresa_id de acordo com o TG_TABLE_NAME.
CREATE OR REPLACE FUNCTION public.fn_auditoria_log()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_empresa_id  uuid;
    v_registro_id uuid;
BEGIN
    -- Tabelas onde o próprio `id` é o identificador raiz de tenant
    IF TG_TABLE_NAME = 'empresas' THEN
        v_empresa_id  := COALESCE(NEW.id, OLD.id);
        v_registro_id := COALESCE(NEW.id, OLD.id);
    ELSE
        v_empresa_id  := COALESCE(NEW.empresa_id, OLD.empresa_id);
        v_registro_id := COALESCE(NEW.id, OLD.id);
    END IF;

    INSERT INTO public.logs_auditoria
        (empresa_id, auth_user_id, acao, tabela, registro_id, dados_anteriores, dados_novos)
    VALUES (
        v_empresa_id,
        auth.uid(),
        TG_OP,
        TG_TABLE_NAME,
        v_registro_id,
        CASE WHEN TG_OP IN ('UPDATE', 'DELETE') THEN row_to_json(OLD) ELSE NULL END,
        CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN row_to_json(NEW) ELSE NULL END
    );
    RETURN COALESCE(NEW, OLD);
END;
$$;

-- Auditoria em todas as tabelas sensíveis
CREATE TRIGGER trg_audit_empresas   AFTER INSERT OR UPDATE OR DELETE ON public.empresas           FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_usuarios   AFTER INSERT OR UPDATE OR DELETE ON public.usuarios_empresa   FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_pessoas    AFTER INSERT OR UPDATE OR DELETE ON public.pessoas            FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_produtos   AFTER INSERT OR UPDATE OR DELETE ON public.produtos           FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_vendas     AFTER INSERT OR UPDATE OR DELETE ON public.vendas             FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_itens      AFTER INSERT OR UPDATE OR DELETE ON public.itens_venda        FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_estoque    AFTER INSERT OR UPDATE OR DELETE ON public.estoque_movimentos FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();
CREATE TRIGGER trg_audit_financeiro AFTER INSERT OR UPDATE OR DELETE ON public.titulos_financeiros FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_log();

-- 6.3 Ledger imutável
CREATE OR REPLACE FUNCTION public.impede_alteracao_ledger()
RETURNS trigger LANGUAGE plpgsql SET search_path = '' AS $$
BEGIN
    RAISE EXCEPTION 'Segurança: Ledger imutável. UPDATE e DELETE proibidos.';
END;
$$;
CREATE TRIGGER bloqueia_kardex
    BEFORE UPDATE OR DELETE ON public.estoque_movimentos
    FOR EACH ROW EXECUTE FUNCTION public.impede_alteracao_ledger();

-- 6.4 Proteção do estoque_atual via flag de transação
CREATE OR REPLACE FUNCTION public.protege_estoque_atual()
RETURNS trigger LANGUAGE plpgsql SET search_path = '' AS $$
BEGIN
    IF NEW.estoque_atual IS DISTINCT FROM OLD.estoque_atual THEN
        IF current_setting('erp.estoque_bypass', true) IS DISTINCT FROM 'on' THEN
            RAISE EXCEPTION 'Segurança: estoque_atual só pode ser alterado via RPC de movimentação.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;
CREATE TRIGGER tgr_protege_estoque
    BEFORE UPDATE ON public.produtos
    FOR EACH ROW EXECUTE FUNCTION public.protege_estoque_atual();


/* =====================================================================
   7. RPCs — SCHEMA PRIVATE
   Funções SECURITY DEFINER privilegiadas ficam fora do schema public
   para não serem expostas pela Data API do Supabase.
   O frontend chama via: supabase.rpc('rpc_nome', params)
   — o Supabase resolve o schema pelo search_path da role.

   Para que o frontend consiga chamar funções em `private`, crie
   wrappers públicos finos em `public` que apenas delegam, OU configure
   o search_path da role `authenticated` para incluir `private`.
   A opção mais simples no Supabase é adicionar `private` ao
   search_path padrão da role authenticated:
       ALTER ROLE authenticated SET search_path = public, private;
   ===================================================================== */
ALTER ROLE authenticated SET search_path = public, private;


-- ── RPC: Onboarding — Criar Empresa ─────────────────────────────────
CREATE OR REPLACE FUNCTION private.rpc_criar_empresa(
    p_razao_social  text,
    p_nome_fantasia text,
    p_cnpj          text DEFAULT NULL
)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_empresa_id uuid;
    v_user_id    uuid := auth.uid();
    v_cnpj_norm  text;
BEGIN
    IF v_user_id IS NULL THEN RAISE EXCEPTION 'Usuário não autenticado.'; END IF;
    IF length(trim(p_razao_social))  < 3 THEN RAISE EXCEPTION 'Razão social inválida (mínimo 3 caracteres).'; END IF;
    IF length(trim(p_nome_fantasia)) < 2 THEN RAISE EXCEPTION 'Nome fantasia inválido.'; END IF;

    -- Normaliza CNPJ para somente dígitos antes de persistir
    IF p_cnpj IS NOT NULL THEN
        v_cnpj_norm := regexp_replace(p_cnpj, '[^0-9]', '', 'g');
        IF length(v_cnpj_norm) != 14 THEN
            RAISE EXCEPTION 'CNPJ inválido. Informe 14 dígitos.';
        END IF;
    END IF;

    INSERT INTO public.empresas (razao_social, nome_fantasia, cnpj)
    VALUES (trim(p_razao_social), trim(p_nome_fantasia), v_cnpj_norm)
    RETURNING id INTO v_empresa_id;

    -- Criador entra automaticamente como admin
    INSERT INTO public.usuarios_empresa (empresa_id, auth_user_id, perfil)
    VALUES (v_empresa_id, v_user_id, 'admin');

    RETURN v_empresa_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_criar_empresa(text, text, text) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION private.rpc_criar_empresa(text, text, text) TO authenticated;


-- ── RPC: Gerenciar Usuário da Empresa ───────────────────────────────
-- Unifica: convidar (INSERT), alterar perfil (UPDATE), ativar/desativar.
-- p_acao: 'convidar' | 'alterar_perfil' | 'desativar' | 'reativar'
CREATE OR REPLACE FUNCTION private.rpc_gerenciar_usuario(
    p_empresa_id   uuid,
    p_acao         text,
    p_auth_user_id uuid,                  -- uuid do auth.users alvo
    p_perfil       text DEFAULT NULL      -- obrigatório para 'convidar' e 'alterar_perfil'
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_existe boolean;
BEGIN
    -- Apenas admins gerenciam usuários
    IF NOT public.tem_perfil(p_empresa_id, 'admin') THEN
        RAISE EXCEPTION 'Acesso Negado: apenas admins podem gerenciar usuários.';
    END IF;

    -- Admin não pode gerenciar a si mesmo (evita lock-out acidental)
    IF p_auth_user_id = auth.uid() THEN
        RAISE EXCEPTION 'Você não pode alterar o seu próprio acesso.';
    END IF;

    IF p_acao NOT IN ('convidar', 'alterar_perfil', 'desativar', 'reativar') THEN
        RAISE EXCEPTION 'Ação inválida. Use: convidar, alterar_perfil, desativar, reativar.';
    END IF;

    IF p_acao IN ('convidar', 'alterar_perfil') THEN
        IF p_perfil IS NULL OR p_perfil NOT IN ('admin', 'gerente', 'caixa', 'estoquista') THEN
            RAISE EXCEPTION 'Perfil inválido. Use: admin, gerente, caixa, estoquista.';
        END IF;
    END IF;

    -- Verifica se o auth_user alvo existe no sistema
    IF NOT EXISTS (SELECT 1 FROM auth.users WHERE id = p_auth_user_id) THEN
        RAISE EXCEPTION 'Usuário não encontrado no sistema de autenticação.';
    END IF;

    SELECT EXISTS (
        SELECT 1 FROM public.usuarios_empresa
        WHERE empresa_id = p_empresa_id AND auth_user_id = p_auth_user_id
    ) INTO v_existe;

    IF p_acao = 'convidar' THEN
        IF v_existe THEN
            RAISE EXCEPTION 'Usuário já pertence a esta empresa.';
        END IF;
        INSERT INTO public.usuarios_empresa (empresa_id, auth_user_id, perfil, ativo)
        VALUES (p_empresa_id, p_auth_user_id, p_perfil, true);

    ELSIF p_acao = 'alterar_perfil' THEN
        IF NOT v_existe THEN
            RAISE EXCEPTION 'Usuário não pertence a esta empresa.';
        END IF;
        UPDATE public.usuarios_empresa
        SET perfil = p_perfil
        WHERE empresa_id = p_empresa_id AND auth_user_id = p_auth_user_id;

    ELSIF p_acao = 'desativar' THEN
        IF NOT v_existe THEN
            RAISE EXCEPTION 'Usuário não pertence a esta empresa.';
        END IF;
        UPDATE public.usuarios_empresa
        SET ativo = false
        WHERE empresa_id = p_empresa_id AND auth_user_id = p_auth_user_id;

    ELSIF p_acao = 'reativar' THEN
        IF NOT v_existe THEN
            RAISE EXCEPTION 'Usuário não pertence a esta empresa.';
        END IF;
        UPDATE public.usuarios_empresa
        SET ativo = true
        WHERE empresa_id = p_empresa_id AND auth_user_id = p_auth_user_id;
    END IF;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_gerenciar_usuario(uuid, text, uuid, text) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION private.rpc_gerenciar_usuario(uuid, text, uuid, text) TO authenticated;


-- ── RPC: Iniciar Venda ───────────────────────────────────────────────
CREATE OR REPLACE FUNCTION private.rpc_iniciar_venda(
    p_empresa_id uuid,
    p_cliente_id uuid DEFAULT NULL
)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_venda_id    uuid;
    v_vendedor_id uuid;
BEGIN
    IF NOT public.tem_perfil(p_empresa_id, 'admin', 'gerente', 'caixa') THEN
        RAISE EXCEPTION 'Acesso Negado.';
    END IF;

    SELECT id INTO v_vendedor_id
    FROM public.usuarios_empresa
    WHERE auth_user_id = auth.uid() AND empresa_id = p_empresa_id AND ativo = true;
    IF NOT FOUND THEN RAISE EXCEPTION 'Vendedor não encontrado nesta empresa.'; END IF;

    IF p_cliente_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.pessoas
            WHERE id = p_cliente_id AND empresa_id = p_empresa_id
        ) THEN
            RAISE EXCEPTION 'Cliente inexistente ou não pertence a esta empresa.';
        END IF;
    END IF;

    INSERT INTO public.vendas (empresa_id, cliente_id, vendedor_id, status)
    VALUES (p_empresa_id, p_cliente_id, v_vendedor_id, 'pendente')
    RETURNING id INTO v_venda_id;

    RETURN v_venda_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_iniciar_venda(uuid, uuid) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION private.rpc_iniciar_venda(uuid, uuid) TO authenticated;


-- ── RPC: Adicionar Item na Venda ─────────────────────────────────────
CREATE OR REPLACE FUNCTION private.rpc_adicionar_item_venda(
    p_venda_id   uuid,
    p_produto_id uuid,
    p_quantidade numeric
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_venda RECORD;
    v_preco numeric(15,2);
BEGIN
    IF p_quantidade <= 0 THEN
        RAISE EXCEPTION 'Quantidade deve ser maior que zero.';
    END IF;

    -- FOR UPDATE: bloqueia a venda impedindo race condition com rpc_concluir_venda
    SELECT * INTO v_venda FROM public.vendas WHERE id = p_venda_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Venda não encontrada.'; END IF;
    IF v_venda.status != 'pendente' THEN
        RAISE EXCEPTION 'Itens só podem ser adicionados em vendas pendentes (status atual: %).', v_venda.status;
    END IF;
    IF NOT public.tem_perfil(v_venda.empresa_id, 'admin', 'gerente', 'caixa') THEN
        RAISE EXCEPTION 'Acesso Negado.';
    END IF;

    SELECT preco_venda INTO v_preco
    FROM public.produtos
    WHERE id = p_produto_id AND empresa_id = v_venda.empresa_id AND ativo = true;
    IF NOT FOUND THEN RAISE EXCEPTION 'Produto não encontrado ou inativo nesta empresa.'; END IF;

    INSERT INTO public.itens_venda (empresa_id, venda_id, produto_id, quantidade, preco_unitario)
    VALUES (v_venda.empresa_id, p_venda_id, p_produto_id, p_quantidade, v_preco);

    UPDATE public.vendas
    SET valor_subtotal = valor_subtotal + (p_quantidade * v_preco),
        valor_total    = valor_total    + (p_quantidade * v_preco)
    WHERE id = p_venda_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_adicionar_item_venda(uuid, uuid, numeric) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION private.rpc_adicionar_item_venda(uuid, uuid, numeric) TO authenticated;


-- ── RPC: Concluir Venda ──────────────────────────────────────────────
-- FOR UPDATE: lock transacional garante que duas chamadas simultâneas
-- não gerem duplo processamento. A segunda vai aguardar o lock e falhar
-- no check de status. Isso é proteção contra duplicação, não idempotência.
CREATE OR REPLACE FUNCTION private.rpc_concluir_venda(
    p_venda_id        uuid,
    p_forma_pagamento text
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_venda            RECORD;
    v_item             RECORD;
    v_permite_negativo boolean;
    v_estoque          numeric(15,4);
    v_qtd_itens        int;
BEGIN
    SELECT * INTO v_venda FROM public.vendas WHERE id = p_venda_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Venda não encontrada.'; END IF;
    IF v_venda.status != 'pendente' THEN
        RAISE EXCEPTION 'Transação abortada: venda já está em status "%".', v_venda.status;
    END IF;
    IF NOT public.tem_perfil(v_venda.empresa_id, 'admin', 'gerente', 'caixa') THEN
        RAISE EXCEPTION 'Acesso Negado.';
    END IF;
    IF length(trim(coalesce(p_forma_pagamento, ''))) < 2 THEN
        RAISE EXCEPTION 'Forma de pagamento inválida.';
    END IF;

    SELECT COUNT(*) INTO v_qtd_itens FROM public.itens_venda WHERE venda_id = p_venda_id;
    IF v_qtd_itens = 0 THEN
        RAISE EXCEPTION 'Não é possível concluir uma venda sem itens.';
    END IF;

    SELECT permite_estoque_negativo INTO v_permite_negativo
    FROM public.empresas WHERE id = v_venda.empresa_id;

    PERFORM set_config('erp.estoque_bypass', 'on', true);

    FOR v_item IN SELECT * FROM public.itens_venda WHERE venda_id = p_venda_id LOOP
        UPDATE public.produtos
        SET estoque_atual = estoque_atual - v_item.quantidade
        WHERE id = v_item.produto_id
        RETURNING estoque_atual INTO v_estoque;

        IF v_estoque < 0 AND NOT v_permite_negativo THEN
            RAISE EXCEPTION 'Estoque insuficiente para o produto %.', v_item.produto_id;
        END IF;

        INSERT INTO public.estoque_movimentos
            (empresa_id, produto_id, venda_id, tipo, quantidade, motivo, auth_user_id)
        VALUES
            (v_venda.empresa_id, v_item.produto_id, p_venda_id,
             'saida', v_item.quantidade, 'Venda PDV', auth.uid());
    END LOOP;

    INSERT INTO public.titulos_financeiros
        (empresa_id, pessoa_id, venda_id, tipo, descricao, valor, data_vencimento, status)
    VALUES
        (v_venda.empresa_id, v_venda.cliente_id, p_venda_id,
         'receita', 'Venda #' || substr(p_venda_id::text, 1, 8),
         v_venda.valor_total, current_date, 'pago');

    UPDATE public.vendas
    SET status = 'concluida', forma_pagamento = p_forma_pagamento
    WHERE id = p_venda_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_concluir_venda(uuid, text) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION private.rpc_concluir_venda(uuid, text) TO authenticated;


-- ── RPC: Cancelar Venda ──────────────────────────────────────────────
CREATE OR REPLACE FUNCTION private.rpc_cancelar_venda(p_venda_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_venda RECORD;
    v_item  RECORD;
BEGIN
    SELECT * INTO v_venda FROM public.vendas WHERE id = p_venda_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Venda não encontrada.'; END IF;
    IF v_venda.status != 'concluida' THEN
        RAISE EXCEPTION 'Apenas vendas concluídas podem ser canceladas (status atual: %).', v_venda.status;
    END IF;
    IF NOT public.tem_perfil(v_venda.empresa_id, 'admin', 'gerente') THEN
        RAISE EXCEPTION 'Apenas gerentes e admins podem cancelar vendas.';
    END IF;

    PERFORM set_config('erp.estoque_bypass', 'on', true);

    FOR v_item IN SELECT * FROM public.itens_venda WHERE venda_id = p_venda_id LOOP
        UPDATE public.produtos
        SET estoque_atual = estoque_atual + v_item.quantidade
        WHERE id = v_item.produto_id;

        INSERT INTO public.estoque_movimentos
            (empresa_id, produto_id, venda_id, tipo, quantidade, motivo, auth_user_id)
        VALUES
            (v_venda.empresa_id, v_item.produto_id, p_venda_id,
             'entrada', v_item.quantidade, 'Estorno Venda', auth.uid());
    END LOOP;

    UPDATE public.titulos_financeiros
    SET status = 'cancelado', descricao = descricao || ' (ESTORNADO)'
    WHERE venda_id = p_venda_id;

    UPDATE public.vendas
    SET status = 'cancelada', data_cancelamento = now()
    WHERE id = p_venda_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_cancelar_venda(uuid) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION private.rpc_cancelar_venda(uuid) TO authenticated;


-- ── RPC: Ajuste Manual de Estoque ───────────────────────────────────
CREATE OR REPLACE FUNCTION private.rpc_ajuste_estoque(
    p_produto_id uuid,
    p_tipo       text,
    p_quantidade numeric,
    p_motivo     text
)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE
    v_empresa_id       uuid;
    v_permite_negativo boolean;
    v_estoque_atual    numeric(15,4);
BEGIN
    IF p_tipo NOT IN ('entrada', 'saida') THEN
        RAISE EXCEPTION 'Tipo inválido. Use "entrada" ou "saida".';
    END IF;
    IF p_quantidade <= 0 THEN
        RAISE EXCEPTION 'Quantidade deve ser maior que zero.';
    END IF;
    IF length(trim(coalesce(p_motivo, ''))) < 3 THEN
        RAISE EXCEPTION 'Motivo obrigatório (mínimo 3 caracteres).';
    END IF;

    SELECT empresa_id, estoque_atual INTO v_empresa_id, v_estoque_atual
    FROM public.produtos WHERE id = p_produto_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Produto não encontrado.'; END IF;

    IF NOT public.tem_perfil(v_empresa_id, 'admin', 'gerente', 'estoquista') THEN
        RAISE EXCEPTION 'Acesso Negado.';
    END IF;

    SELECT permite_estoque_negativo INTO v_permite_negativo
    FROM public.empresas WHERE id = v_empresa_id;

    IF p_tipo = 'saida'
       AND (v_estoque_atual - p_quantidade) < 0
       AND NOT v_permite_negativo THEN
        RAISE EXCEPTION 'Ajuste negado: deixaria estoque negativo (atual: %).', v_estoque_atual;
    END IF;

    PERFORM set_config('erp.estoque_bypass', 'on', true);

    IF p_tipo = 'entrada' THEN
        UPDATE public.produtos SET estoque_atual = estoque_atual + p_quantidade WHERE id = p_produto_id;
    ELSE
        UPDATE public.produtos SET estoque_atual = estoque_atual - p_quantidade WHERE id = p_produto_id;
    END IF;

    INSERT INTO public.estoque_movimentos
        (empresa_id, produto_id, tipo, quantidade, motivo, auth_user_id)
    VALUES
        (v_empresa_id, p_produto_id, p_tipo, p_quantidade, p_motivo, auth.uid());
END;
$$;
REVOKE EXECUTE ON FUNCTION private.rpc_ajuste_estoque(uuid, text, numeric, text) FROM PUBLIC;
GRANT  EXECUTE ON FUNCTION private.rpc_ajuste_estoque(uuid, text, numeric, text) TO authenticated;


/* =====================================================================
   8. ROW LEVEL SECURITY (RLS)
   GRANT controla acesso ao objeto; RLS filtra as linhas por tenant.
   As duas camadas são obrigatórias e complementares.
   ===================================================================== */
ALTER TABLE public.empresas            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.usuarios_empresa    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pessoas             ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.produtos            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendas              ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.itens_venda         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.estoque_movimentos  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.titulos_financeiros ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.logs_auditoria      ENABLE ROW LEVEL SECURITY;

-- Empresas
CREATE POLICY "rls_empresas_select"
    ON public.empresas FOR SELECT
    USING (id IN (SELECT public.get_minhas_empresas()));

-- Usuários da empresa
CREATE POLICY "rls_usuarios_select"
    ON public.usuarios_empresa FOR SELECT
    USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa', 'estoquista'));
-- INSERT/UPDATE em usuarios_empresa: somente via RPC SECURITY DEFINER (sem policy direta)

-- Pessoas
CREATE POLICY "rls_pessoas_select" ON public.pessoas FOR SELECT
    USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa', 'estoquista'));
CREATE POLICY "rls_pessoas_insert" ON public.pessoas FOR INSERT
    WITH CHECK (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa'));
CREATE POLICY "rls_pessoas_update" ON public.pessoas FOR UPDATE
    USING  (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa'))
    WITH CHECK (empresa_id IN (SELECT public.get_minhas_empresas()));

-- Produtos
CREATE POLICY "rls_produtos_select" ON public.produtos FOR SELECT
    USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa', 'estoquista'));
CREATE POLICY "rls_produtos_insert" ON public.produtos FOR INSERT
    WITH CHECK (public.tem_perfil(empresa_id, 'admin', 'gerente'));
CREATE POLICY "rls_produtos_update" ON public.produtos FOR UPDATE
    USING  (public.tem_perfil(empresa_id, 'admin', 'gerente'))
    WITH CHECK (empresa_id IN (SELECT public.get_minhas_empresas()));

-- Tabelas transacionais: somente leitura (mutação exclusiva por RPCs)
CREATE POLICY "rls_vendas_select"
    ON public.vendas FOR SELECT
    USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa'));

CREATE POLICY "rls_itens_select"
    ON public.itens_venda FOR SELECT
    USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa'));

CREATE POLICY "rls_estoque_select"
    ON public.estoque_movimentos FOR SELECT
    USING (public.tem_perfil(empresa_id, 'admin', 'gerente', 'caixa', 'estoquista'));

CREATE POLICY "rls_financeiro_select"
    ON public.titulos_financeiros FOR SELECT
    USING (public.tem_perfil(empresa_id, 'admin', 'gerente'));

-- Auditoria: somente admins leem, ninguém escreve diretamente
CREATE POLICY "rls_auditoria_select"
    ON public.logs_auditoria FOR SELECT
    USING (public.tem_perfil(empresa_id, 'admin'));


/* =====================================================================
   FIM — V5 FINAL
   
   O que ainda é trabalho para uma V6 (fora do escopo do banco):
   - Suíte de testes de ataque (multi-tenant, concorrência, privilege escalation)
   - Limite de empresas por usuário / controle de plano SaaS
   - Rate limiting na camada de API (Supabase Edge Functions ou proxy)
   - Normalização e validação real de CNPJ (dígitos verificadores)
   ===================================================================== */
