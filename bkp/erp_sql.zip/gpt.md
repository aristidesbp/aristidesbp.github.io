Sim. **Esta V4 do Claude está melhor que a V3 anterior**, e ele corrigiu vários pontos que eu havia marcado. Mas eu **não aprovaria este SQL como “V4 definitiva de produção” ainda**.

E encontrei um problema que o próprio Claude não percebeu:

## 🚨 1. Há um bug crítico na auditoria da tabela `empresas`

A função:

```sql
v_empresa_id := COALESCE(NEW.empresa_id, OLD.empresa_id);
```

é aplicada também a:

```sql
CREATE TRIGGER trg_audit_empresas
AFTER INSERT OR UPDATE OR DELETE ON public.empresas
```

Só que `empresas` possui:

```sql
id
razao_social
nome_fantasia
cnpj
...
```

e **não possui `empresa_id`**. O campo identificador dela é `id`. 

Portanto, quando o trigger de auditoria disparar sobre `empresas`, a função tenta acessar um campo inexistente em `NEW`/`OLD`.

Isso pode quebrar justamente:

```sql
rpc_criar_empresa()
```

porque ela faz:

```sql
INSERT INTO public.empresas ...
```

e o trigger dispara.

### Correção

A função precisa tratar `TG_TABLE_NAME`:

```sql
IF TG_TABLE_NAME = 'empresas' THEN
    v_empresa_id := COALESCE(NEW.id, OLD.id);
ELSE
    v_empresa_id := COALESCE(NEW.empresa_id, OLD.empresa_id);
END IF;
```

**Esse é, para mim, o defeito mais urgente da V4.**

---

# 🟢 2. Claude realmente corrigiu os `FOR UPDATE`

Aqui houve uma evolução concreta.

Na conclusão:

```sql
SELECT *
INTO v_venda
FROM public.vendas
WHERE id = p_venda_id
FOR UPDATE;
```

e também ao adicionar item e cancelar. 

Isso resolve o problema que eu havia apontado de duas chamadas simultâneas passarem pelo teste:

```text
pendente → concluir
pendente → concluir
```

Agora:

```text
T1 pega lock
T2 espera
T1 conclui
T2 recebe a linha atualizada
T2 vê concluída
T2 falha
```

### Portanto:

**Concorrência da mesma venda: 🟢 melhorou bastante.**

Mas há uma nuance importante:

### Isso não significa “idempotência” no sentido estrito.

Uma segunda chamada retorna erro:

```text
Venda já está em concluída
```

Isso é **proteção contra duplicação**, que é excelente.

Mas uma operação verdadeiramente idempotente normalmente pode receber a mesma solicitação repetidamente e produzir o mesmo estado sem erro.

Para um ERP, eu prefiro a proteção atual a fingir uma idempotência inexistente.

---

# 🟢 3. O isolamento multi-tenant ficou muito mais forte

Aqui eu concordo com Claude.

As relações agora utilizam:

```sql
FOREIGN KEY (empresa_id, produto_id)
```

```sql
FOREIGN KEY (empresa_id, venda_id)
```

```sql
FOREIGN KEY (empresa_id, pessoa_id)
```

etc. 

E ainda existe a proteção:

```sql
empresa_id é imutável
```

para pessoas, produtos e vendas. 

Isso é **muito melhor que simplesmente confiar no frontend ou no RLS**.

### Meu julgamento:

**Integridade referencial cross-tenant: 🟢 forte**

Mas ainda não usaria a frase:

> “É fisicamente impossível qualquer vazamento cross-tenant.”

Porque Compound FK protege relações. Ela não transforma automaticamente **todas as consultas, funções, relatórios, views, RPCs futuras etc.** em isolamento perfeito.

---

# 🟢 4. RLS agora existe

Claude corrigiu uma deficiência importante da V4 anterior.

Agora todas as tabelas principais têm RLS:

```sql
ALTER TABLE ... ENABLE ROW LEVEL SECURITY;
```

e as políticas usam:

```sql
public.tem_perfil(empresa_id, ...)
```



Isso é exatamente a direção correta: no Supabase, **grants determinam se o papel pode acessar o objeto e RLS determina quais linhas ele pode alcançar**. As duas camadas devem ser configuradas conjuntamente. ([Supabase][1])

---

# 🟢 5. O controle de GRANT ficou melhor

Claude também acertou aqui:

```sql
REVOKE ALL ON TABLE ...
FROM anon, authenticated;

GRANT SELECT ...
TO authenticated;
```

para as tabelas transacionais. 

Isso é importante.

E ele fez:

```sql
REVOKE EXECUTE ... FROM PUBLIC;
GRANT EXECUTE ... TO authenticated;
```

nas RPCs. 

A documentação atual do Supabase recomenda exatamente esse controle explícito sobre `EXECUTE` das funções. ([Supabase][2])

---

# 🔴 6. Mas as RPCs `SECURITY DEFINER` continuam no `public`

Ainda vejo:

```sql
CREATE OR REPLACE FUNCTION public.rpc_concluir_venda(...)
```

```sql
CREATE OR REPLACE FUNCTION public.rpc_cancelar_venda(...)
```

etc. 

Isso funciona, mas eu considero arquitetura inferior para uma aplicação séria.

A documentação atual do Supabase recomenda que funções `SECURITY DEFINER` privilegiadas não fiquem em schema exposto à Data API; um schema privado dedicado é o padrão mais limpo. ([Supabase][2])

Eu faria:

```text
private.rpc_concluir_venda()
private.rpc_cancelar_venda()
private.rpc_ajuste_estoque()
private.rpc_iniciar_venda()
```

E deixaria exposto somente aquilo que realmente é API.

---

# 🔴 7. O Claude fala em CQRS, mas isso não é CQRS completo

Ele chama:

> “Padrão CQRS”

Mas o que temos é essencialmente:

```text
READ  → SELECT
WRITE → RPC
```

Isso é uma **separação de leitura/mutação**, e é uma ótima arquitetura para esse ERP.

Mas CQRS completo pode envolver modelos de leitura e escrita separados, projeções, comandos etc.

Não é um problema técnico para seu ERP.

Eu só mudaria o marketing:

> **Command-oriented RPC / separação de leitura e escrita**

ou

> **CQRS simplificado na camada de acesso**

É mais preciso.

---

# 🔴 8. Ainda existe problema nas permissões dos cadastros

Claude escreveu:

```sql
GRANT SELECT, INSERT, UPDATE
ON TABLE public.empresas, public.usuarios_empresa, public.pessoas, public.produtos
TO authenticated;
```

Mas as políticas seguintes só criam:

```text
SELECT
```

para `empresas` e `usuarios_empresa`. 

Ou seja:

```text
GRANT INSERT
+
RLS sem política INSERT
=
acesso negado
```

Isso não é vulnerabilidade — é **inconsistência de projeto**.

Na verdade, deixa uma pergunta funcional importante:

### Como o sistema cadastra novos funcionários na `usuarios_empresa`?

Não existe RPC de convite/adicionar usuário.

Portanto:

**Segurança: razoável.**

**Funcionalidade de administração de usuários: incompleta.**

---

# 🔴 9. `rpc_criar_empresa()` continua aberta a criação ilimitada de empresas

Qualquer usuário autenticado que consiga executar:

```sql
rpc_criar_empresa(...)
```

pode criar outra empresa.

Não necessariamente é uma vulnerabilidade — pode ser exatamente o SaaS desejado.

Mas para produção você provavelmente vai querer regras como:

```text
limite de empresas por usuário
plano contratado
trial
limite de usuários
rate limit
```

A documentação do Supabase inclusive destaca que RLS não resolve requisitos como limites por usuário/IP e quotas; isso precisa de outra camada. ([Supabase][3])

---

# 🟠 10. CNPJ ainda precisa ser normalizado

Tem:

```sql
cnpj text UNIQUE
```

Mas:

```text
12.345.678/0001-90
```

e:

```text
12345678000190
```

serão considerados valores diferentes.

Para SaaS comercial, eu normalizaria para somente dígitos antes da unicidade.

---

# 🔴 11. `rpc_ajuste_estoque()` ficou muito melhor, mas ainda há uma questão de governança

Agora temos:

```text
entrada
saida
quantidade > 0
motivo
FOR UPDATE
estoque negativo
```

Excelente. 

Mas um `estoquista` ainda pode executar:

```text
ajuste de estoque
```

livremente.

Talvez isso seja exatamente o esperado.

Eu acrescentaria, comercialmente, regras como:

```text
estoquista → ajuste permitido
gerente → ajuste permitido
admin → ajuste permitido
```

e opcionalmente:

```text
ajuste acima de X → gerente obrigatório
```

Isso já é governança operacional, não apenas segurança técnica.

---

# 🟠 12. A proteção `current_setting()` está boa como camada

Agora eu considero o mecanismo aceitável:

```sql
SET LOCAL / set_config(..., true)
```

e o trigger:

```sql
current_setting('erp.estoque_bypass', true)
```



Porém, como eu disse anteriormente:

**isso não deve ser apresentado como a única barreira de segurança.**

A segurança real é:

```text
REVOKE UPDATE
       +
RLS
       +
trigger
       +
RPC
       +
SECURITY DEFINER
```

A documentação do Supabase também recomenda combinar grants + RLS e restringir funções privilegiadas. ([Supabase][1])

---

# 🟠 13. Auditoria agora está muito melhor — mas “universal” exige corrigir o bug

O Claude de fato adicionou auditoria a:

```text
empresas
usuarios_empresa
pessoas
produtos
vendas
itens_venda
estoque_movimentos
titulos_financeiros
```

Isso é uma evolução real. 

Só que justamente por ter colocado `empresas`, introduziu o problema:

```sql
NEW.empresa_id
```

em uma tabela que não possui essa coluna.

Portanto:

**Arquitetura de auditoria: 🟢**

**Implementação atual: 🔴 precisa corrigir antes de executar.**

---

# 🟢 14. Ledger ficou realmente interessante

A combinação:

```text
INSERT → RPC
UPDATE → proibido
DELETE → proibido
```

é boa. 

E os movimentos guardam:

```text
empresa
produto
venda
tipo
quantidade
motivo
auth_user_id
timestamp
```

Muito bom para um ERP.

---

# 🔴 15. Ainda falta uma coisa que eu considero importante: testes automatizados de segurança

Esse é o próximo passo que o Claude não resolveu.

Você precisa de testes que tentem deliberadamente:

```text
Acessar empresa B
Alterar empresa_id
Inserir venda diretamente
Alterar venda diretamente
Inserir item diretamente
Inserir Ledger diretamente
Alterar Ledger
Alterar estoque diretamente
Concluir venda duas vezes
Cancelar duas vezes
Concluir e adicionar item simultaneamente
Usar RPC com produto de outro tenant
Usar RPC com venda de outro tenant
```

A própria documentação atual do Supabase recomenda manter testes que afirmem permissões permitidas **e negadas** para `anon` e `authenticated`. ([Supabase][1])

---

# Minha comparação

| Área                    | V3 anterior |     V4 Claude |
| ----------------------- | ----------: | ------------: |
| Compound FKs            |         9,5 |       **9,5** |
| Multi-tenant            |         8,5 |         **9** |
| RLS                     |         7,5 |       **8,5** |
| GRANTs                  |           5 |       **8,5** |
| RPCs                    |           8 |       **8,5** |
| Concorrência            |           5 |       **8,5** |
| Ledger                  |         8,5 |       **8,5** |
| Estoque                 |         7,5 |       **8,5** |
| Auditoria               |         6,5 |         **8** |
| Segurança `search_path` |         8,5 |       **8,5** |
| Produção                |           ❌ | **Ainda não** |

### Nota geral que eu daria:

**8,2/10**

A V4 está **bem próxima de uma base profissional**, mas não é “definitiva”.

---

# 🚨 Os 6 ajustes que eu faria agora

**1. Corrigir imediatamente o trigger de auditoria de `empresas`.**

**2. Colocar as funções `SECURITY DEFINER` sensíveis em `private`.**

**3. Revogar explicitamente também `PUBLIC` nos objetos/tabelas críticos, além de `anon/authenticated`, conforme o caso.** A documentação do Supabase recomenda controle explícito desses privilégios. ([Supabase][2])

**4. Criar RPC de gestão de usuários da empresa**, porque hoje `usuarios_empresa` não tem caminho funcional de INSERT/UPDATE pela API.

**5. Criar uma suíte de testes de ataque/multi-tenant e concorrência.**

**6. Só depois chamar isso de “V4 Produção”.**

## E uma correção importante no discurso comercial

Eu **não venderia**:

> “Nível bancário”
> “Integridade absoluta”
> “Impossível sofrer qualquer vazamento cross-tenant”
> “100% blindado”

Eu venderia como:

> **ERP SaaS multi-tenant com isolamento referencial por Compound Foreign Keys, RLS, RBAC, controle explícito de privilégios, operações críticas via RPC transacional, proteção de estoque, Ledger imutável e auditoria de operações sensíveis.**

Isso é tecnicamente forte **sem prometer mais do que o código consegue provar**.

**Minha decisão como auditor: V4 = candidata séria à produção, mas ainda não aprovada.** O primeiro bloqueador concreto é o trigger da auditoria em `empresas`; depois eu faria a bateria de ataques e concorrência.

[1]: https://supabase.com/docs/guides/database/postgres/row-level-security?utm_source=chatgpt.com "Row Level Security | Supabase Docs"
[2]: https://supabase.com/docs/guides/database/functions?example-view=sql&language=sql&queryGroups=example-view&queryGroups=language&utm_source=chatgpt.com "Database Functions | Supabase Docs"
[3]: https://supabase.com/docs/guides/api/securing-your-api?utm_source=chatgpt.com "Securing your API | Supabase Docs"

