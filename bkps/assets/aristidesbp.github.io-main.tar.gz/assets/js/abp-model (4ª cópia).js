// assets/js/model.js

export const portfolioData = {
  sobre: "Sou Aristides, desenvolvedor Front-end e gestor de tráfego pago. Trabalho com soluções inteligentes e foco em resultado.",
  projetos: [
    { nome: "Projeto Coworking", link: "https://github.com/..." },
    { nome: "App Lista de Tarefas", link: "https://github.com/..." }
  ],
  contato: {
    email: "aristides@example.com"
  }
};

