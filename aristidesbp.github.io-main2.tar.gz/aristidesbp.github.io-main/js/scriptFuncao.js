function createSobre() {
const sobreContainer = document.getElementById("sobre");
sobreContainer.innerHTML = `



  <h1> ola mundo</h1>



`;}/*COLOQUE NO SEU HTML:
<div id="sobre"></div>
<script src="sobre.js"></script>
<script>createSobre();</script>*/
